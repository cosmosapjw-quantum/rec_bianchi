# One independent read-only review, two perspectives

Reviewer: /root/rec02c_review. One invocation only; no second reviewer or post-repair re-review.
Reviewed adapter SHA-256: eb161073a7fda7c6d12e0fca5a2d80fb22fa7ccb933bc49021cc4d54650c9363.
Reviewed test SHA-256: c67eec0651ee3bcc23985e337db994d1a8e23afda612f5f18def21c273db38a8.
Base: 30576407d50e10b88a32b65a9510db61e4159e1b.
Independent test command: env PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 /workspace/scratch/ae018d984864/rec02c-venv/bin/python -m pytest -q -p no:cacheprovider tests/trajectory/test_rec_resolved_deposition.py.
Observed: 79 passed, exit 0. Both additional reproduction processes exited 0.
Verdict on reviewed revision: one blocking P1, no P0.

## P1: mutable NumPy headers break identity and immutability

Read-only bytes do not freeze ndarray headers; descriptor hardcodes <f8.
Ordinary dtype assignment reproduced the following:

| Mutation | Actual consequence |
|---|---|
| rates.values.dtype = np.int64 | action[0,0] 0.5 -> 1.152921504606847e18; input identity unchanged |
| binding.plan.mode_measure_m3.dtype = np.int64 | action[0,0] 0.5 -> 2.2301785790600538e-13; plan identity unchanged |
| output.values.dtype = np.int64 | value 0.5 -> 4602678819172646912; unchanged digest still describes <f8 |

Required repair: bind immutable dtype/shape/bytes, expose fresh views or protected representation.
Cover packet, tangent, plan arrays and returned outputs. Hashing a changed dtype alone is insufficient.

## PHYS-MATH

No blocking finding on the pristine manufactured fixture. Signed rates/action, s^-1 units,
the density tangent, and fixed-map scope are correct. Fraction action/JVP and moments,
B/B2 nonuniqueness and the 0.75 s^-1 difference are preserved. No physical authentication,
provider, integration or positivity-evolution claim is introduced.

## PHYS-MATH-CODE

Actual COM apply/jvp delegation is present without algebra duplication. Declared order,
units, shape, invalid-value, moving-input and typed-redeposition rejection are covered.
Receipt creation follows numerical execution. P1 prevents approving the reviewed identity
implementation. Unchanged COM and physical-source core blobs independently checked.
Figure, mutation campaign, publication and repaired revision were outside this review.

## Author disposition after the one allowed repair

The finding was independently reproduced by the author: header-repair-red.log contains
three intended assertion failures (packet/plan/output), no import or collection error.
The repair stores bytes and shape, returns fresh packet/tangent/output headers and fresh
COM plans, and canonicalizes descriptor endianness. The final suite includes four header
mutation cases (adding tangent coverage), all green in the recorded 83-test source run.
Disposition: RESOLVED_BY_EXECUTED_AUTHOR_REGRESSION; NOT independently re-reviewed.
