//! Q 티어 기하 코어 — 11개 Bianchi 유형의 통합 구조상수 캐리어.
pub mod group;
