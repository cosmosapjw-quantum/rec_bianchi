from pathlib import Path
import json,numpy as np
HERE=Path(__file__).resolve().parent
L=json.loads((HERE/'PR01B1B1_ledger.json').read_text())
assert L['hard_gate_status']['full_17x17_frequency_kernel']
assert L['hard_gate_status']['harmonic_moments_ell0_to6']
assert L['hard_gate_status']['positive_scalar_deposition']
assert L['hard_gate_status']['red_interior_blue_partition']
assert L['hard_gate_status']['same_event_four_force']
assert not L['hard_gate_status']['raw_integrated_detailed_balance']
D=np.load(HERE/'full_frequency_harmonic_deposition.npz')
assert D['harmonic_gain_sInv'].shape==(7,17,17)
assert np.min(D['harmonic_gain_sInv'][0])>=0
assert np.max(np.abs(D['photon_four_force_per_photon']+D['hydrogen_four_force_per_photon']))==0
print('PR01B1-B1 full-frequency harmonic audit: PASS')
