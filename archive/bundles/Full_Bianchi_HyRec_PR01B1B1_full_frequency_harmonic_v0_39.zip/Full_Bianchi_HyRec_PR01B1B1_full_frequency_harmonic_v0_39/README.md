# Full Bianchi-HyRec PR-01B1-B1 v0.39

The 17x17 scalar frequency matrix and recoil harmonic corrections through ell=6 were computed with 17,825,792 exact/no-recoil Sobol events.

## Passed
- positive scalar gain
- red/interior/blue partition
- number left-null
- same-event photon/hydrogen four-force
- harmonic corrections ell=0..6

## Blocked
The independently integrated raw conductance has weighted detailed-balance residual 2.456741e-04 and raw equilibrium right-null 5.487301e-05. The exact shared-conductance reference null is 1.312730e-16, but it is not used to hide the raw failure.

Next: invariant phase-space/Jacobian derivation and selected-pair deterministic reverse integration.
