from __future__ import annotations
import csv, json, hashlib, zipfile, shutil, subprocess, sys, math
from pathlib import Path
import numpy as np

ROOT=Path('/mnt/data/Full_Bianchi_HyRec_PR01B1B1_full_frequency_harmonic_v0_39')
WS=ROOT/'workspace'
sys.path.insert(0,str(WS/'src'))
from full_bianchi_hyrec.recoil.full_harmonic_deposition import FullKernelConfig, full_frequency_harmonic_kernel

config=FullKernelConfig(
    sobol_power=17,
    seeds=(101,102,103,104,105,106,107,108),
    ell_max=6,
    source_cells=tuple(range(17)),
)
result=full_frequency_harmonic_kernel(config)

# Full test suite.
test=subprocess.run(['pytest','-q'],cwd=WS,text=True,capture_output=True,check=True)
(ROOT/'PYTEST_FULL.txt').write_text(test.stdout+test.stderr)

# Pair ledger: raw independent columns, not symmetrized.
K=result.harmonic_gain_s_inv[0]
SE=result.harmonic_seed_standard_error_s_inv[0]
Pi=result.equilibrium_weight_m3
C=K*Pi[None,:]
D=C-C.T
A=.5*(C+C.T)
SEc=SE*Pi[None,:]
SEpair=np.sqrt(SEc**2+SEc.T**2)
maxC=float(np.max(np.abs(A)))
pairs=[]
for i in range(17):
    for j in range(i+1,17):
        if abs(A[i,j]) <= maxC*1e-12:
            continue
        pairs.append({
            'i':i,'j':j,
            'x_i':float(result.x_centers[i]),'x_j':float(result.x_centers[j]),
            'K_i_from_j_sInv':float(K[i,j]),
            'K_j_from_i_sInv':float(K[j,i]),
            'conductance_mean':float(A[i,j]),
            'conductance_difference':float(D[i,j]),
            'relative_difference':float(D[i,j]/A[i,j]),
            'combined_standard_error':float(SEpair[i,j]),
            'significance':float(abs(D[i,j])/(SEpair[i,j]+1e-300)),
        })
with (ROOT/'independent_pair_balance.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(pairs[0].keys())); w.writeheader(); w.writerows(pairs)

# Source-column summary.
rows=[]
for j,x in enumerate(result.x_centers):
    rows.append({
        'source_cell':j,'x_source':float(x),
        'total_rate_sInv':float(result.total_rate_s_inv[j]),
        'independent_total_rate_sInv':float(result.independent_total_rate_s_inv[j]),
        'partition_minus_independent_sInv':float(result.total_partition_discrepancy_s_inv[j]),
        'total_rate_standard_error_sInv':float(result.total_rate_standard_error_s_inv[j]),
        'inside_rate_sInv':float(result.harmonic_gain_s_inv[0,:,j].sum()),
        'red_exterior_rate_sInv':float(result.red_exterior_rate_s_inv[j]),
        'blue_exterior_rate_sInv':float(result.blue_exterior_rate_s_inv[j]),
        'capture_fraction':float(result.harmonic_gain_s_inv[0,:,j].sum()/result.total_rate_s_inv[j]),
        'recoil_increment_M1_x':float(result.recoil_increment_M1_x[j]),
        'recoil_increment_standard_error_x':float(result.recoil_increment_standard_error_x[j]),
        'minimum_scalar_target_rate_sInv':float(np.min(result.harmonic_gain_s_inv[0,:,j])),
        'Qgamma_0':float(result.photon_four_force_per_photon[j,0]),
        'Qgamma_x':float(result.photon_four_force_per_photon[j,1]),
        'Qgamma_y':float(result.photon_four_force_per_photon[j,2]),
        'Qgamma_z':float(result.photon_four_force_per_photon[j,3]),
    })
with (ROOT/'source_column_summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

# Harmonic corrections relative to Hummer reference.
ref=np.load(WS/'data/full_hummer_reference.npz')
base=ref['physical_gain_sInv'][:7]
hrows=[]
for ell in range(7):
    diff=result.harmonic_gain_s_inv[ell]-base[ell]
    hrows.append({
        'ell':ell,
        'baseline_norm':float(np.linalg.norm(base[ell])),
        'exact_recoil_correction_norm':float(np.linalg.norm(diff)),
        'relative_correction':float(np.linalg.norm(diff)/(np.linalg.norm(result.harmonic_gain_s_inv[ell])+1e-300)),
        'seed_standard_error_norm':float(np.linalg.norm(result.harmonic_seed_standard_error_s_inv[ell])),
        'correction_to_standard_error':float(np.linalg.norm(diff)/(np.linalg.norm(result.harmonic_seed_standard_error_s_inv[ell])+1e-300)),
    })
with (ROOT/'harmonic_correction_summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(hrows[0].keys())); w.writeheader(); w.writerows(hrows)

# Selected raw balance pairs: highest conductance, worst relative, worst significance.
selected=[]
if pairs:
    by_cond=sorted(pairs,key=lambda r:abs(r['conductance_mean']),reverse=True)[:8]
    by_rel=sorted(pairs,key=lambda r:abs(r['relative_difference']),reverse=True)[:8]
    by_sig=sorted(pairs,key=lambda r:r['significance'],reverse=True)[:8]
    seen=set()
    for category,items in [('highest_conductance',by_cond),('worst_relative',by_rel),('worst_significance',by_sig)]:
        for r in items:
            key=(r['i'],r['j'])
            if (category,key) in seen: continue
            selected.append({'category':category,**r}); seen.add((category,key))
with (ROOT/'selected_reverse_audit_pairs.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(selected[0].keys())); w.writeheader(); w.writerows(selected)

np.savez_compressed(
    ROOT/'full_frequency_harmonic_deposition.npz',
    classification=np.asarray('PR01B1B1_FULL_FREQUENCY_HARMONIC_QMC_AUDIT'),
    x_edges=result.x_edges,x_centers=result.x_centers,
    harmonic_gain_sInv=result.harmonic_gain_s_inv,
    harmonic_seed_standard_error_sInv=result.harmonic_seed_standard_error_s_inv,
    total_rate_sInv=result.total_rate_s_inv,
    independent_total_rate_sInv=result.independent_total_rate_s_inv,
    total_partition_discrepancy_sInv=result.total_partition_discrepancy_s_inv,
    red_exterior_rate_sInv=result.red_exterior_rate_s_inv,
    blue_exterior_rate_sInv=result.blue_exterior_rate_s_inv,
    recoil_increment_M1_x=result.recoil_increment_M1_x,
    recoil_increment_standard_error_x=result.recoil_increment_standard_error_x,
    photon_four_force_per_photon=result.photon_four_force_per_photon,
    hydrogen_four_force_per_photon=result.hydrogen_four_force_per_photon,
    equilibrium_weight_m3=result.equilibrium_weight_m3,
)

# Quantities for the stage decision.
relative_partition=np.max(np.abs(result.total_partition_discrepancy_s_inv)/(np.abs(result.total_rate_s_inv)+1e-300))
max_force=float(np.max(np.abs(result.photon_four_force_per_photon+result.hydrogen_four_force_per_photon)))
raw_db_pass=result.raw_equilibrium_right_null < 1e-12 and result.raw_pair_balance_weighted_rms < 1e-12

ledger={
 'classification':'PR01B1B1_FULL_FREQUENCY_HARMONIC_DEPOSITION_AUDIT',
 'stage':'PR-01B1-B1',
 'status':'PARTIAL_PASS_MICROREVERSIBILITY_BLOCKED',
 'configuration':{
   'temperature_K':config.temperature_K,'n1s_cm3':config.n1s_cm3,
   'frequency_cells':17,'ell_max':6,'sobol_power_per_seed':config.sobol_power,
   'seed_count':len(config.seeds),'event_count_total':17*len(config.seeds)*2**config.sobol_power,
   'seeds':list(config.seeds),
 },
 'results':{
   'minimum_scalar_gain_sInv':result.minimum_scalar_gain_s_inv,
   'maximum_partition_closure_sInv':result.maximum_deposition_residual_s_inv,
   'maximum_partition_vs_independent_total_relative':float(relative_partition),
   'maximum_same_event_four_force_residual':max_force,
   'raw_pair_balance_weighted_rms':result.raw_pair_balance_weighted_rms,
   'raw_pair_balance_max_relative':result.raw_pair_balance_max_relative,
   'raw_pair_balance_max_significance':result.raw_pair_balance_max_significance,
   'raw_pair_count':result.raw_pair_balance_pair_count,
   'generator_left_null':result.generator_left_null,
   'raw_equilibrium_right_null':result.raw_equilibrium_right_null,
   'shared_conductance_equilibrium_right_null':result.shared_conductance_equilibrium_right_null,
   'capture_fraction_min':float(np.min(result.harmonic_gain_s_inv[0].sum(axis=0)/result.total_rate_s_inv)),
   'capture_fraction_mean':float(np.mean(result.harmonic_gain_s_inv[0].sum(axis=0)/result.total_rate_s_inv)),
   'recoil_increment_min':float(np.min(result.recoil_increment_M1_x)),
   'recoil_increment_max':float(np.max(result.recoil_increment_M1_x)),
 },
 'hard_gate_status':{
   'TDD_and_full_tests':True,
   'full_17x17_frequency_kernel':True,
   'harmonic_moments_ell0_to6':True,
   'positive_scalar_deposition':bool(result.minimum_scalar_gain_s_inv>=0),
   'red_interior_blue_partition':bool(result.maximum_deposition_residual_s_inv<1e-12),
   'same_event_four_force':bool(max_force==0.0),
   'number_left_null':bool(result.generator_left_null<1e-12),
   'raw_integrated_detailed_balance':bool(raw_db_pass),
   'raw_equilibrium_right_null':bool(result.raw_equilibrium_right_null<1e-12),
   'shared_conductance_reference_null':bool(result.shared_conductance_equilibrium_right_null<1e-12),
   'independent_deterministic_reverse_pairs':False,
   'ell12_20_24_release':False,
 },
 'decision':{
   'frequency_harmonic_deposition':'PASS_THROUGH_ELL6',
   'production_release':'NOT_APPROVED',
   'blocker':'raw independently integrated columns do not satisfy thermal microreversibility at release tolerance',
   'interpretation':(
      'The event corrections, positive deposition, number ledger and same-event four-force are stable. '
      'The remaining ~1e-4 raw equilibrium residual is systematic, not hidden by the exact shared-conductance null. '
      'The next stage must derive and implement the invariant forward/reverse phase-space Jacobian or a common invariant conductance parameterization.'
   ),
 },
 'next_stage':{
   'name':'PR01B1B2_invariant_phase_space_measure',
   'tasks':[
      'derive the Lorentz-invariant 2-to-2 event measure and the Jacobian between forward and PT-reverse rest-frame solid-angle parameterizations',
      'replace the current c(1-beta.n)d3p dOmega* parameterization by a common invariant conductance measure',
      'run deterministic reverse quadrature on selected high-weight pairs',
      'recompute the 17x17 ell<=6 correction and require raw detailed balance below 1e-10 before event pairing',
      'only then extend to L=12/20/24 and BackgroundSnapshot exterior coupling',
   ]
 },
 'limitations':[
   'scalar unresolved 2p pole+crossed amplitude only',
   'harmonic correction is stored only through ell=6',
   'red/blue baseline split uses no-recoil mirror symmetry and QMC recoil corrections',
   'shared conductance null is an audit reference and is not used to approve the raw kernel',
 ]
}
(ROOT/'PR01B1B1_ledger.json').write_text(json.dumps(ledger,indent=2))

formalism=r'''# PR-01B1-B1 full-frequency harmonic deposition audit

## Integrated kernel

For source cell `j`, the exact recoil correction is evaluated with the
same Sobol point as the no-recoil event:

\[
K^{\rm trial}_{\ell,ij}
=K^{\rm Hummer}_{\ell,ij}
+\langle w_e P_\ell(\mu_{\rm H})D_i(e)
-w_e^0P_\ell(\mu_{\rm H}^0)D_i(e^0)\rangle.
\]

The angle in the tally is the hydrogen-frame scattering angle. The
atomic cross section is still evaluated in the initial atom rest frame.

## Positive partition

Every microscopic outcome belongs to red exterior, one interior cell,
or blue exterior. The partitioned estimator is primary:

\[
\Gamma_j=K_{Rj}+\sum_iK_{ij}+K_{Bj}.
\]

An independently averaged total-rate estimator is retained only as a
quadrature diagnostic.

## Raw detailed-balance audit

The 17 source columns are integrated independently. Before any event
pairing, define

\[
C^{\rm raw}_{ij}=K^{\rm raw}_{i\leftarrow j}\Pi_j.
\]

Production microreversibility requires

\[
C^{\rm raw}_{ij}=C^{\rm raw}_{ji}
\]

within integration error. This stage finds a statistically significant
residual at roughly the 10^{-4} operator level. The symmetric reference

\[
S_{ij}=\tfrac12(C^{\rm raw}_{ij}+C^{\rm raw}_{ji})
\]

is stored only to show what the exact equilibrium null would be after
pairing; it is not accepted as a repair.

## Consequence

The current forward variables

\[
d^3p_i\,c(1-\boldsymbol\beta_i\cdot\boldsymbol n_i)\,d\Omega_i^*
\]

are not yet a demonstrated common measure under the PT event map. The
next stage must derive the invariant phase-space measure or its explicit
forward/reverse Jacobian before the full kernel can be released.
'''
(ROOT/'FULL_FREQUENCY_HARMONIC_FORMALISM.md').write_text(formalism)

verify='''from pathlib import Path\nimport json,numpy as np\nHERE=Path(__file__).resolve().parent\nL=json.loads((HERE/'PR01B1B1_ledger.json').read_text())\nassert L['hard_gate_status']['full_17x17_frequency_kernel']\nassert L['hard_gate_status']['harmonic_moments_ell0_to6']\nassert L['hard_gate_status']['positive_scalar_deposition']\nassert L['hard_gate_status']['red_interior_blue_partition']\nassert L['hard_gate_status']['same_event_four_force']\nassert not L['hard_gate_status']['raw_integrated_detailed_balance']\nD=np.load(HERE/'full_frequency_harmonic_deposition.npz')\nassert D['harmonic_gain_sInv'].shape==(7,17,17)\nassert np.min(D['harmonic_gain_sInv'][0])>=0\nassert np.max(np.abs(D['photon_four_force_per_photon']+D['hydrogen_four_force_per_photon']))==0\nprint('PR01B1-B1 full-frequency harmonic audit: PASS')\n'''
(ROOT/'verify_PR01B1B1.py').write_text(verify)
subprocess.run([sys.executable,str(ROOT/'verify_PR01B1B1.py')],check=True)

readme=f'''# Full Bianchi-HyRec PR-01B1-B1 v0.39\n\nThe 17x17 scalar frequency matrix and recoil harmonic corrections through ell=6 were computed with {ledger['configuration']['event_count_total']:,} exact/no-recoil Sobol events.\n\n## Passed\n- positive scalar gain\n- red/interior/blue partition\n- number left-null\n- same-event photon/hydrogen four-force\n- harmonic corrections ell=0..6\n\n## Blocked\nThe independently integrated raw conductance has weighted detailed-balance residual {result.raw_pair_balance_weighted_rms:.6e} and raw equilibrium right-null {result.raw_equilibrium_right_null:.6e}. The exact shared-conductance reference null is {result.shared_conductance_equilibrium_right_null:.6e}, but it is not used to hide the raw failure.\n\nNext: invariant phase-space/Jacobian derivation and selected-pair deterministic reverse integration.\n'''
(ROOT/'README.md').write_text(readme)

# Manifest and archive.
manifest=[]
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and p.name!='MANIFEST_SHA256.txt':
        manifest.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}")
(ROOT/'MANIFEST_SHA256.txt').write_text('\n'.join(manifest)+'\n')
zip_path=Path('/mnt/data/Full_Bianchi_HyRec_PR01B1B1_full_frequency_harmonic_v0_39.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file(): z.write(p,arcname=f'{ROOT.name}/{p.relative_to(ROOT)}')
with zipfile.ZipFile(zip_path) as z:
    bad=z.testzip(); assert bad is None,bad
print(json.dumps({'bundle':str(zip_path),'ledger':str(ROOT/'PR01B1B1_ledger.json'),'pytest':test.stdout.strip(),'results':ledger['results'],'hard_gates':ledger['hard_gate_status'],'zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest()},indent=2))
