from pathlib import Path
import json, numpy as np
HERE=Path(__file__).resolve().parent
L=json.loads((HERE/"C3B2A_ledger.json").read_text())
assert L["hard_gate_status"]["C_solver_parity"]
assert L["hard_gate_status"]["native_true_rate_remap"]
assert L["hard_gate_status"]["angle_restriction_identity"]
assert not L["hard_gate_status"]["direct_Tvv_lift"]
assert not L["hard_gate_status"]["Lebedev26_isotropy"]
assert not L["hard_gate_status"]["absolute_rate_normalization"]
d=np.load(HERE/"angular_lift_audit.npz")
assert abs(d["angular_weights"].sum()-1)<1e-15
assert np.all(d["fine_Tvr_magnitude"]>=0)
assert np.all(d["fine_Trv_magnitude"]>=0)
print("C3B2A substitution audit: PASS")
