# Full Bianchi–HyRec C3B2A substitution audit v0.28

- C runtime structured-solver parity: PASS
- positive native-to-fine true-rate remap: PASS
- exact angular restriction identity: PASS
- direct lifting of escape-compressed Tvv: REJECTED
- Lebedev-26 angular release: FAIL
- absolute s^-1 COM–KHW normalization: OPEN
- monolithic substitution: NOT APPROVED

Key numbers:

- C/Python Schur difference: 2.765780e-15
- smooth-L8 isotropy leakage: 2.193350e-03
- narrow-core isotropy leakage: 7.425381e-03
- single-scale FP matching residual: 2.511977e-01
- required scale spread: 3.116699e+03
