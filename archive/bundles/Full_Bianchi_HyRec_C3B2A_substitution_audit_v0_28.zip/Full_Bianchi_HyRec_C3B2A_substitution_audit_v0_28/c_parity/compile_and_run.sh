#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cc -O2 -std=c11 -Wall -Wextra -pedantic \
  "$HERE/parity_harness.c" -lm -o "$HERE/parity_harness"
"$HERE/parity_harness" "$HERE" "$HERE/c_solution.bin"
python "$HERE/compare_parity.py"
