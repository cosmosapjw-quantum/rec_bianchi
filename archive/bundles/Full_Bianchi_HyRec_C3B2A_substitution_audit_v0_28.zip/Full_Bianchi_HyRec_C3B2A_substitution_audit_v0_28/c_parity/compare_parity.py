from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
c=np.fromfile(HERE/"c_solution.bin",dtype="<f8")
py=np.fromfile(HERE/"schur_solution.bin",dtype="<f8")
relative=np.linalg.norm(c-py)/np.linalg.norm(py)
maximum=np.max(np.abs(c-py))
assert relative < 1e-13
assert maximum < 1e-20
print("C solver parity: PASS")
print("relative =",relative)
print("max_abs  =",maximum)
