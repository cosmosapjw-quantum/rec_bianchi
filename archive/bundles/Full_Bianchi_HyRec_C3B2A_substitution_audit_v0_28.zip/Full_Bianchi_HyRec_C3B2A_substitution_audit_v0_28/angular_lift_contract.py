"""Angular lift identities for the HYREC/Bianchi interface."""
from __future__ import annotations
import numpy as np


def isotropic_prolongation(n_frequency: int, n_angle: int) -> np.ndarray:
    return np.kron(
        np.eye(n_frequency),
        np.ones((n_angle, 1)),
    )


def angular_restriction(
    n_frequency: int,
    angular_weights: np.ndarray,
) -> np.ndarray:
    return np.kron(
        np.eye(n_frequency),
        angular_weights.reshape(1, -1),
    )


def lifted_real_to_radiation(
    Tvr_frequency: np.ndarray,
    n_angle: int,
) -> np.ndarray:
    return np.kron(
        Tvr_frequency,
        np.ones((n_angle, 1)),
    )


def lifted_radiation_to_real(
    Trv_frequency: np.ndarray,
    angular_weights: np.ndarray,
) -> np.ndarray:
    return np.kron(
        Trv_frequency,
        angular_weights.reshape(1, -1),
    )
