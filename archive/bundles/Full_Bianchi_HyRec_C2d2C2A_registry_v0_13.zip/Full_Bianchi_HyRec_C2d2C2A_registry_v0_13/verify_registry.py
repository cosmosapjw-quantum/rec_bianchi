from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
data = np.load(HERE / "geometry_registry.npz")

directions = data["directions"]
weights = data["angular_weights"]
edge_a = data["edge_a"]
edge_b = data["edge_b"]
active = data["recommended_active"].astype(bool)

assert directions.shape == (26, 3)
assert abs(weights.sum() - 1.0) < 1e-15
assert np.max(abs(np.sum(weights[:,None] * directions, axis=0))) < 1e-15

second = np.einsum("q,qi,qj->ij", weights, directions, directions)
assert np.max(abs(second - np.eye(3)/3.0)) < 1e-15

assert edge_a.size == 97461
assert np.all(edge_a < edge_b)
assert active.sum() == 93925

indptr = data["active_CSR_indptr"]
indices = data["active_CSR_indices"]
edge_ids = data["active_CSR_edge_id"]

assert indptr.shape == (443,)
assert indices.size == 2 * active.sum()
assert edge_ids.size == indices.size
assert indptr[-1] == indices.size

print("C2d2C2A geometry registry: PASS")
