from pathlib import Path
import json, numpy as np
HERE=Path(__file__).resolve().parent
data=np.load(HERE/"exact_nested_conductance.npz")
ledger=json.loads((HERE/"D1CB_ledger.json").read_text())
for d in ("10.25","12.75","16.25","21.25"):
    S=data[f"S_{d}"];Pi=data[f"Pi_{d}"]
    assert np.max(np.abs(S-S.T)) < 1e-12
    K=S/Pi[None,:]
    G=K.copy();np.fill_diagonal(G,0);np.fill_diagonal(G,-G.sum(axis=0))
    assert np.max(np.abs(np.ones(len(Pi))@G)) < 1e-11
    assert np.max(np.abs(G@Pi)) < 1e-11
assert ledger["orbit_counts"]["new_physics_orbits"]==2340
print("D1C-B exact outer-wing bundle: PASS")
