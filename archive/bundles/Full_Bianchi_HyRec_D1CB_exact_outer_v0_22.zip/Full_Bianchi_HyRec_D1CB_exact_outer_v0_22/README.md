# Full Bianchi-HyRec D1C-B exact outer wing v0.22

This bundle replaces the calibrated Hummer surrogate outside |x|=10.25 by
2,340 exact cell-integrated scalar COM-KHW orbit evaluations.

Main results:

- conductance-weighted low/high quadrature difference:
  8.430181409036e-12
- exact versus pilot matrix difference at |x|=21.25:
  1.509518855221e-07
- compact/tapered |x|=10.25 -> 12.75 action gate:
  1.746503080635e-05
- maximum fractional detuning at the outer boundary:
  4.987042953399e-04

See DOMAIN_POLICY.md for the scalar production-domain decision.
