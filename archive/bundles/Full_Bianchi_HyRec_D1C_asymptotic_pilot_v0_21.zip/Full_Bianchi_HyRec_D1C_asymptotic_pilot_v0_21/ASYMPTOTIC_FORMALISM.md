# D1C calibrated far-wing pilot

The new outer-wing conductance uses the observer-frame Hummer-II kernel
with recoil shift and the photon phase-space detailed-balance factor.
For -1<mu<1, define

X=x_o+g(1-mu),  Y=x_i,
X=c u+s z,       Y=c u-s z,

c=sqrt((1+mu)/2), s=sqrt((1-mu)/2).

The Jacobian cancels the prefactor:

r_II dX dY = exp(-z^2) H(a/c,u) du dz / pi.

At mu=-1 the exact finite limit is integrated with u=a tan(theta).
A low-order log-correction in mean detuning, frequency separation and mu
is fitted to the immutable v0.20 wing cache.  The full-fit and an
outer-cell holdout fit define the surrogate uncertainty band.

Existing |x|<=10.25 conductance entries are never replaced.
