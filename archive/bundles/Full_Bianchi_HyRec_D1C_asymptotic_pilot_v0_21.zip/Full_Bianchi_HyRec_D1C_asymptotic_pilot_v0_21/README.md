# Full Bianchi-HyRec D1C asymptotic pilot v0.21

This artifact extends the immutable v0.20 conductance to nested symmetric
domains |x|=12.75,16.25,21.25 with a calibrated Hummer-II far-wing lane.

It is intentionally classified as a pilot: the overlap matrix error of the
calibration is 3.753431e-05, and the
outer holdout uncertainty is recorded separately.

See D1C_ledger.json and nested_domain_actions.csv for the domain decision.
