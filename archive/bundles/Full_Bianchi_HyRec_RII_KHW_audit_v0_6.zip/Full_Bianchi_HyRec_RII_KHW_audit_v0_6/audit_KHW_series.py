"""
Near-Ly-alpha Kramers-Heisenberg amplitude audit.

Lee's expansion is

    A(delta)/A0 =
        1 - 0.8961 delta
          - 12.22 delta^2
          - 52.52 delta^3
          - 243.8 delta^4
          - 1210 delta^5,

with delta = (nu_in_star - nu_alpha)/nu_alpha.

The cross-section correction is |A/A0|^2.  It multiplies the
incoming atom-frame scalar absorption amplitude.  The atom-frame
nu_out_star/nu_in_star Kramers-Heisenberg-Waller factor remains
separately in the exact event weight and must not be duplicated.

Complete numerical results are stored in KHW_event_audit_results.npz
and KHW_event_audit_ledger.json.
"""
