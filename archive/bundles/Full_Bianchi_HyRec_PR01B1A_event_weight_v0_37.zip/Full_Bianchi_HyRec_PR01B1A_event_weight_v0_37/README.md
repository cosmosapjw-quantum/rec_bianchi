# Full Bianchi-HyRec PR-01B1-A v0.37

This bundle locks a positive scalar 2p pole+crossed event response and
the Maxwell-Juettner equilibrium conductance of an exact PR-01A recoil
event.

## Results

- full pytest suite: ..............                                                           [100%]
14 passed in 0.43s
- float64 physical events: 5000
- arbitrary-precision PT events: 60
- maximum high-precision response residual: 5.336363065071218747374265094798561175741e-85
- maximum high-precision thermal-log residual: 1.976662114355723104565357634613128563946e-82
- maximum high-precision conductance residual: 1.976662114355723104565357634613128563946e-82

## Status

- PR-01B1-A event conductance: PASS
- Maxwell-Juettner momentum integration: OPEN
- finite-volume deposition: OPEN
- production lab differential rate: OPEN

The primitive Bianchi background code remains an external host/reference;
local event microphysics is intentionally chart independent.
