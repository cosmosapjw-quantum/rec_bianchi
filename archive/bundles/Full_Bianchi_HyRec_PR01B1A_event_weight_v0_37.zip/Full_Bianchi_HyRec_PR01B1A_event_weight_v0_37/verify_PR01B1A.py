from pathlib import Path
import csv,json
import mpmath as mp

HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/'PR01B1A_ledger.json').read_text())
for key,value in ledger['hard_gate_status'].items():
    if key in {'finite_volume_deposition','Maxwellian_momentum_integration','production_lab_rate'}:
        assert not value
    else:
        assert value

with (HERE/'scalar_2p_response_scan.csv').open() as f:
    rows=list(csv.DictReader(f))
assert all(float(row['response_area_m2'])>0 for row in rows)
assert '14 passed' in ledger['TDD']['green']
print('PR-01B1-A event conductance: PASS')
