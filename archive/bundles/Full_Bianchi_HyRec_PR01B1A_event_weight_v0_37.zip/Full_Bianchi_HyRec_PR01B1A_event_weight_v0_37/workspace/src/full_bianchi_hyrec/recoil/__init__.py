"""Exact scalar photon-hydrogen recoil kinematics."""
