"""Re-run the durable C3B2B1-B invariant checks.

The full numerical generator is documented in
HARMONIC_NYSTROM_FORMALISM.md and represented by the durable NPZ.
"""
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
subprocess.run(
    ["python",str(HERE/"verify_C3B2B1B.py")],
    check=True,
)
