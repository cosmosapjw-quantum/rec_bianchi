from pathlib import Path
import json
import numpy as np
import csv

HERE=Path(__file__).resolve().parent
ledger=json.loads(
    (HERE/"C3B2B1B_ledger.json").read_text()
)
assert all(ledger["hard_gate_status"].values())

data=np.load(
    HERE/"continuous_mu_legendre_kernel.npz"
)
K=data["dimensionless_legendre_kernel"]
assert K.shape == (7,17,17)
assert np.all(np.isfinite(K))
assert np.min(K[0]) >= 0.0
assert np.all(
    (data["capture_fraction"] >= 0.0)
    & (data["capture_fraction"] <= 1.0+1e-12)
)

print("C3B2B1-B harmonic/Nystrom reference: PASS")
