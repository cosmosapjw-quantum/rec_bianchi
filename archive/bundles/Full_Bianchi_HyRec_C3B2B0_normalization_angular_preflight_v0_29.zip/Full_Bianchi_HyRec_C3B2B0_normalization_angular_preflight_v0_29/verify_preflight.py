from pathlib import Path
import json
import numpy as np

HERE=Path(__file__).resolve().parent
ledger=json.loads(
    (HERE/"normalization_angular_ledger.json").read_text()
)

assert ledger["hard_gate_status"][
    "absolute_cross_section_convention"
]
assert ledger["hard_gate_status"][
    "oscillator_strength_integral"
]
assert ledger["hard_gate_status"][
    "Rayleigh_phase_normalization"
]
assert ledger["hard_gate_status"][
    "Lebedev_rule_registry"
]
assert not ledger["hard_gate_status"][
    "Lebedev38_50_release_for_sharp_kernel"
]
assert not ledger["hard_gate_status"][
    "physical_COM_KHW_rate_table"
]

registry=np.load(HERE/"lebedev_rule_registry.npz")
for order in [7,9,11,13,15,17,19,23,29]:
    weights=registry[f"weights_order_{order}"]
    directions=registry[f"directions_order_{order}"]
    assert abs(weights.sum()-1.0) < 1e-14
    assert np.max(
        np.abs(np.linalg.norm(directions,axis=1)-1.0)
    ) < 1e-14

print("C3B2B0 normalization and angular preflight: PASS")
