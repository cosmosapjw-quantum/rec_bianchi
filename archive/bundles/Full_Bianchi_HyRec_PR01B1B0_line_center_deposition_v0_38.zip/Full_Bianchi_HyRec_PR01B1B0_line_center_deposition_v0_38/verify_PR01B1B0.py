from pathlib import Path
import json
import numpy as np

HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/"PR01B1B0_ledger.json").read_text())

for key,value in ledger["hard_gate_status"].items():
    if key in {"full_17x17_kernel","independent_integrated_reverse_quadrature"}:
        assert not value
    else:
        assert value

data=np.load(HERE/"line_center_deposition.npz")
inside=data["inside_rate_sInv"]
total=float(data["total_rate_sInv"])
red=float(data["red_exterior_rate_sInv"])
blue=float(data["blue_exterior_rate_sInv"])

assert np.all(inside >= 0.0)
assert red >= 0.0 and blue >= 0.0
assert abs(inside.sum()+red+blue-total) < 1e-12
assert np.linalg.norm(
    data["photon_four_force_per_photon"]
    + data["hydrogen_four_force_per_photon"]
) == 0.0

print("PR01B1-B0 line-centre deposition: PASS")
