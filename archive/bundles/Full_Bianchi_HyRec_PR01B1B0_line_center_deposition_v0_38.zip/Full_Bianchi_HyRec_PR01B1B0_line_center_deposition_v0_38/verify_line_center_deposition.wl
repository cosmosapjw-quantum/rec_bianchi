ClearAll["Global`*"];

phase=3(1+mu^2)/8;
rayleighNorm=Integrate[phase,{mu,-1,1}];
meanOneMinusMu=Integrate[phase(1-mu),{mu,-1,1}];

recoilShift=-g(1-mu)/(1+g b(1-mu));
recoilMean=Assuming[
 {g>0,b>0},
 FullSimplify[Integrate[phase recoilShift,{mu,-1,1}]]
];

a21FromF=8 Pi^2 re f nu0^2/(3 c);
areaCorrection=A21/a21FromF;

pairResidual=FullSimplify[
 (Kic PiC)-(Kic PiC/PiI)PiI,
 Assumptions->{PiC>0,PiI>0}
];

<|
 "RayleighNormalization"->rayleighNorm,
 "MeanOneMinusMu"->meanOneMinusMu,
 "ExactRayleighRecoilMean"->recoilMean,
 "OscillatorAreaCorrection"->areaCorrection,
 "SharedConductanceResidual"->pairResidual,
 "DepositionPartitionResidual"->
  FullSimplify[DR+Total[Di]+DB-1 /. DB->1-DR-Total[Di]]
|>
