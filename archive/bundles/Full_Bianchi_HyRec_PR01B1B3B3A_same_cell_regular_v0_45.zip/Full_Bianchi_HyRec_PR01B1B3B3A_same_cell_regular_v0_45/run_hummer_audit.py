import sys, numpy as np
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'workspace/src'))
from full_bianchi_hyrec.recoil.same_cell_regular import integrate_hummer_same_cell_audit
cell=8
v=integrate_hummer_same_cell_audit(cell,lane='reference',ell_max=12)
np.savez_compressed(HERE/'chunks/hummer_audit_8.npz',cell=np.asarray(cell),rate_sInv=v)
print(v)
