from __future__ import annotations
import argparse, sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
WORK=HERE/'workspace'
sys.path.insert(0,str(WORK/'src'))
from full_bianchi_hyrec.recoil.same_cell_regular import integrate_same_cell_regularized

p=argparse.ArgumentParser();p.add_argument('--cell',type=int,required=True);p.add_argument('--lane',default='production');p.add_argument('--ell-max',type=int,default=24);p.add_argument('--out',required=True);a=p.parse_args()
value=integrate_same_cell_regularized(a.cell,lane=a.lane,ell_max=a.ell_max)
np.savez_compressed(a.out,cell=np.asarray(a.cell),lane=np.asarray(a.lane),ell_max=np.asarray(a.ell_max),rate_sInv=value)
print(a.cell,a.lane,value[0],value[1],value[-1])
