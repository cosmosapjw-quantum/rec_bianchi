"""Invariant scalar photon--hydrogen pair-cell integration."""
