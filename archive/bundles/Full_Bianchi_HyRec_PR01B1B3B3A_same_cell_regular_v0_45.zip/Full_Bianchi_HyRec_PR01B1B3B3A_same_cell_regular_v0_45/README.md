# Full Bianchi--HyRec PR-01B1-B3B3A v0.45

The distributional same-frequency-cell gain is replaced by the finite collision remainder K_ell(i,i)-K_0(i,i).  The coherent-forward delta cancels analytically because P_ell(1)=1.

## Results

- cells: 17
- ell range: 0--24
- scalar remainder: 0.000e+00
- most negative angular rate: -3.109510e-01 s^-1
- selected production/reference: 4.223806e-08
- independent Hummer endpoint audit: 5.290973e-09
- scalar number left-null: 6.183624e-17
- scalar equilibrium right-null: 2.180772e-16

## Status

- same-cell coherent/angular block: PASS
- raw distributional diagonal gain: intentionally not constructed
- red/blue exterior deposition: OPEN
- full PR-01 release: OPEN
