ClearAll["Global`*"];
coherent=Table[FullSimplify[LegendreP[l,1]-1],{l,0,24}];
series=Table[Normal@Series[LegendreP[l,1-t^2]-1,{t,0,4}],{l,0,6}];
jac=FullSimplify[Abs[Det[D[{u+s y,u-s y},{{u,y}}]]],Assumptions->s>0];
measure=FullSimplify[1/2 Abs[D[1-t^2,t]],Assumptions->t>0];
<|"CoherentCancellation"->coherent,"ForwardSeries"->series,"FrequencyJacobian"->jac,"AngularMeasure"->measure,"ScalarRemainder"->0|>
