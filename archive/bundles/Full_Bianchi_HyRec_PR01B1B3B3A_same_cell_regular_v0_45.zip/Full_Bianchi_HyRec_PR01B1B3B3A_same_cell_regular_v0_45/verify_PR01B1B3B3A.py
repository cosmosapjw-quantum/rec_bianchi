from pathlib import Path
import json,numpy as np
H=Path(__file__).resolve().parent
L=json.loads((H/'PR01B1B3B3A_ledger.json').read_text())
for k,v in L['hard_gate_status'].items():
    if k in {'red_blue_exterior_deposition','full_PR01_release'}: assert not v
    else: assert v
D=np.load(H/'same_cell_regularized_block.npz')
R=D['exact_regularized_rate_sInv']; assert R.shape==(25,17); assert np.max(np.abs(R[0]))==0.; assert np.all(R[1:]<=1e-18)
M=D['bounded_collision_matrices_ell0_to6_sInv'];Pi=D['equilibrium_weight_m3'];assert np.max(np.abs(np.ones(17)@M[0]))<1e-12;assert np.max(np.abs(M[0]@Pi))/(np.max(np.abs(M[0]))*np.max(Pi))<1e-12
print('PR01B1-B3B3A same-cell regularized block: PASS')
