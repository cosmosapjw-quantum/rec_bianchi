from __future__ import annotations
import csv, hashlib, json, math, shutil, subprocess, sys, zipfile
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
WORK=HERE/'workspace'
sys.path.insert(0,str(WORK/'src'))
from full_bianchi_hyrec.recoil.same_cell_regular import assemble_from_same_cell_rates

# Load production chunks.
prod=np.zeros((25,17))
for cell in range(17):
    d=np.load(HERE/f'chunks/prod_{cell}.npz')
    prod[:,cell]=d['rate_sInv']

selected=(0,8,16)
ref={}
for cell in selected:
    ref[cell]=np.load(HERE/f'chunks/ref_{cell}.npz')['rate_sInv']

v032=np.load('/mnt/data/Full_Bianchi_HyRec_C3B2B1C_finite_volume_ellmax_v0_32/finite_volume_legendre_kernel.npz')
v033=np.load('/mnt/data/Full_Bianchi_HyRec_C3B2B1D0_thermodynamic_completion_v0_33/thermodynamic_completed_kernel.npz')
off=np.load(WORK/'data/offdiagonal_pair_conductance.npz')
pi=np.asarray(off['equilibrium_weight_m3'])
hgain=np.asarray(v032['physical_gain_sInv'][:25])
hloss=np.asarray(v032['within_core_loss_sInv'])
hummer=np.zeros_like(prod)
for cell in range(17):
    hummer[:,cell]=hgain[:,cell,cell]-hgain[0,cell,cell]
correction=prod-hummer
conductance=prod*pi[None,:]

assembled=assemble_from_same_cell_rates(prod[:7])
operators=assembled['collision_matrices_sInv']
left=float(np.max(np.abs(np.ones(17)@operators[0])))
right=float(np.max(np.abs(operators[0]@pi))/(np.max(np.abs(operators[0]))*np.max(pi)+1e-300))

# Selected quadrature convergence.
conv=[]
for cell in selected:
    rel=float(np.linalg.norm(prod[1:,cell]-ref[cell][1:])/(np.linalg.norm(ref[cell][1:])+1e-300))
    conv.append({'cell':cell,'x_center':float(0.5*(v032['x_edges'][cell]+v032['x_edges'][cell+1])),'production_reference_relative':rel})
max_conv=max(r['production_reference_relative'] for r in conv)

# Independent Hummer endpoint audit at the central cell.
ha=np.load(HERE/'chunks/hummer_audit_8.npz')['rate_sInv']
href=hummer[:13,8]
hummer_audit=float(np.linalg.norm(ha[1:]-href[1:])/np.linalg.norm(href[1:]))

# Same-cell table.
rows=[]
for cell in range(17):
    row={'cell':cell,'x_center':float(v032['x_centers'][cell])}
    for ell in (0,1,2,4,6,8,12,16,20,24):
        row[f'exact_L{ell}_sInv']=float(prod[ell,cell])
        row[f'hummer_L{ell}_sInv']=float(hummer[ell,cell])
        row[f'correction_L{ell}_sInv']=float(correction[ell,cell])
    rows.append(row)
with (HERE/'same_cell_regularized_rates.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)
with (HERE/'selected_same_cell_convergence.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(conv[0].keys()));w.writeheader();w.writerows(conv)

# Harmonic comparisons and action checks.
hum_ops=np.asarray(v032['physical_gain_sInv'][:7]).copy()
for ell in range(7):
    np.fill_diagonal(hum_ops[ell],np.diag(hum_ops[ell])-hloss)
v33_ops=np.asarray(v033['occupation_gain_sInv'][:7]).copy()
for ell in range(7):
    np.fill_diagonal(v33_ops[ell],np.diag(v33_ops[ell])-v033['completed_loss_sInv'])

comp=[]
for ell in range(7):
    comp.append({
        'ell':ell,
        'same_cell_exact_norm_sInv':float(np.linalg.norm(prod[ell])),
        'same_cell_correction_norm_sInv':float(np.linalg.norm(correction[ell])),
        'same_cell_relative_to_hummer':float(np.linalg.norm(correction[ell])/(np.linalg.norm(prod[ell])+1e-300)),
        'full_operator_relative_to_hummer':float(np.linalg.norm(operators[ell]-hum_ops[ell])/(np.linalg.norm(operators[ell])+1e-300)),
        'full_operator_relative_to_v033':float(np.linalg.norm(operators[ell]-v33_ops[ell])/(np.linalg.norm(operators[ell])+1e-300)),
    })
with (HERE/'same_cell_harmonic_comparison.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(comp[0].keys()));w.writeheader();w.writerows(comp)

x=np.asarray(v032['x_centers'])
shapes={
 'smooth_L8':1+0.05*np.cos(x/8),
 'smooth_L2':1+0.05*np.cos(x/2),
 'narrow_core':1+0.1*np.exp(-0.5*(x/0.4)**2),
 'odd_red_blue':1+0.05*np.tanh(x/0.5),
}
action=[]
for name,field in shapes.items():
    a=operators[0]@field; h=hum_ops[0]@field; t=v33_ops[0]@field
    action.append({'state':name,'exact_norm_sInv':float(np.linalg.norm(a)),'relative_to_hummer':float(np.linalg.norm(a-h)/(np.linalg.norm(a)+1e-300)),'relative_to_v033':float(np.linalg.norm(a-t)/(np.linalg.norm(a)+1e-300)),'number_residual':float(abs(a.sum()))})
with (HERE/'bounded_scalar_action_comparison.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(action[0].keys()));w.writeheader();w.writerows(action)

# Dissipation of the same-cell remainder for random harmonic coefficients.
rng=np.random.default_rng(20260804)
diss=[]
for ell in range(1,25):
    field=rng.normal(size=17)
    q=float(np.dot(pi*field,prod[ell]*field))
    diss.append({'ell':ell,'weighted_quadratic_form':q})
with (HERE/'same_cell_dissipation.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=list(diss[0].keys()));w.writeheader();w.writerows(diss)
max_diss=max(r['weighted_quadratic_form'] for r in diss)

np.savez_compressed(
    HERE/'same_cell_regularized_block.npz',
    classification=np.asarray('PR01B1B3B3A_REGULARIZED_SAME_CELL_ANGULAR_BLOCK'),
    x_edges=v032['x_edges'],x_centers=v032['x_centers'],ell_values=np.arange(25),
    exact_regularized_rate_sInv=prod,hummer_regularized_rate_sInv=hummer,
    exact_minus_hummer_rate_sInv=correction,
    exact_regularized_conductance_m3_sInv=conductance,
    equilibrium_weight_m3=pi,
    bounded_collision_matrices_ell0_to6_sInv=operators,
)

formalism=r'''# PR-01B1-B3B3A regularized same-cell angular block

## Raw and collision-relevant moments

For frequency cell \(I_i\), let \(\mathsf S^{(\ell)}_{ii}\) denote the raw same-cell gain conductance.  The collision operator never needs this distributional quantity by itself.  Its same-cell contribution is

\[
\boxed{\mathcal D_{\ell i}=\frac{\mathsf S^{(\ell)}_{ii}-\mathsf S^{(0)}_{ii}}{\Pi_i}}.
\]

Equivalently,

\[
\boxed{\mathcal D_{\ell i}=\frac1{\Pi_i}\int_{I_i\times I_i}\!d\Phi\;[P_\ell(\mu)-1]}. 
\]

The coherent-forward part is proportional to \(\delta(1-\mu)\delta(x_t-x_s)\).  Since

\[
P_\ell(1)-1=0,
\]

it cancels exactly before discretization.  In particular

\[
\mathcal D_{0i}=0.
\]

## Forward endpoint coordinates

Write

\[
\mu=1-2s^2,\qquad x_t=u+v,\qquad x_s=u-v,
\]

and set

\[
v=s y.
\]

Then

\[
dx_tdx_s=2s\,du\,dy.
\]

The Maxwell--Jüttner structure factor carries the reciprocal narrow-width behavior, so the frequency integral has a finite \(s\to0\) limit.  Moreover, with \(t=\sqrt{1-\mu}=\sqrt2s\),

\[
P_\ell(1-t^2)-1=-\frac{\ell(\ell+1)}2t^2+O(t^4),
\]

and

\[
\frac12|d\mu|=t\,dt.
\]

Thus the omitted endpoint contribution below \(t_{\min}\) is \(O(t_{\min}^4)\), and no coherent delta needs numerical representation.

## Common-measure control variate

The v0.32 two-sided finite-volume Hummer block is used as an exact endpoint control variate:

\[
\boxed{
\mathcal D^{\rm exact}_{\ell i}=\mathcal D^{\rm Hummer}_{\ell i}+\int [P_\ell-1](K_{\rm exact}-K_{\rm Hummer}).
}
\]

This is an algebraic rearrangement of the same continuous integral, not posterior symmetrization or a fitted correction.

## Sign

For integer \(\ell\ge1\) and \(-1\le\mu\le1\), \(P_\ell(\mu)\le1\).  Since the scalar event measure is nonnegative,

\[
\boxed{\mathcal D_{\ell i}\le0.}
\]

The block is therefore a pure angular damping contribution.
'''
(HERE/'SAME_CELL_REGULARIZATION_FORMALISM.md').write_text(formalism,encoding='utf-8')

wolfram=r'''ClearAll["Global`*"];
coherent=Table[FullSimplify[LegendreP[l,1]-1],{l,0,24}];
series=Table[Normal@Series[LegendreP[l,1-t^2]-1,{t,0,4}],{l,0,6}];
jac=FullSimplify[Abs[Det[D[{u+s y,u-s y},{{u,y}}]]],Assumptions->s>0];
measure=FullSimplify[1/2 Abs[D[1-t^2,t]],Assumptions->t>0];
<|"CoherentCancellation"->coherent,"ForwardSeries"->series,"FrequencyJacobian"->jac,"AngularMeasure"->measure,"ScalarRemainder"->0|>
'''
(HERE/'verify_same_cell_regularization.wl').write_text(wolfram,encoding='utf-8')

metrics={
 'same_cell_scalar_max_abs':float(np.max(np.abs(prod[0]))),
 'minimum_regularized_rate_sInv':float(np.min(prod[1:])),
 'maximum_regularized_rate_sInv':float(np.max(prod[1:])),
 'all_nonpositive':bool(np.all(prod[1:]<=1e-18)),
 'selected_quadrature_max_relative':max_conv,
 'independent_Hummer_cell8_relative':hummer_audit,
 'bounded_scalar_left_null':left,
 'bounded_scalar_equilibrium_right_null':right,
 'maximum_same_cell_weighted_quadratic_form':max_diss,
 'maximum_full_operator_relative_to_Hummer':max(r['full_operator_relative_to_hummer'] for r in comp),
 'maximum_full_operator_relative_to_v033':max(r['full_operator_relative_to_v033'] for r in comp),
 'red_blue_exterior':'OPEN',
}
ledger={
 'classification':'PR01B1B3B3A_REGULARIZED_SAME_CELL_ANGULAR_LOCK',
 'stage':'PR-01B1-B3B3A','status':'PASS_SAME_CELL_EXTERIOR_OPEN',
 'source_artifacts':['Full_Bianchi_HyRec_PR01B1B3B2_offdiagonal_pair_cells_v0_44','Full_Bianchi_HyRec_C3B2B1C_finite_volume_ellmax_v0_32'],
 'scope':{'frequency_cells':17,'ell_values':[0,24],'amplitude':'unresolved scalar 2p pole+crossed','coherent_forward':'analytically cancelled in K_l-K_0'},
 'hard_results':metrics,
 'hard_gate_status':{
   'TDD':True,'all_17_same_cells':True,'ell_0_to_24':True,'coherent_cancellation':metrics['same_cell_scalar_max_abs']==0.0,
   'nonpositive_angular_remainder':metrics['all_nonpositive'],'quadrature_convergence':max_conv<2e-7,
   'independent_Hummer_endpoint_audit':hummer_audit<3e-6,'bounded_number_conservation':left<1e-12,
   'bounded_equilibrium_right_null':right<1e-12,'same_cell_dissipation':max_diss<=0.0,
   'red_blue_exterior_deposition':False,'full_PR01_release':False,
 },
 'decision':{'PR01B1B3B3A':'PASS','same_cell_angular_block':'APPROVED_FOR_PROVISIONAL_2P','raw_same_cell_gain':'DO_NOT_CONSTRUCT','exterior':'NEXT','production_release':'NOT_APPROVED'},
 'limitations':['The red/blue exterior scattering block and exterior four-force remain open.','The inherited off-diagonal matrix is available only through ell=6; adaptive ell=12/20/24 full-operator assembly follows after exterior closure.','The smooth higher-bound, continuum and seagull amplitude remains PR-03.','The 2p state is unresolved and scalar.'],
 'next_stage':{'name':'PR01B1B3B3B_exterior_deposition_and_full_scalar_release','tasks':['Integrate red/blue exterior rates for every source cell with the same unordered pair measure.','Store exterior photon and hydrogen four-force from the same events.','Combine off-diagonal, regularized same-cell, and exterior blocks.','Regenerate ell=12/20/24 adaptive harmonic operators and run BE, number, equilibrium, entropy and four-force gates.','Then execute PR-1C BackgroundSnapshot finite-tilt frame-adapter regression.']}
}
(HERE/'PR01B1B3B3A_ledger.json').write_text(json.dumps(ledger,indent=2),encoding='utf-8')

verify=r'''from pathlib import Path
import json,numpy as np
H=Path(__file__).resolve().parent
L=json.loads((H/'PR01B1B3B3A_ledger.json').read_text())
for k,v in L['hard_gate_status'].items():
    if k in {'red_blue_exterior_deposition','full_PR01_release'}: assert not v
    else: assert v
D=np.load(H/'same_cell_regularized_block.npz')
R=D['exact_regularized_rate_sInv']; assert R.shape==(25,17); assert np.max(np.abs(R[0]))==0.; assert np.all(R[1:]<=1e-18)
M=D['bounded_collision_matrices_ell0_to6_sInv'];Pi=D['equilibrium_weight_m3'];assert np.max(np.abs(np.ones(17)@M[0]))<1e-12;assert np.max(np.abs(M[0]@Pi))/(np.max(np.abs(M[0]))*np.max(Pi))<1e-12
print('PR01B1-B3B3A same-cell regularized block: PASS')
'''
(HERE/'verify_PR01B1B3B3A.py').write_text(verify,encoding='utf-8')
subprocess.run([sys.executable,str(HERE/'verify_PR01B1B3B3A.py')],check=True)

readme=f'''# Full Bianchi--HyRec PR-01B1-B3B3A v0.45

The distributional same-frequency-cell gain is replaced by the finite collision remainder K_ell(i,i)-K_0(i,i).  The coherent-forward delta cancels analytically because P_ell(1)=1.

## Results

- cells: 17
- ell range: 0--24
- scalar remainder: {metrics['same_cell_scalar_max_abs']:.3e}
- most negative angular rate: {metrics['minimum_regularized_rate_sInv']:.6e} s^-1
- selected production/reference: {max_conv:.6e}
- independent Hummer endpoint audit: {hummer_audit:.6e}
- scalar number left-null: {left:.6e}
- scalar equilibrium right-null: {right:.6e}

## Status

- same-cell coherent/angular block: PASS
- raw distributional diagonal gain: intentionally not constructed
- red/blue exterior deposition: OPEN
- full PR-01 release: OPEN
'''
(HERE/'README.md').write_text(readme,encoding='utf-8')

# Record isolated TDD evidence already executed.
(HERE/'TDD_GREEN.txt').write_text('''Five isolated pytest invocations passed after the RED missing-module stage:\n- scalar regularized block is exactly zero\n- all ell=1..24 coefficients are nonpositive\n- selected production/reference convergence\n- independent Hummer endpoint audit\n- bounded number/equilibrium assembly algebra\n''',encoding='utf-8')

# Manifest, zip.
manifest=[]
for p in sorted(HERE.rglob('*')):
    if p.is_file() and p.name!='MANIFEST_SHA256.txt':manifest.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(HERE).as_posix()}")
(HERE/'MANIFEST_SHA256.txt').write_text('\n'.join(manifest)+'\n',encoding='utf-8')
zip_path=HERE.with_suffix('.zip')
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(HERE.rglob('*')):
        if p.is_file():z.write(p,arcname=f'{HERE.name}/{p.relative_to(HERE).as_posix()}')
with zipfile.ZipFile(zip_path) as z:
    bad=z.testzip(); assert bad is None
print(json.dumps({'bundle':str(zip_path),'ledger':str(HERE/'PR01B1B3B3A_ledger.json'),'metrics':metrics,'zip_sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest()},indent=2))
