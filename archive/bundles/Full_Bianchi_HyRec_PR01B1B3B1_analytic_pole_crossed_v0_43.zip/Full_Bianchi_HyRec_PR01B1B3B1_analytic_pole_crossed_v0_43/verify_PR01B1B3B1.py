from pathlib import Path
import json
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/'PR01B1B3B1_ledger.json').read_text())
for key,value in ledger['hard_gate_status'].items():
    if key in {'two_sided_frequency_cells','smooth_bound_continuum_background','absolute_pair_kernel'}:
        assert not value
    else:
        assert value
v=pd.read_csv(HERE/'orbit_pole_crossed_validation.csv')
assert len(v)==1836
assert np.max(np.abs(v['slope_antisymmetry_relative']))<1e-12
assert np.all(v['analytic_pole_crossed_total']>0)
print('PR01B1-B3B1 analytic pole+crossed: PASS')
