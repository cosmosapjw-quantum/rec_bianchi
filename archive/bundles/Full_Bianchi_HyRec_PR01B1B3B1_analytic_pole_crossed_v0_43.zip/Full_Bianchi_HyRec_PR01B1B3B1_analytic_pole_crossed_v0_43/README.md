# Full Bianchi-HyRec PR-01B1-B3B1 v0.43

This bundle closes the conditional Gaussian average of the provisional
scalar 2p absorption pole plus crossed time ordering.

## Main results

- 1,836 pole anchors: 2.786660e-13
- crossed-slope identity D=-B: 6.000890e-15
- selected direct quadrature: 7.860379e-14
- 90-digit Faddeeva comparison: 1.950660e-14
- median crossed share of v0.14 pole-subtracted background: 0.552202

The remaining v0.14 background is the expected seagull/higher-bound/
continuum contribution and remains PR-03 scope.

## Status

- analytic pole+crossed Gaussian average: PASS
- amplitude-internal momentum quadrature: superseded for provisional 2p
- two-sided frequency cells: OPEN
- absolute pair kernel: OPEN
