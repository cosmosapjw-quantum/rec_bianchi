ClearAll["Global`*"];

qvec=ps ns-pt nt;
BT=nuS sigma/(M c) (et.ns);
DT=-nuT sigma/(M c) (et.nt);
slopeIdentity=FullSimplify[
 BT+DT,
 Assumptions->{et.qvec==0,ps==h nuS/c,pt==h nuT/c}
];

partialFraction=FullSimplify[
 1/((alpha+B z)(beta+D z))-
 (B/(B beta-D alpha)/(alpha+B z)
 -D/(B beta-D alpha)/(beta+D z))
];

fullExpansion=Expand[
 Abs[a/(A+B z-I gam)+a/(C+D z+I gam)]^2,
 TargetFunctions->{Re,Im}
];

<|
 "CrossedSlopeResidual"->slopeIdentity,
 "PartialFractionResidual"->partialFraction,
 "FullAmplitudeExpansion"->fullExpansion
|>
