# Full Bianchi-HyRec C2d2C2-B orbit cache v0.14

This bundle fills all 1,836 active scalar physics orbits
of the v0.13 17x26 registry and assembles the 93,925
active unordered conductance edges.

## Gates

- integrated amplitude reciprocity: 4.298531e-16
- pointwise amplitude reciprocity: 2.062229e-15
- forward/reverse log-edge residual: 7.105427e-14
- 96/128 to 128/192 quadrature change: 5.520593e-14
- generator left null: 1.646643e-15
- equilibrium right null: 2.216011e-15
- maximum photon-number relative residual: 3.902962e-16
- Route M/C kernel residual: 4.336809e-19

All non-equilibrium test states have non-positive free-energy production.

## Important scope

This is a centre-sampled orbit cache with finite-volume cell measures.
The next stage must integrate the COM-KHW orbit over both frequency-cell
interiors before the scalar Ly-alpha block is called production-ready.

## Files

- orbit_amplitude_cache.csv
- orbit_cache_and_conductance.npz
- operator_action_tests.csv
- state_jump_moments.csv
- quadrature_worst_orbits.csv
- cache_ledger.json
- ORBIT_FORMALISM.md
- verify_cache.py
- MANIFEST_SHA256.txt
