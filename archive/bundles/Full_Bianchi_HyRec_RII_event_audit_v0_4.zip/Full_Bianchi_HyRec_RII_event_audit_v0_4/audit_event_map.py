"""
Audit identities for Full Bianchi–HyRec Ly-alpha scalar RII.

The key exact frame identity is

    D_in * (nu_out_star/nu_in_star) * D_out^-1
        = nu_out/nu_in,

where D = gamma(1-beta.n).  D_in is the proper-density
incident flux factor and D_out^-1 is the Jacobian of
dnu_star dOmega_star relative to dnu dOmega.

For a finite-state monolithic rate K[a,b],

    Gamma[b] = sum_a K[a,b]
    P[a,b] = K[a,b]/Gamma[b]

gives the exactly equivalent conditional representation.
"""

from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
data = np.load(HERE / "routeM_routeC_factorization.npz")

K = data["monolithic_rate_table"]
Gamma = data["opacity_column_sum"]
P = data["conditional_redistribution"]
G = data["generator"]

assert np.all(Gamma > 0.0)
assert np.min(P) >= 0.0
assert np.max(np.abs(P.sum(axis=0) - 1.0)) < 1.0e-12
assert np.max(np.abs(K - Gamma[None, :] * P)) < 1.0e-12

G2 = K.copy()
np.fill_diagonal(G2, 0.0)
np.fill_diagonal(G2, -G2.sum(axis=0))
assert np.max(np.abs(G2 - G)) < 1.0e-12

print("Route M / Route C factorization: PASS")
