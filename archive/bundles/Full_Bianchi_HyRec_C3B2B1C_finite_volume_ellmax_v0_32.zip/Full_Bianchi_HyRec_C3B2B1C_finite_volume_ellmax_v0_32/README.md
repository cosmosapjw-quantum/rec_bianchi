# Full Bianchi-HyRec C3B2B1-C v0.32

This bundle removes incoming-frequency centre sampling, constructs the
two-sided finite-volume Hummer-II Legendre kernel through ell=32, and
locks an adaptive ellmax policy.

## Main results

- two-cell formula validation: 4.765198e-14
- production/reference quadrature: 6.529044e-11
- photon-number residual: 2.999242e-16
- harmonic transform Gram residual: 2.897682e-14
- harmonic transform round trip: 4.161979e-15

## Measured minimum ellmax at 1e-5

- finite tilt beta=0.3: L=8
- mixed tilt/shear: L=12
- nonlinear even shear: L=18
- directional red/blue crossing: L=24

The padded operating policy is L=12, 12, 20 and 24 respectively.
A universal L=12 release is rejected.
