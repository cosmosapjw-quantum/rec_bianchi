from pathlib import Path
import subprocess
HERE=Path(__file__).resolve().parent
subprocess.run(["python",str(HERE/"verify_C3B2B1C.py")],check=True)
