from pathlib import Path
import json
import numpy as np
HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/"C3B2B1C_ledger.json").read_text())
for key,value in ledger["hard_gate_status"].items():
    if key=="ellmax_12_universal":
        assert value is False
    else:
        assert value
data=np.load(HERE/"finite_volume_legendre_kernel.npz")
K=data["dimensionless_legendre_kernel"]
assert K.shape==(33,17,17)
assert np.all(np.isfinite(K))
assert np.min(K[0])>=0.0
assert np.max(np.abs(K[0]-K[0].T))<1e-14
assert np.all(data["capture_fraction"]<=1.0+1e-12)
print("C3B2B1-C finite-volume and ellmax: PASS")
