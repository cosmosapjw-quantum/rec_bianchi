# 02 EVIDENCE ACQUISITION

PR-05C1 keeps canonical history macro surfaces fixed, verifies adaptive internal transaction semantics, and leaves full coupled physics to PR-05C2.
