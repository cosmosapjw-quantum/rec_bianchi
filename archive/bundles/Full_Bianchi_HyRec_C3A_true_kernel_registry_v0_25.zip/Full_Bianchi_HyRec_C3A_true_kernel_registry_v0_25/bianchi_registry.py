"""Canonical Bianchi structure-constant registry helpers.

Convention:
 C^a_bc = epsilon_bcd n^{da} + delta^a_c a_b-delta^a_b a_c.
"""
from __future__ import annotations
import numpy as np


def structure_constants(a_vec, nmat):
    eps = np.zeros((3,3,3))
    eps[0,1,2]=eps[1,2,0]=eps[2,0,1]=1.0
    eps[0,2,1]=eps[2,1,0]=eps[1,0,2]=-1.0
    C=np.zeros((3,3,3))
    for o in range(3):
        for i in range(3):
            for j in range(3):
                C[o,i,j]=sum(eps[i,j,d]*nmat[d,o] for d in range(3))
                C[o,i,j]+=(1.0 if o==j else 0.0)*a_vec[i]
                C[o,i,j]-=(1.0 if o==i else 0.0)*a_vec[j]
    return C


def koszul_connection(C):
    G=np.zeros((3,3,3))
    for g in range(3):
        for b in range(3):
            for a in range(3):
                G[g,b,a]=0.5*(C[g,a,b]-C[a,b,g]+C[b,g,a])
    return G


def lie_direction_drift(G, direction):
    return -np.einsum('gba,a,b->g',G,direction,direction)
