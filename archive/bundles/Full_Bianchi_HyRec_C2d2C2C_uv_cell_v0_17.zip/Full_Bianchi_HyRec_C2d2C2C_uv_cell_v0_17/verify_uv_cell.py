from pathlib import Path
import numpy as np
D=np.load(Path(__file__).resolve().parent/'uv_cell_conductance.npz');Pi=D['equilibrium_cell_weight']
for k in ['pole_conductance_production','full_conductance_production','pole_conductance_reference','full_conductance_reference']:
 S=D[k];assert np.max(np.abs(S-S.T))<1e-13;assert np.min(S)>=0
for k in ['pole_generator_production','full_generator_production','pole_generator_reference','full_generator_reference']:
 G=D[k];assert np.max(np.abs(np.ones(G.shape[0])@G))<1e-10;assert np.max(np.abs(G@Pi))<1e-10
print('UV backscatter cell release gate: PASS')
