# UV backscatter cell integration v0.17

- full conductance production vs reference: 7.596398e-08
- worst orbit reference vs high check: 1.983540e-06
- nonbackscatter GL12 vs GL16 spot check: 7.284169e-10
