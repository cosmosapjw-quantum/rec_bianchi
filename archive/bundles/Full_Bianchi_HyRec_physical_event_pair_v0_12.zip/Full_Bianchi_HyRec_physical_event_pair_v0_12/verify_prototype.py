"""
Basic invariant checks for physical_event_pair_tables.npz.
"""

from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
data = np.load(HERE / "physical_event_pair_tables.npz")

S = data["full_conductance"]
G = data["full_generator"]
Pi = data["equilibrium_weight"]
K = S / Pi[None, :]
Gamma = data["full_opacity"]
P = data["full_conditional"]

assert np.max(np.abs(S-S.T)) < 1e-12
assert np.max(np.abs(np.ones(G.shape[0]) @ G)) < 1e-12
assert np.max(np.abs(G @ Pi)) < 1e-12
assert np.max(np.abs(P.sum(axis=0)-1.0)) < 1e-12
assert np.max(np.abs(K-Gamma[None,:]*P)) < 1e-12

print("physical scalar full-angle event-pair prototype: PASS")
