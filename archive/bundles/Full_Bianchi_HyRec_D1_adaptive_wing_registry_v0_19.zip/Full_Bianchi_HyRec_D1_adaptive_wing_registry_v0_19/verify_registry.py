from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
d=np.load(p/'adaptive_wing_registry.npz')
assert len(d['x_centers'])==29
assert np.allclose(d['x_edges'],-d['x_edges'][::-1])
assert len(d['state_frequency_index'])==754
assert len(d['edge_a'])==283881
assert d['recommended_active'].sum()==273325
assert np.all(d['new_core_state']==26*(d['old_core_state']//26+6)+d['old_core_state']%26)
print('adaptive wing registry: PASS')
