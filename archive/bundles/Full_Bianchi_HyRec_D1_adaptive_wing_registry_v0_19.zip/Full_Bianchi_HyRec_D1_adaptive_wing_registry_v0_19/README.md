# Full Bianchi-HyRec D1 adaptive wing registry v0.19

This geometry-only artifact embeds the immutable 17-cell v0.17 core in a symmetric 29-cell mesh extending to |x|=10.25.

- states: 754
- unordered edges: 283,881
- active edges: 273,325
- physics orbits: 5,626
- old core frequency indices map to new indices 6..22

No new amplitudes or conductances are claimed in this bundle.
