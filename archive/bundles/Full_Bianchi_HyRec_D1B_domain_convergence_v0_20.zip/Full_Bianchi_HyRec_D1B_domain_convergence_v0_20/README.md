# D1B domain convergence v0.20

New orbits: 3384
Matrix quadrature difference: 1.058370e-16
Max non-BE domain action difference: 3.469220e-01
Decision: FAIL
