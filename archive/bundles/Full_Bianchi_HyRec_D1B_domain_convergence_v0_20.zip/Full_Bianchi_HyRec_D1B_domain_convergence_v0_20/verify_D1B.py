from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent;d=np.load(p/'D1B_conductance.npz');S=d['full29_conductance_high'];G=d['full29_generator'];Pi=d['equilibrium_weight'];assert np.max(abs(S-S.T))<1e-12;assert np.max(abs(np.ones(G.shape[0])@G))<1e-10;assert np.max(abs(G@Pi))<1e-10;print('D1B invariants: PASS')
