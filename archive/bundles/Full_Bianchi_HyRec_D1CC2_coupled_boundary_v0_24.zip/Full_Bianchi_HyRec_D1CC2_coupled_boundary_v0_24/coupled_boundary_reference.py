from __future__ import annotations
import numpy as np

def gamma(beta):
    return 1.0/np.sqrt(1.0-np.dot(beta,beta))

def doppler_factor(beta,direction):
    return gamma(beta)*(1.0-np.dot(beta,direction))

def dlog_doppler(beta,beta_dot,direction,direction_dot):
    G=gamma(beta)
    return (
        G**2*np.dot(beta,beta_dot)
        -(np.dot(beta_dot,direction)+np.dot(beta,direction_dot))
        /(1.0-np.dot(beta,direction))
    )

def hydrogen_frequency_characteristic(
    R_normal,beta,beta_dot,direction,direction_dot
):
    return R_normal+dlog_doppler(
        beta,beta_dot,direction,direction_dot
    )

def positive_part(value):
    return np.maximum(value,0.0)

def red_flux(speed,interior,red_exterior):
    return positive_part(-speed)*interior-positive_part(speed)*red_exterior

def blue_flux(speed,interior,blue_exterior):
    return positive_part(speed)*interior-positive_part(-speed)*blue_exterior
