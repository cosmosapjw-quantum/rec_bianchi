# Full Bianchi-HyRec C3B2B1A v0.30

This bundle regenerates an absolutely normalized angle-dependent
Hummer-II two-level reference on the 17-cell Ly-alpha core and tests
Lebedev orders 26 through 302 points.

## Physical scale

- line-centre opacity at n1s=250 cm^-3: 8.062697185855e-01 s^-1
- integrated cross section: 1.104589773129e-06 m^2 Hz

## Main finding

The coherent forward limit creates a narrow angular-frequency boundary
layer. Raw Lebedev convergence is slow and non-monotone; point-count
inflation alone is not accepted as the final production strategy.

This is a physical Hummer-II reference, not yet the full COM-KHW,
recoil, stimulated, detailed-balance-completed operator.
