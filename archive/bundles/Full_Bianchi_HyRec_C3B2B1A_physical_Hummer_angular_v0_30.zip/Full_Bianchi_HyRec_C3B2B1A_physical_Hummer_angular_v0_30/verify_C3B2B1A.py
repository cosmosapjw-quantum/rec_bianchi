from pathlib import Path
import json
import numpy as np

HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/'C3B2B1A_ledger.json').read_text())
assert ledger['hard_gate_status']['absolute_two_level_rate']
assert ledger['hard_gate_status']['RII_frequency_normalization']
assert ledger['hard_gate_status']['number_conservation_truncated_operator']
assert not ledger['hard_gate_status']['full_COM_KHW_physical_kernel']
data=np.load(HERE/'physical_Hummer_angular_audit.npz')
assert data['x_centers'].shape == (17,)
assert data['physical_opacity_s^-1'][8] > 0.0
print('C3B2B1A physical Hummer angular audit: PASS')
