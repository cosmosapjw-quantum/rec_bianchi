{
  "all_macro_lanes_converged": true,
  "classification": "PR05C2B_NUMERICAL_METRICS",
  "completion_class": "PASS_EXPLICIT_CLOSURE_WITH_UNCERTAINTY",
  "face_reconstruction_no_new_extrema": true,
  "harmonic_reason": "Harmonic block reduced Newton iterations but increased GMRES iterations and wall time on the locked z~1100 reference; diagonal/AP remains production and dense-batched is the hot-lane exact reference.",
  "harmonic_selected": false,
  "macro_lane_count": 9,
  "maximum_angular_monopole_residual": 1.5746698203986192e-16,
  "maximum_collision_entropy_production": -2.0082063333026803e-08,
  "maximum_collision_four_force_residual": 0.0,
  "maximum_direct_thermodynamic_closure_discrepancy": 0.30528993146949396,
  "maximum_interface_atom_source_abs": 0.0,
  "maximum_macro_energy_residual": 1.5492554592789343e-13,
  "maximum_macro_gross_backward_error": 9.02914974419302e-14,
  "maximum_macro_jvp_residual": 3.1190785809695545e-10,
  "maximum_macro_number_residual": 5.0631318336812805e-15,
  "minimum_angular_occupation": 3.9257934119511183e-16,
  "minimum_macro_occupation": 1.3498620726626376e-21,
  "multi_macro_trajectory_completed": false,
  "muscl_minimum_refinement_ratio": 3.7961196172750875,
  "no_fitted_normalization": true,
  "performance": {
    "action_only_median_s": 0.0009004499997899984,
    "dense_assembly_speedup": 1.5305611119218634,
    "dense_batched_assembly_s": 0.8981288400000267,
    "dense_matrix_relative_difference": 3.876584386397876e-27,
    "dense_scalar_column_assembly_s": 1.3746410759995342,
    "pair_loop_full_median_s": 0.04841360899990832,
    "pair_loop_jvp_median_s": 0.04275559899997461,
    "samples": {
      "action_only": [
        0.000752855999962776,
        0.0009004499997899984,
        0.0007235560005938169,
        0.0009560690004946082,
        0.0009525449995635427,
        0.0013379150004766416,
        0.0007223460006571258
      ],
      "pair_loop_full": [
        0.04841360899990832,
        0.05686953700023878,
        0.04081172800033528
      ],
      "pair_loop_jvp": [
        0.042400923000059265,
        0.04275559899997461,
        0.04501545799939777
      ],
      "vectorized_full": [
        0.00629611299973476,
        0.002187856000091415,
        0.001817612999730045,
        0.0019015520001630648,
        0.0017858129995147465
      ],
      "vectorized_jvp": [
        0.002081157000247913,
        0.001837504999457451,
        0.0016024669994294527,
        0.0012177859998701024,
        0.0011565180002435227,
        0.0011394779994589044,
        0.0011242629998378106
      ]
    },
    "speedup_action_only_vs_pair_loop": 53.76601589338583,
    "speedup_vectorized_full_vs_pair_loop": 25.460049999030623,
    "speedup_vectorized_jvp_vs_pair_loop": 35.10928767824168,
    "vectorized_full_median_s": 0.0019015520001630648,
    "vectorized_jvp_median_s": 0.0012177859998701024
  },
  "source_identical_angular_reconstruction": false,
  "source_identical_thermodynamic_recompilation": false,
  "status": "PASS_EXPLICIT_CLOSURE_WITH_UNCERTAINTY_OPTIMIZED_CANONICAL_MACRO_REFERENCE_PR05C2C_NEXT"
}
