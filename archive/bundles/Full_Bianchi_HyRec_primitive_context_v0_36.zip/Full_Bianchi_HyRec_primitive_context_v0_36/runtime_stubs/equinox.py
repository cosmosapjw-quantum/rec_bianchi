from __future__ import annotations
from dataclasses import dataclass, field as dc_field, fields


def field(*, converter=None, **kwargs):
    metadata = dict(kwargs.pop("metadata", {}) or {})
    metadata["converter"] = converter
    return dc_field(metadata=metadata, **kwargs)


class Module:
    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        dataclass(eq=False, repr=True)(cls)

    def __post_init__(self):
        for item in fields(self):
            converter = item.metadata.get("converter")
            if converter is not None:
                object.__setattr__(
                    self,
                    item.name,
                    converter(getattr(self, item.name)),
                )


def filter_jit(fn=None, **kwargs):
    if fn is None:
        return lambda function: function
    return fn
