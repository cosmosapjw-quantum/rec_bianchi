from pathlib import Path
import csv,json,numpy as np
HERE=Path(__file__).resolve().parent
runs=list(csv.DictReader((HERE/'background_runs.csv').open()))
assert len(runs)==7 and all(r['success']=='True' for r in runs)
ix=next(r for r in runs if r['model']=='IX_isotropic_closed_dust')
assert float(ix['event_time'])>0 and abs(float(ix['Hbar_final']))<1e-8
recomb=list(csv.DictReader((HERE/'recombination_reference.csv').open()))
assert len(recomb)==3
data=np.load(HERE/'background_timeseries.npz')
assert data['VI0_state'].shape[1]==5
assert data['tilted_state'].shape[1]==11
assert data['IX_state'].shape[1]==7
inventory=json.loads((HERE/'primitive_inventory.json').read_text())
assert inventory['python_module_count']>=80
assert inventory['test_module_count']>=60
print('primitive background context artifact: PASS')
