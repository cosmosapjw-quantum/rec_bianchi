from pathlib import Path
import json
import numpy as np

HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/"C3B2B1D0_ledger.json").read_text())

for key,value in ledger["hard_gate_status"].items():
    if key in {
        "exact_COM_recoil_event",
        "anisotropic_nonlinear_stimulation",
    }:
        assert not value
    else:
        assert value

data=np.load(HERE/"thermodynamic_completed_kernel.npz")
W=data["completed_rate_sInv"][0]
Pi=data["dilute_equilibrium_weight_m3"]
assert np.max(
    np.abs(W*Pi[None,:]-W.T*Pi[:,None])
) / np.max(np.abs(W*Pi[None,:])) < 1e-14

assert np.all(data["mode_measure_m3"] > 0)
assert np.all(data["cell_activity"] > 0)

print("C3B2B1-D0 thermodynamic completion: PASS")
