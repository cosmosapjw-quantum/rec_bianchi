from pathlib import Path
import json
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/"PR01B1B2_ledger.json").read_text())

for key,value in ledger["hard_gate_status"].items():
    if key in {
        "v039_missing_Jacobian_claim",
        "selected_pair_statistical_rejection",
        "full_invariant_17x17_kernel",
        "resonance_adapted_amplitude_integral",
    }:
        assert not value
    else:
        assert value

pair=pd.read_csv(HERE/"invariant_pair_measure_audit.csv")
assert np.max(np.abs(pair["conductance_log_residual"])) < 5e-13

jac=pd.read_csv(HERE/"event_map_jacobian_audit.csv")
assert np.max(np.abs(jac["relative_residual"])) < 1e-5

print("PR01B1-B2 invariant pair measure: PASS")
