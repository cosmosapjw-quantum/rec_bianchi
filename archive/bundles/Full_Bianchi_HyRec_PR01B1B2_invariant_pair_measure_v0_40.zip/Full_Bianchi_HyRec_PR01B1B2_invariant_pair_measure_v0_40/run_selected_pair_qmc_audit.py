from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE / "workspace"
sys.path.insert(0, str(WORKSPACE / "src"))

from full_bianchi_hyrec.recoil.thermal_deposition import (  # noqa: E402
    DepositionConfig,
    _sample_seed,
)


def histogram(values, cells, valid, size):
    return np.bincount(
        cells[valid], weights=values[valid], minlength=size
    )


def main():
    reference = np.load(
        WORKSPACE / "data" / "full_hummer_reference.npz"
    )
    v039 = np.load(
        HERE.parent
        / "Full_Bianchi_HyRec_PR01B1B1_full_frequency_harmonic_v0_39"
        / "full_frequency_harmonic_deposition.npz"
    )

    x_edges = reference["x_edges"]
    x_centers = reference["x_centers"]
    hummer = reference["physical_gain_sInv"][0]
    Pi = reference["equilibrium_weight_m3"]
    raw = v039["harmonic_gain_sInv"][0]
    n_frequency = len(x_centers)

    source_cells = (6, 7, 8, 9, 10)
    seeds = (501, 502, 503, 504, 505, 506, 507, 508)
    power = 19

    exact_samples = {}
    baseline_samples = {}
    corrected_samples = {}

    for source in source_cells:
        exact_columns = []
        baseline_columns = []

        config = DepositionConfig(
            temperature_K=3000.0,
            n1s_cm3=250.0,
            source_x_left=float(x_edges[source]),
            source_x_right=float(x_edges[source + 1]),
            sobol_power=power,
            seeds=seeds,
            gaussian_mixture_weight=0.5,
            cauchy_scale_factor=1.0,
            cauchy_truncation_sigma=12.0,
        )
        sampler_reference = {
            "x_edges": x_edges,
            "x_centers": x_centers,
        }

        for seed in seeds:
            sample = _sample_seed(
                config, int(seed), sampler_reference
            )
            exact = sample["exact_weight"]
            baseline = sample["baseline_weight"]
            count = len(exact)

            exact_valid = (
                (sample["cell_exact"] >= 0)
                & (sample["cell_exact"] < n_frequency)
            )
            baseline_valid = (
                (sample["cell_baseline"] >= 0)
                & (sample["cell_baseline"] < n_frequency)
            )

            exact_column = histogram(
                exact,
                sample["cell_exact"],
                exact_valid,
                n_frequency,
            ) / count
            baseline_column = histogram(
                baseline,
                sample["cell_baseline"],
                baseline_valid,
                n_frequency,
            ) / count

            exact_columns.append(exact_column)
            baseline_columns.append(baseline_column)

        exact_samples[source] = np.asarray(exact_columns)
        baseline_samples[source] = np.asarray(baseline_columns)
        corrected_samples[source] = (
            hummer[:, source][None, :]
            + exact_samples[source]
            - baseline_samples[source]
        )

    selected_pairs = (
        (7, 9),
        (8, 9),
        (6, 9),
        (7, 8),
        (6, 7),
        (6, 8),
        (7, 10),
        (9, 10),
    )

    rows = []
    for i, j in selected_pairs:
        # K_{i<-j} and K_{j<-i}
        for estimator, samples in (
            ("direct_exact", exact_samples),
            ("sampled_no_recoil", baseline_samples),
            ("control_variate", corrected_samples),
        ):
            left = samples[j][:, i] * Pi[j]
            right = samples[i][:, j] * Pi[i]

            left_mean = float(left.mean())
            right_mean = float(right.mean())
            left_se = float(left.std(ddof=1) / math.sqrt(len(left)))
            right_se = float(right.std(ddof=1) / math.sqrt(len(right)))
            difference = left_mean - right_mean
            combined_se = math.sqrt(left_se**2 + right_se**2)
            mean = 0.5 * (left_mean + right_mean)

            rows.append(
                {
                    "i": i,
                    "j": j,
                    "x_i": float(x_centers[i]),
                    "x_j": float(x_centers[j]),
                    "estimator": estimator,
                    "left_conductance": left_mean,
                    "right_conductance": right_mean,
                    "relative_difference": difference / mean,
                    "combined_standard_error": combined_se,
                    "significance": difference / combined_se,
                    "sobol_power": power,
                    "seed_count": len(seeds),
                }
            )

        raw_left = float(raw[i, j] * Pi[j])
        raw_right = float(raw[j, i] * Pi[i])
        raw_mean = 0.5 * (raw_left + raw_right)
        rows.append(
            {
                "i": i,
                "j": j,
                "x_i": float(x_centers[i]),
                "x_j": float(x_centers[j]),
                "estimator": "v039_raw",
                "left_conductance": raw_left,
                "right_conductance": raw_right,
                "relative_difference": (
                    raw_left - raw_right
                ) / raw_mean,
                "combined_standard_error": float("nan"),
                "significance": float("nan"),
                "sobol_power": 17,
                "seed_count": 8,
            }
        )

    with (HERE / "selected_pair_highres_qmc.csv").open(
        "w", newline="", encoding="utf-8"
    ) as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(rows[0].keys())
        )
        writer.writeheader()
        writer.writerows(rows)

    summary = {
        "sources": list(source_cells),
        "pairs": [list(pair) for pair in selected_pairs],
        "sobol_power": power,
        "seed_count": len(seeds),
        "events_per_source": len(seeds) * 2**power,
        "maximum_absolute_significance": {
            estimator: max(
                abs(row["significance"])
                for row in rows
                if row["estimator"] == estimator
                and np.isfinite(row["significance"])
            )
            for estimator in (
                "direct_exact",
                "sampled_no_recoil",
                "control_variate",
            )
        },
    }
    (HERE / "selected_pair_highres_qmc_summary.json").write_text(
        json.dumps(summary, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
