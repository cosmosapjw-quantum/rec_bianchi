from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.constants import c, h, k, physical_constants

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE / "workspace"
sys.path.insert(0, str(WORKSPACE / "src"))

from full_bianchi_hyrec.recoil.invariant_pair_measure import (  # noqa: E402
    invariant_pair_conductance_log,
    log_maxwell_boltzmann_structure_factor,
    log_maxwell_juttner_structure_factor,
    photon_pair_invariants,
)


M_H = physical_constants["atomic mass constant"][0] * 1.00782503223
NU_ALPHA = c / (1215.6701e-10)
T = 3000.0
EPSILON_ALPHA = h * NU_ALPHA / (M_H * c**2)
THETA = k * T / (M_H * c**2)
ALPHA = h * NU_ALPHA / (k * T)


def gamma_beta(beta):
    return 1.0 / math.sqrt(1.0 - float(beta @ beta))


def boost_photon(ratio, direction, beta):
    gamma = gamma_beta(beta)
    bn = float(beta @ direction)
    doppler = gamma * (1.0 - bn)
    beta2 = float(beta @ beta)
    if beta2 == 0.0:
        return ratio, direction.copy()

    transformed = (
        direction
        + (
            (gamma - 1.0) * bn / beta2
            - gamma
        )
        * beta
    ) / doppler
    transformed /= np.linalg.norm(transformed)
    return ratio * doppler, transformed


def inverse_boost_photon(ratio, direction, beta):
    return boost_photon(ratio, direction, -beta)


def atom_four(beta):
    gamma = gamma_beta(beta)
    return np.concatenate(([gamma], gamma * beta))


def photon_four(ratio, direction):
    return EPSILON_ALPHA * ratio * np.concatenate(([1.0], direction))


def beta_from_atom(momentum):
    return momentum[1:] / momentum[0]


def sphere_direction(theta, phi):
    return np.array(
        [
            math.sin(theta) * math.cos(phi),
            math.sin(theta) * math.sin(phi),
            math.cos(theta),
        ]
    )


def sphere_angles(direction):
    direction = direction / np.linalg.norm(direction)
    theta = math.acos(float(np.clip(direction[2], -1.0, 1.0)))
    phi = math.atan2(direction[1], direction[0])
    if phi < 0.0:
        phi += 2.0 * math.pi
    return theta, phi


def screen_basis(direction):
    reference = np.array([1.0, 0.0, 0.0])
    if abs(direction[0]) > 0.85:
        reference = np.array([0.0, 1.0, 0.0])
    e1 = np.cross(direction, reference)
    e1 /= np.linalg.norm(e1)
    e2 = np.cross(direction, e1)
    return e1, e2


def outgoing_direction(incoming, mu, azimuth):
    e1, e2 = screen_basis(incoming)
    sine = math.sqrt(max(0.0, 1.0 - mu * mu))
    result = (
        mu * incoming
        + sine
        * (
            math.cos(azimuth) * e1
            + math.sin(azimuth) * e2
        )
    )
    return result / np.linalg.norm(result)


def scattering_angles(incoming, outgoing):
    mu = float(np.clip(incoming @ outgoing, -1.0, 1.0))
    e1, e2 = screen_basis(incoming)
    perpendicular = outgoing - mu * incoming
    if np.linalg.norm(perpendicular) < 1.0e-14:
        return mu, 0.0
    azimuth = math.atan2(
        float(perpendicular @ e2),
        float(perpendicular @ e1),
    )
    if azimuth < 0.0:
        azimuth += 2.0 * math.pi
    return mu, azimuth


def event_map(parameters):
    """
    Full 8D map:
      (nu ratio, beta_i, incoming theta/phi, mu*, azimuth*)
    to PT-reversed initial variables.
    """
    ratio = float(parameters[0])
    beta = np.asarray(parameters[1:4], dtype=float)
    theta = float(parameters[4])
    phi = float(parameters[5])
    mu = float(parameters[6])
    azimuth = float(parameters[7])

    incoming_lab = sphere_direction(theta, phi)
    incoming_rest_ratio, incoming_rest = boost_photon(
        ratio, incoming_lab, beta
    )
    outgoing_rest = outgoing_direction(
        incoming_rest, mu, azimuth
    )
    outgoing_rest_ratio = incoming_rest_ratio / (
        1.0
        + EPSILON_ALPHA
        * incoming_rest_ratio
        * (1.0 - mu)
    )
    outgoing_ratio, outgoing_lab = inverse_boost_photon(
        outgoing_rest_ratio, outgoing_rest, beta
    )

    initial_atom = atom_four(beta)
    initial_photon = photon_four(ratio, incoming_lab)
    final_photon = photon_four(outgoing_ratio, outgoing_lab)
    final_atom = initial_atom + initial_photon - final_photon

    reverse_beta = -beta_from_atom(final_atom)
    reverse_incoming = -outgoing_lab
    reverse_outgoing = -incoming_lab
    reverse_theta, reverse_phi = sphere_angles(reverse_incoming)

    reverse_in_rest_ratio, reverse_in_rest = boost_photon(
        outgoing_ratio, reverse_incoming, reverse_beta
    )
    _, reverse_out_rest = boost_photon(
        ratio, reverse_outgoing, reverse_beta
    )
    reverse_mu, reverse_azimuth = scattering_angles(
        reverse_in_rest, reverse_out_rest
    )

    return np.array(
        [
            outgoing_ratio,
            *reverse_beta,
            reverse_theta,
            reverse_phi,
            reverse_mu,
            reverse_azimuth,
        ],
        dtype=float,
    )


def numerical_jacobian(function, parameters):
    parameters = np.asarray(parameters, dtype=float)
    steps = np.array(
        [2e-7, 2e-8, 2e-8, 2e-8, 2e-7, 2e-7, 2e-7, 2e-7]
    )
    matrix = np.zeros((8, 8))

    for column in range(8):
        plus = parameters.copy()
        minus = parameters.copy()
        plus[column] += steps[column]
        minus[column] -= steps[column]
        forward = function(plus)
        backward = function(minus)
        difference = forward - backward

        for angle_index in (5, 7):
            difference[angle_index] = (
                difference[angle_index] + math.pi
            ) % (2.0 * math.pi) - math.pi

        matrix[:, column] = difference / (2.0 * steps[column])

    return matrix


def log_mj_beta_density(beta):
    gamma = gamma_beta(beta)
    # Normalization cancels in the Jacobian ratio.
    return -(gamma - 1.0) / THETA + 5.0 * math.log(gamma)


def log_equilibrium_parameter_measure(parameters):
    ratio = float(parameters[0])
    beta = np.asarray(parameters[1:4], dtype=float)
    theta = float(parameters[4])
    mu = float(parameters[6])
    incoming = sphere_direction(theta, float(parameters[5]))

    flux = 1.0 - float(beta @ incoming)
    phase = 3.0 / 8.0 * (1.0 + mu * mu)

    return (
        2.0 * math.log(ratio)
        + math.log(math.sin(theta))
        + log_mj_beta_density(beta)
        + math.log(flux)
        + math.log(phase)
        - ALPHA * ratio
    )


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(rows[0].keys())
        )
        writer.writeheader()
        writer.writerows(rows)


def main():
    rng = np.random.default_rng(20260804)
    jacobian_rows = []

    for event_id in range(48):
        beta = rng.normal(size=3)
        beta *= rng.uniform(0.2, 4.0) * math.sqrt(THETA)
        parameters = np.array(
            [
                rng.uniform(0.99990, 1.00010),
                *beta,
                rng.uniform(0.35, 2.75),
                rng.uniform(0.2, 5.8),
                rng.uniform(-0.8, 0.8),
                rng.uniform(0.2, 5.8),
            ]
        )
        reverse = event_map(parameters)
        jacobian = numerical_jacobian(event_map, parameters)
        determinant = abs(float(np.linalg.det(jacobian)))
        expected = math.exp(
            log_equilibrium_parameter_measure(parameters)
            - log_equilibrium_parameter_measure(reverse)
        )
        relative = determinant / expected - 1.0

        jacobian_rows.append(
            {
                "event_id": event_id,
                "beta_norm": float(np.linalg.norm(beta)),
                "frequency_ratio_in": float(parameters[0]),
                "frequency_ratio_out": float(reverse[0]),
                "mu_rest": float(parameters[6]),
                "jacobian_absolute": determinant,
                "equilibrium_measure_ratio": expected,
                "relative_residual": relative,
            }
        )

    write_csv(HERE / "event_map_jacobian_audit.csv", jacobian_rows)

    # Relativistic structure-factor and conductance audits.
    x_values = (-3.5, -1.0, -0.5, 0.0, 0.5, 1.0, 3.5)
    mus = (-0.75, -0.25, 0.25, 0.75)
    pair_rows = []
    delta_nu = NU_ALPHA * math.sqrt(2.0 * THETA)

    for x_source in x_values:
        for x_target in x_values:
            if x_target >= x_source:
                continue
            nu_source = NU_ALPHA + x_source * delta_nu
            nu_target = NU_ALPHA + x_target * delta_nu

            for mu in mus:
                invariants = photon_pair_invariants(
                    nu_source, nu_target, mu, M_H
                )
                log_forward = invariant_pair_conductance_log(
                    nu_source_hz=nu_source,
                    nu_target_hz=nu_target,
                    mu=mu,
                    mass_kg=M_H,
                    temperature_K=T,
                    amplitude_average=1.0,
                )
                log_reverse = invariant_pair_conductance_log(
                    nu_source_hz=nu_target,
                    nu_target_hz=nu_source,
                    mu=mu,
                    mass_kg=M_H,
                    temperature_K=T,
                    amplitude_average=1.0,
                )
                log_mj = log_maxwell_juttner_structure_factor(
                    invariants.q_dimensionless,
                    invariants.delta_dimensionless,
                    M_H,
                    T,
                )
                log_mb = log_maxwell_boltzmann_structure_factor(
                    invariants.q_dimensionless,
                    invariants.delta_dimensionless,
                    M_H,
                    T,
                )

                pair_rows.append(
                    {
                        "x_source": x_source,
                        "x_target": x_target,
                        "mu": mu,
                        "q_dimensionless": invariants.q_dimensionless,
                        "delta_dimensionless": invariants.delta_dimensionless,
                        "log_conductance_forward": log_forward,
                        "log_conductance_reverse": log_reverse,
                        "conductance_log_residual": log_forward - log_reverse,
                        "log_S_MJ_minus_log_S_MB": log_mj - log_mb,
                    }
                )

    write_csv(HERE / "invariant_pair_measure_audit.csv", pair_rows)

    print(
        json.dumps(
            {
                "jacobian_event_count": len(jacobian_rows),
                "maximum_jacobian_relative": max(
                    abs(row["relative_residual"])
                    for row in jacobian_rows
                ),
                "pair_count": len(pair_rows),
                "maximum_conductance_log_residual": max(
                    abs(row["conductance_log_residual"])
                    for row in pair_rows
                ),
                "maximum_relativistic_MB_log_difference": max(
                    abs(row["log_S_MJ_minus_log_S_MB"])
                    for row in pair_rows
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
