"""
Conditional exact-event audit for scalar Ly-alpha RII.

Core formulas:

  P(u_parallel|x) =
    a exp(-u^2) /
    [pi H(a,x)((x-u)^2+a^2)]

  nu_out_star =
    nu_in_star /
    [1 + h nu_in_star/(m_H c^2) (1-mu_star)]

Incoming and outgoing photons are related to the hydrogen-fluid
frame by exact Lorentz boosts.  The event weight is

  w_event = w_velocity w_angle D_in
            (nu_out_star/nu_in_star).

The Meiksin comparison map is evaluated on the same exact outgoing
lab direction:

  x_out^M =
    x_in + u.(n_out-n_in)
    - epsilon_D(1-n_in.n_out).

See conditional_event_ledger.json for equations, residuals, and
the complete numerical table.
"""
