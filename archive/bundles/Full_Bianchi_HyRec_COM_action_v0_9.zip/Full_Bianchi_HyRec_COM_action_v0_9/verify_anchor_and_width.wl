ClearAll["Global`*"];
eabs = 1-Sqrt[1-2 e0];
eem  = -1+Sqrt[1+2 e0];

{
 Normal@Series[eabs,{e0,0,4}],
 Normal@Series[eem,{e0,0,4}],
 FullSimplify[e0-eabs+eabs^2/2],
 FullSimplify[e0-eem-eem^2/2]
}

term = -(f d/2) (1/(d-w-I g)+1/(d+w+I g));
FullSimplify[term + f d^2/(d^2-(w+I g)^2)]
