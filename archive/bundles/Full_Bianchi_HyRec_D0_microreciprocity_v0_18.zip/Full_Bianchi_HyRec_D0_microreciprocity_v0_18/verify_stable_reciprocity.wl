ClearAll["Global`*"];
logS[dE_] := 1/2 Log[beta M/(2 Pi)] - Log[Q]
 - beta M (dE-Q^2/(2 M))^2/(2 Q^2);
FullSimplify[logS[-dE]-(logS[dE]-beta dE),
 Assumptions->{beta>0,M>0,Q>0}]
