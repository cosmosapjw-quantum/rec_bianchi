# Full Bianchi-HyRec D0 microreciprocity lock v0.18

This artifact closes the conditional numerical reciprocity item left in
v0.17.

## v0.17 double-precision maxima

- pair-log residual: 3.808509063674e-12
- pointwise amplitude residual: 9.344299351302e-12

## Arbitrary-precision result

At a reconstructed far-tail pole point in the worst amplitude orbit:

- energy residual: 3.7176882e-119
- D-minus residual: -1.733248e-89
- D-plus residual: -6.434447e-86
- full amplitude relative residual: 1.7379323e-97

The dynamic-structure-factor and Boltzmann edge-log residuals are also
zero at 100-digit working precision.

No physical conductance is changed. The reverse DSF exponent is now
constructed from its exact identity, and the COM amplitude is stored as
one shared event invariant after an independent arbitrary-precision audit.
