ClearAll["Global`*"];
int=Assuming[{B>0,g>0,A\[Element]Reals},
 FullSimplify[Integrate[Exp[-z^2/2]/Sqrt[2 Pi]/((A+B z)^2+g^2),{z,-Infinity,Infinity}]]];
A21f=8 Pi^2 re f nu0^2/(3 c);
sigmaT=8 Pi re^2/3;
area=FullSimplify[sigmaT(A21/A21f)(f nu0/2)^2 Pi/(A21/(4 Pi))];
<|"GaussianLorentzianIntegral"->int,"OscillatorAreaResidual"->FullSimplify[area-Pi re c f]|>
