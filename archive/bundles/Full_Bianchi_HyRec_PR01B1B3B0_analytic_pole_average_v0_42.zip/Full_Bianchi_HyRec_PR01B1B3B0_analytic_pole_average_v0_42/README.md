# Full Bianchi–HyRec PR-01B1-B3B0 v0.42

This bounded stage replaces the numerical scattering-plane tangent
quadrature of the scalar COM 2p absorption pole by an analytic
Faddeeva/Voigt expression.

## Hard results

- all-orbit cache comparison: 2.786660e-13
- pole-location comparison: 1.953993e-14
- pole-width comparison: 1.105782e-13
- selected direct Gaussian quadrature: 2.819966e-14
- 90-digit Faddeeva cross-check: 5.523858e-15
- oscillator-area symbolic residual: 0.0e+00
- independently rounded CODATA constants floor: -2.069500e-11
- tests: ..                                                                       [100%]
2 passed in 0.44s

## Decision

- fresh conditional transverse 2p-pole integral: PASS
- v0.14 tangent quadrature for the pole: SUPERSEDED
- source/target two-sided frequency cells: OPEN
- crossed/background amplitude: OPEN
- production pair kernel: OPEN
