from pathlib import Path
import json, pandas as pd
HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/'PR01B1B3B0_ledger.json').read_text())
for key,val in ledger['hard_gate_status'].items():
    if key in {'two_sided_frequency_cells','crossed_term','full_pair_kernel'}:
        assert not val
    else:
        assert val
rows=pd.read_csv(HERE/'orbit_analytic_pole_validation.csv')
assert len(rows)==1836
print('PR01B1-B3B0 analytic pole average: PASS')
