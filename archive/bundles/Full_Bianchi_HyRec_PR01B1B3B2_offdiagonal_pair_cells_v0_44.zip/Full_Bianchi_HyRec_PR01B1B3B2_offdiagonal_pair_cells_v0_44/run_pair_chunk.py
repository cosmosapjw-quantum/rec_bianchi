from __future__ import annotations
import argparse, sys, time
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'workspace'/'src'))
from full_bianchi_hyrec.recoil import pair_cell_conductance as PCC
parser=argparse.ArgumentParser();parser.add_argument('--start',type=int,required=True);parser.add_argument('--stop',type=int,required=True);args=parser.parse_args()
pairs=[(i,j) for i in range(PCC.ncell) for j in range(i+1,PCC.ncell)]
subset=pairs[args.start:args.stop]
values=np.zeros((len(subset),7))
t0=time.time()
for idx,(i,j) in enumerate(subset):
 values[idx]=PCC.integrate_unordered_pair(i,j,lane='production',kind='exact')
out=HERE/f'pair_chunk_{args.start:03d}_{args.stop:03d}.npz'
np.savez_compressed(out,pairs=np.asarray(subset,dtype=int),values=values)
print(out.name,len(subset),time.time()-t0,flush=True)
