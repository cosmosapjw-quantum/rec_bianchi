from pathlib import Path
import json
import numpy as np

HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/"PR01B1B3B2_ledger.json").read_text())
for key,value in ledger["hard_gate_status"].items():
    if key in {"same_cell_coherent_angular_block","red_blue_exterior_deposition","full_ell_le_6_collision_operator"}:
        assert not value
    else:
        assert value, key

data=np.load(HERE/"offdiagonal_pair_conductance.npz")
S=data["conductance_m3_sInv"]
K=data["rates_sInv"]
Pi=data["equilibrium_weight_m3"]
G=data["scalar_generator_sInv"]
assert S.shape==(7,17,17)
assert np.max(np.abs(S-np.swapaxes(S,1,2)))==0.0
mask=~np.eye(17,dtype=bool)
assert np.min(S[0][mask])>0.0
assert np.max(np.abs(np.ones(17)@G))<1e-12
assert np.max(np.abs(G@Pi))/(np.max(np.abs(G))*np.max(Pi))<1e-12
assert not bool(data["diagonal_block_present"])
print("PR01B1-B3B2 off-diagonal pair cells: PASS")
