from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE / "workspace"
sys.path.insert(0, str(WORKSPACE / "src"))

from full_bianchi_hyrec.recoil import pair_cell_conductance as PCC  # noqa: E402


def calculate_pair(pair):
    target, source = pair
    value = PCC.integrate_unordered_pair(
        target, source, lane="production", kind="exact"
    )
    return target, source, value


def write_csv(path, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main():
    n = PCC.ncell
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    matrix_norm = np.zeros((7, n, n))

    workers = 1
    for pair_index, (i, j) in enumerate(pairs, start=1):
        value = PCC.integrate_unordered_pair(
            i, j, lane="production", kind="exact"
        )
        matrix_norm[:, i, j] = value
        matrix_norm[:, j, i] = value
        if pair_index % 16 == 0 or pair_index == len(pairs):
            print(f"computed {pair_index}/{len(pairs)} unordered pairs", flush=True)

    common_mode_factor = 8.0 * math.pi * PCC.dnu / PCC.c**3
    conductance = common_mode_factor * matrix_norm
    Pi = np.asarray(
        [PCC.physical_equilibrium_cell_weight(i) for i in range(n)]
    )
    rates = conductance / Pi[None, None, :]

    # Frequency-redistribution generator; same-cell angular scattering is
    # deliberately absent from this bounded off-diagonal artifact.
    generator = rates[0].copy()
    np.fill_diagonal(generator, 0.0)
    np.fill_diagonal(generator, -generator.sum(axis=0))

    left_null = float(np.max(np.abs(np.ones(n) @ generator)))
    right_null = float(
        np.max(np.abs(generator @ Pi))
        / (np.max(np.abs(generator)) * np.max(Pi) + 1.0e-300)
    )
    symmetry = float(
        np.max(np.abs(conductance - np.swapaxes(conductance, 1, 2)))
        / (np.max(np.abs(conductance)) + 1.0e-300)
    )

    # Entropy test on a positive random ratio field.
    rng = np.random.default_rng(20260804)
    ratio = np.exp(0.2 * rng.normal(size=n))
    population = Pi * ratio
    action = generator @ population
    entropy_production = float(np.dot(np.log(ratio), action))
    number_residual = float(abs(action.sum()))

    v032 = np.load(
        "/mnt/data/Full_Bianchi_HyRec_C3B2B1C_finite_volume_ellmax_v0_32/"
        "finite_volume_legendre_kernel.npz"
    )
    v033 = np.load(
        "/mnt/data/Full_Bianchi_HyRec_C3B2B1D0_thermodynamic_completion_v0_33/"
        "thermodynamic_completed_kernel.npz"
    )
    hummer = np.asarray(v032["physical_gain_sInv"][:7])
    completed = np.asarray(v033["completed_rate_sInv"][:7])
    offdiag = ~np.eye(n, dtype=bool)

    harmonic_rows = []
    for ell in range(7):
        exact_values = rates[ell][offdiag]
        hummer_values = hummer[ell][offdiag]
        completed_values = completed[ell][offdiag]
        harmonic_rows.append(
            {
                "ell": ell,
                "exact_offdiagonal_norm_s^-1": float(np.linalg.norm(exact_values)),
                "relative_to_no_recoil_Hummer": float(
                    np.linalg.norm(exact_values - hummer_values)
                    / (np.linalg.norm(exact_values) + 1.0e-300)
                ),
                "relative_to_v033_completion": float(
                    np.linalg.norm(exact_values - completed_values)
                    / (np.linalg.norm(exact_values) + 1.0e-300)
                ),
                "minimum_exact_rate_s^-1": float(np.min(exact_values)),
                "maximum_exact_rate_s^-1": float(np.max(exact_values)),
            }
        )

    # Pair ledger for ell=0.
    pair_rows = []
    for i, j in pairs:
        sij = conductance[0, i, j]
        left = rates[0, i, j] * Pi[j]
        right = rates[0, j, i] * Pi[i]
        pair_rows.append(
            {
                "target_i": i,
                "source_j": j,
                "x_i": float(PCC.xedges[i] + 0.25),
                "x_j": float(PCC.xedges[j] + 0.25),
                "conductance_m^-3_s^-1": float(sij),
                "K_i_from_j_s^-1": float(rates[0, i, j]),
                "K_j_from_i_s^-1": float(rates[0, j, i]),
                "pair_balance_relative": float(
                    (left - right) / (abs(left) + abs(right) + 1.0e-300)
                ),
                "relative_to_Hummer_i_from_j": float(
                    rates[0, i, j] / hummer[0, i, j] - 1.0
                ),
                "relative_to_v033_i_from_j": float(
                    rates[0, i, j] / completed[0, i, j] - 1.0
                ),
            }
        )

    # Selected production/reference and independent orientation audit.
    selected_pairs = [(8, 9), (7, 9), (4, 12), (0, 1), (0, 8)]
    convergence_rows = []
    for i, j in selected_pairs:
        production = matrix_norm[:, i, j]
        reference = PCC.integrate_unordered_pair(
            i, j, lane="reference", kind="exact"
        )
        reverse = PCC.integrate_unordered_pair(
            j, i, lane="reference", kind="exact"
        )
        hummer_weighted = PCC.integrate_unordered_pair(
            i, j, lane="reference", kind="hummer"
        ) / PCC.pi_norm(j)
        convergence_rows.append(
            {
                "target_i": i,
                "source_j": j,
                "x_i": float(PCC.xedges[i] + 0.25),
                "x_j": float(PCC.xedges[j] + 0.25),
                "production_reference_relative": float(
                    np.linalg.norm(production - reference)
                    / np.linalg.norm(reference)
                ),
                "independent_orientation_relative": float(
                    np.linalg.norm(reference - reverse)
                    / np.linalg.norm(reference)
                ),
                "mode_weighted_Hummer_vs_v032_relative": float(
                    np.linalg.norm(hummer_weighted - hummer[:7, i, j])
                    / np.linalg.norm(hummer[:7, i, j])
                ),
            }
        )

    # Random pointwise infinite-mass/no-recoil normalization audit.
    rng = np.random.default_rng(20260805)
    point_rows = []
    for sample in range(512):
        x_t = rng.uniform(-4.0, 4.0)
        x_s = rng.uniform(-4.0, 4.0)
        mu = rng.uniform(-0.98, 0.98)
        ratio_value = PCC.pointwise_hummer_limit_ratio(x_t, x_s, mu)
        point_rows.append(
            {
                "sample": sample,
                "x_target": x_t,
                "x_source": x_s,
                "mu": mu,
                "pair_over_Hummer": ratio_value,
                "relative_residual": ratio_value - 1.0,
            }
        )

    write_csv(HERE / "offdiagonal_pair_ledger.csv", pair_rows)
    write_csv(HERE / "selected_pair_convergence.csv", convergence_rows)
    write_csv(HERE / "harmonic_offdiagonal_comparison.csv", harmonic_rows)
    write_csv(HERE / "pointwise_hummer_limit.csv", point_rows)

    np.savez_compressed(
        HERE / "offdiagonal_pair_conductance.npz",
        classification=np.asarray(
            "PR01B1B3B2_OFFDIAGONAL_TWO_SIDED_PAIR_CONDUCTANCE"
        ),
        x_edges=PCC.xedges,
        x_centers=0.5 * (PCC.xedges[:-1] + PCC.xedges[1:]),
        ell_values=np.arange(7),
        conductance_m3_sInv=conductance,
        rates_sInv=rates,
        equilibrium_weight_m3=Pi,
        scalar_generator_sInv=generator,
        diagonal_block_present=np.asarray(False),
    )

    summary = {
        "offdiagonal_pair_count": len(pairs),
        "workers": workers,
        "conductance_symmetry_relative": symmetry,
        "generator_left_null": left_null,
        "equilibrium_right_null": right_null,
        "minimum_scalar_conductance": float(
            np.min(conductance[0][offdiag])
        ),
        "number_residual_random_state": number_residual,
        "entropy_production_random_state": entropy_production,
        "maximum_selected_quadrature_relative": max(
            row["production_reference_relative"] for row in convergence_rows
        ),
        "maximum_selected_orientation_relative": max(
            row["independent_orientation_relative"] for row in convergence_rows
        ),
        "maximum_pointwise_Hummer_relative": max(
            abs(row["relative_residual"]) for row in point_rows
        ),
        "same_cell_angular_block": "OPEN",
        "red_blue_exterior": "OPEN",
    }
    (HERE / "matrix_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
