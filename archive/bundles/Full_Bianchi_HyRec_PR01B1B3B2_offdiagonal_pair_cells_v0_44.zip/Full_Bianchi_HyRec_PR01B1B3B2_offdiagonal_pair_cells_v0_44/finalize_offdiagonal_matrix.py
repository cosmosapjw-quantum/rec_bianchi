from __future__ import annotations
import csv,json,math,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'workspace'/'src'))
from full_bianchi_hyrec.recoil import pair_cell_conductance as PCC

def write_csv(path,rows):
    with Path(path).open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys()));w.writeheader();w.writerows(rows)

n=PCC.ncell
matrix_norm=np.zeros((7,n,n))
seen=[]
for path in sorted(HERE.glob('pair_chunk_*.npz')):
    d=np.load(path);pairs=d['pairs'];values=d['values']
    for (i,j),value in zip(pairs,values):
        i=int(i);j=int(j);matrix_norm[:,i,j]=value;matrix_norm[:,j,i]=value;seen.append((i,j))
if len(seen)!=n*(n-1)//2 or len(set(seen))!=len(seen):
    raise RuntimeError(f'incomplete/duplicate pairs {len(seen)} {len(set(seen))}')
common_mode_factor=8*math.pi*PCC.dnu/PCC.c**3
conductance=common_mode_factor*matrix_norm
Pi=np.asarray([PCC.physical_equilibrium_cell_weight(i) for i in range(n)])
rates=conductance/Pi[None,None,:]
generator=rates[0].copy();np.fill_diagonal(generator,0);np.fill_diagonal(generator,-generator.sum(axis=0))
left=float(np.max(np.abs(np.ones(n)@generator)))
right=float(np.max(np.abs(generator@Pi))/(np.max(np.abs(generator))*np.max(Pi)+1e-300))
sym=float(np.max(np.abs(conductance-np.swapaxes(conductance,1,2)))/(np.max(np.abs(conductance))+1e-300))
rng=np.random.default_rng(20260804);ratio=np.exp(.2*rng.normal(size=n));pop=Pi*ratio;action=generator@pop
entropy=float(np.dot(np.log(ratio),action));number=float(abs(action.sum()))
v032=np.load('/mnt/data/Full_Bianchi_HyRec_C3B2B1C_finite_volume_ellmax_v0_32/finite_volume_legendre_kernel.npz')
v033=np.load('/mnt/data/Full_Bianchi_HyRec_C3B2B1D0_thermodynamic_completion_v0_33/thermodynamic_completed_kernel.npz')
hummer=np.asarray(v032['physical_gain_sInv'][:7]);completed=np.asarray(v033['completed_rate_sInv'][:7]);offdiag=~np.eye(n,dtype=bool)
harmonic=[]
for ell in range(7):
    ex=rates[ell][offdiag];hu=hummer[ell][offdiag];co=completed[ell][offdiag]
    harmonic.append({'ell':ell,'exact_offdiagonal_norm_s^-1':float(np.linalg.norm(ex)),'relative_to_no_recoil_Hummer':float(np.linalg.norm(ex-hu)/(np.linalg.norm(ex)+1e-300)),'relative_to_v033_completion':float(np.linalg.norm(ex-co)/(np.linalg.norm(ex)+1e-300)),'minimum_exact_rate_s^-1':float(np.min(ex)),'maximum_exact_rate_s^-1':float(np.max(ex))})
pair_rows=[]
for i,j in sorted(seen):
    sij=conductance[0,i,j];l=rates[0,i,j]*Pi[j];r=rates[0,j,i]*Pi[i]
    pair_rows.append({'target_i':i,'source_j':j,'x_i':float(.5*(PCC.xedges[i]+PCC.xedges[i+1])),'x_j':float(.5*(PCC.xedges[j]+PCC.xedges[j+1])),'conductance_m^-3_s^-1':float(sij),'K_i_from_j_s^-1':float(rates[0,i,j]),'K_j_from_i_s^-1':float(rates[0,j,i]),'pair_balance_relative':float((l-r)/(abs(l)+abs(r)+1e-300)),'relative_to_Hummer_i_from_j':float(rates[0,i,j]/hummer[0,i,j]-1),'relative_to_v033_i_from_j':float(rates[0,i,j]/completed[0,i,j]-1)})
selected=[(8,9),(7,9),(4,12),(0,1),(0,8),(0,16)]
conv=[]
for i,j in selected:
    prod=matrix_norm[:,i,j]
    ref=PCC.integrate_unordered_pair(i,j,lane='reference',kind='exact')
    rev=PCC.integrate_unordered_pair(j,i,lane='reference',kind='exact')
    hum_weight=PCC.integrate_unordered_pair(i,j,lane='reference',kind='hummer')/PCC.pi_norm(j)
    conv.append({'target_i':i,'source_j':j,'x_i':float(.5*(PCC.xedges[i]+PCC.xedges[i+1])),'x_j':float(.5*(PCC.xedges[j]+PCC.xedges[j+1])),'production_reference_relative':float(np.linalg.norm(prod-ref)/np.linalg.norm(ref)),'independent_orientation_relative':float(np.linalg.norm(ref-rev)/np.linalg.norm(ref)),'mode_weighted_Hummer_vs_v032_relative':float(np.linalg.norm(hum_weight-hummer[:7,i,j])/np.linalg.norm(hummer[:7,i,j]))})
rng=np.random.default_rng(20260805);points=[]
attempts=0
while len(points)<512 and attempts<200000:
    attempts+=1
    mu=float(rng.uniform(-.98,.95))
    xs=float(rng.uniform(-4,4))
    # Keep the audit in the numerically supported Hummer core rather than
    # accepting both numerator and denominator underflow.
    width=max(0.25,3.0*math.sqrt(max(1e-12,1.0-mu)))
    xt=float(np.clip(xs+rng.uniform(-width,width),-4,4))
    try:
        rv=PCC.pointwise_hummer_limit_ratio(xt,xs,mu)
    except (ZeroDivisionError,FloatingPointError):
        continue
    if not np.isfinite(rv) or rv<=0:
        continue
    sample=len(points)
    points.append({'sample':sample,'x_target':xt,'x_source':xs,'mu':mu,'pair_over_Hummer':rv,'relative_residual':rv-1})
if len(points)<512:
    raise RuntimeError(f'only {len(points)} finite Hummer-limit points')
write_csv(HERE/'offdiagonal_pair_ledger.csv',pair_rows);write_csv(HERE/'selected_pair_convergence.csv',conv);write_csv(HERE/'harmonic_offdiagonal_comparison.csv',harmonic);write_csv(HERE/'pointwise_hummer_limit.csv',points)
np.savez_compressed(HERE/'offdiagonal_pair_conductance.npz',classification=np.asarray('PR01B1B3B2_OFFDIAGONAL_TWO_SIDED_PAIR_CONDUCTANCE'),x_edges=PCC.xedges,x_centers=.5*(PCC.xedges[:-1]+PCC.xedges[1:]),ell_values=np.arange(7),conductance_m3_sInv=conductance,rates_sInv=rates,equilibrium_weight_m3=Pi,scalar_generator_sInv=generator,diagonal_block_present=np.asarray(False))
summary={'offdiagonal_pair_count':len(seen),'conductance_symmetry_relative':sym,'generator_left_null':left,'equilibrium_right_null':right,'minimum_scalar_conductance':float(np.min(conductance[0][offdiag])),'number_residual_random_state':number,'entropy_production_random_state':entropy,'maximum_selected_quadrature_relative':max(r['production_reference_relative'] for r in conv),'maximum_selected_orientation_relative':max(r['independent_orientation_relative'] for r in conv),'maximum_pointwise_Hummer_relative':max(abs(r['relative_residual']) for r in points),'maximum_mode_weighted_Hummer_vs_v032':max(abs(r['mode_weighted_Hummer_vs_v032_relative']) for r in conv),'same_cell_angular_block':'OPEN','red_blue_exterior':'OPEN'}
(HERE/'matrix_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
