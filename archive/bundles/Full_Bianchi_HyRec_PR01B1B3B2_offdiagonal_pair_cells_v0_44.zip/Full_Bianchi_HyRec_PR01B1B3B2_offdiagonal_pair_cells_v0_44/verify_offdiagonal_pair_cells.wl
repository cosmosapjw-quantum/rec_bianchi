ClearAll["Global`*"];

smjReverse=Exp[-z delta] smjForward;
conductanceForward=nuS nuT Exp[-beta h nuS] smjForward amp;
conductanceReverse=nuT nuS Exp[-beta h nuT] smjReverse amp;

pairResidual=FullSimplify[
 conductanceForward-conductanceReverse,
 Assumptions->{z==beta M c^2,delta==h(nuS-nuT)/(M c^2)}
];

G={{-k21,k12},{k21,-k12}};
pi={pi1,pi2};
rightResidual=FullSimplify[G.pi,
 Assumptions->{k21 pi1==k12 pi2}];

<|
 "PairConductanceResidual"->pairResidual,
 "GeneratorLeftNull"->FullSimplify[{1,1}.G],
 "GeneratorRightNull"->rightResidual,
 "UVJacobian"->Abs[Det[D[{u+v,u-v},{{u,v}}]]]
|>
