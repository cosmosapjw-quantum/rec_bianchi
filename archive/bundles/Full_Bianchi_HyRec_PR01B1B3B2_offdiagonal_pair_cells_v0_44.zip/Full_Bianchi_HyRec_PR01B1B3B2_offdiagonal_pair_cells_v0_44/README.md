# Full Bianchi-HyRec PR-01B1-B3B2 v0.44

This bundle contains the two-sided finite-volume invariant conductance
for all 136 distinct frequency-cell pairs in the 17-cell Ly-alpha core.

## Hard results

- unordered off-diagonal pairs: 136
- conductance symmetry: 0.000000e+00
- selected production/reference: 2.242119e-09
- independent orientation: 7.043598e-16
- generator left null: 6.183624e-17
- equilibrium right null: 2.180772e-16
- minimum scalar conductance: 7.681739e-09
- pointwise Hummer-limit audit: 4.323950e-08

## Physics comparison

The provisional exact COM pole+crossed off-diagonal scalar rate differs
from the no-recoil Hummer operator by 7.42e-4 in Frobenius norm and from
the v0.33 thermodynamic completion by 6.41e-4.  Near-null smooth modes
are much more sensitive to the missing recoil affinity, while the exact
operator remains within 7.31e-4 of v0.33 on the tested scalar actions.

## Status

- distinct-cell two-sided conductance: PASS
- same-cell coherent angular block: OPEN
- red/blue exterior deposition and four-force: OPEN
- full ell<=6 collision operator: OPEN
- production release: NOT APPROVED
