"""
Run the algebraic sign and conservation tests stored in the ledger.
"""

from pathlib import Path
import json
import numpy as np

HERE = Path(__file__).resolve().parent
ledger = json.loads((HERE / "boundary_contract_ledger.json").read_text())

assert abs(ledger["numeric_tests"]["liouville_number_residual"]) < 1e-12
assert np.max(np.abs(
    ledger["numeric_tests"]["liouville_four_momentum_residual"]
)) < 1e-12
assert abs(ledger["numeric_tests"]["scattering_number_residual"]) < 1e-12
assert np.max(np.abs(
    ledger["numeric_tests"]["scattering_four_momentum_residual"]
)) < 1e-12
assert ledger["numeric_tests"]["true_partition_residual"] == 0.0

print("D1C-C1 boundary contract: PASS")
