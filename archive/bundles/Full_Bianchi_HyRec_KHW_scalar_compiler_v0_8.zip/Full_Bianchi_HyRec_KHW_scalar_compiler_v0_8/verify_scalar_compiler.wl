ClearAll["Global`*"];

(* Per-channel seagull/TRK gauge identity. *)
FullSimplify[
  f - (f Delta/2) (1/(Delta-omega)+1/(Delta+omega))
    + f omega^2/(Delta^2-omega^2),
  Assumptions -> {
    Delta > 0,
    omega != Delta,
    omega != -Delta
  }
]

(* Ly-alpha pole and regular coefficients. *)
Normal@Series[
  f2 (1+z)^2/(z (2+z)),
  {z,0,4}
]

(* A non-pole transition, q=(Delta_2/Delta)^2. *)
Table[
  FullSimplify[
    Coefficient[
      Normal@Series[
        -f q (1+z)^2/(1-q (1+z)^2),
        {z,0,4}
      ],
      z,k
    ]/f
  ],
  {k,0,4}
]
