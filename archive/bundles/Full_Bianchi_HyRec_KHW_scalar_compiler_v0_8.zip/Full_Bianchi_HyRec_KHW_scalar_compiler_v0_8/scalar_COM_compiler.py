"""
Scalar COM-resolved Kramers-Heisenberg-Waller compiler skeleton.

Energy convention:
  all internal transition energies and photon frequencies are in the
  same units (Rydberg is convenient).

For a transition s with oscillator strength f_s and internal energy
Delta_s, define

  D_s^- = Delta_s
          + [|P_i+hbar k_i|^2-|P_i|^2]/(2 M E_unit)
          - omega_i

  D_s^+ = Delta_s
          + [|P_i-hbar k_o|^2-|P_i|^2]/(2 M E_unit)
          + omega_o.

The scalar p-gauge amplitude is

  M = 1 - 1/2 Sum_s f_s Delta_s (1/D_s^- + 1/D_s^+),

with the continuum replacing the sum by an integral over its oscillator
strength distribution.

Recommended pole/background split:

  M_2p_pole = -0.5 f_2 Delta_2 / (D_2^- - Sigma_2p)

  M_background =
      1
      - 0.5 f_2 Delta_2 / D_2^+
      - 0.5 Sum_{n>=3} f_n Delta_n (1/D_n^- + 1/D_n^+)
      - 0.5 Integral_continuum df Delta (1/D^- + 1/D^+).

In the fixed-nucleus elastic limit, the TRK sum rule gives

  M(omega,omega)
    = -omega^2 [
        Sum_n f_n/(Delta_n^2-omega^2)
        + Integral_continuum df/(Delta^2-omega^2)
      ].

Do not truncate the bound/continuum background without monitoring:
  - TRK residual,
  - static polarizability residual,
  - low-frequency gauge cancellation,
  - continuum principal-value convergence.
"""
