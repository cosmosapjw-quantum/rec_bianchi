# Full Bianchi–HyRec C3B1 native sparse block v0.27

This artifact assembles and verifies the source-exact HYREC FULL
2s/2p + 311 virtual-state linear block.

- source Git blob: `df04635e8fd5ed03481547a7967a14030d90a79b`
- full matrix: 313 x 313
- diffusion interval: virtual indices 100..179
- direct solve residual: 2.744211e-14
- structured Schur residual: 8.475773e-15
- direct/Schur difference: 1.114602e-15
- dense/Thomas Tvv difference: 4.615871e-17
- minimum Tvv diagonal-dominance margin: 1.465479e+00
- equilibrium-null source and solution: exactly zero

The upstream table is not redistributed; the NPZ contains derived
matrices and regression solutions only.
