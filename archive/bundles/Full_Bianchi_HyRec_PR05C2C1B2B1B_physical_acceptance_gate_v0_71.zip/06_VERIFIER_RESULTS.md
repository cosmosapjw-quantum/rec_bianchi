# Verifier results

```json
{
  "acceptance_tolerance": 1e-11,
  "action_maximum_abs_s_inv": 6.084732523565685e-23,
  "canonical_corrected_state_relative_backward_error": 514.2814690317614,
  "canonical_dt_s": 1708369384.3217053,
  "canonical_dt_to_parent_gate_dt_ratio": 1326369285591446.8,
  "canonical_legacy_unit_floor_backward_error": 3.8933191726359165e-15,
  "canonical_macro_convergence_claimed": false,
  "canonical_physical_acceptance_metric": 1.0,
  "canonical_physical_gross_backward_error": 1.0,
  "canonical_physical_number_relative_residual": 1.0,
  "classification": "PR05C2C1B2B1B_PHYSICAL_ACCEPTANCE_GATE_METRICS",
  "corrected_generic_gate_rejects_canonical_parent": true,
  "corrected_rescaling_invariance_relative_residual": 1.1102230246251565e-16,
  "dense_jacobian_condition_number": 1494562618.474968,
  "dense_physical_jacobian_audit_elapsed_s": 0.8854141009999239,
  "largest_dt_passing_parent_acceptance_gate_s": 1.2880043309808093e-06,
  "legacy_gate_false_pass_at_canonical_dt": true,
  "legacy_rescaling_disagreement_factor": 9.999999999999999e+17,
  "matrix_free_operator_available": true,
  "next": "PR05C2C1B2B1C_MATRIX_FREE_SAFEGUARDED_CONTINUATION_Z1100_BIANCHI_II",
  "problem_specific_gate_rejects_canonical_parent": true,
  "provenance": {
    "angular_point_count": 26,
    "background_model": "Bianchi_II_large_shear",
    "background_sha256": "df136bca7c120054cc45cf2b4fc2bd52acc3d60e6159b0f63c2622de03f2f03c",
    "boundary_sha256": "147ba6e6cfdae9c06530a0983161e769198b3bb5ad56c0c4d820b0a3f5d3e7b5",
    "canonical_dt_s": 1708369384.3217053,
    "direct_node_sha256": "e6a28194d183658a87f0974afe3f46323106382970a85338f9ce94c20c7b5736",
    "frequency_state_count": 35,
    "source_H_s_inv": 4.969651222923834e-14,
    "source_nH_m3": 250186754.37302318,
    "source_tau": 0.6072662349590596,
    "source_temperature_K": 3003.496188829631,
    "state_count": 910,
    "target_redshift": 1100
  },
  "rust_backend_selected": false,
  "shifted_matrix_free_jvp_relative_residual": 3.4909086631099003e-10,
  "state_maximum": 7.837778140794595e-18,
  "state_minimum": 7.570329622753227e-18,
  "status": "PASS_P0_FALSE_CONVERGENCE_GATE_FIXED_PHYSICAL_RESIDUAL_JVP_CONNECTED_MATRIX_FREE_CONTINUATION_OPEN"
}
```
