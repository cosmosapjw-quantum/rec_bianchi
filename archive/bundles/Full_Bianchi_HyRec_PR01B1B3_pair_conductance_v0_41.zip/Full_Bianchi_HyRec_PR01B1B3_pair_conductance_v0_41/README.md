# Full Bianchi–HyRec PR-01B1-B3A v0.41

This artifact applies the exact relativistic Maxwell–Jüttner dynamic
structure factor to every deterministic centre-sampled COM–KHW orbit in
the v0.14 cache.

## Main results

- physical orbits: 1836
- active unordered edges: 93925
- minimum MJ/MB factor: 9.999874383450e-01
- maximum MJ/MB factor: 9.999999994837e-01
- maximum harmonic-kernel change: 6.532365e-10
- maximum tested-action change: 1.182370e-09
- conductance symmetry: 0.000000e+00
- generator left null: 1.493311e-15
- equilibrium right null: 2.270849e-15
- high-precision log-ratio residual: 2.131323e-14

## Decision

- exact MJ measure reweighting: PASS
- Maxwell–Boltzmann production approximation at recombination: SUPPORTED
- centre-sampled/dimensionless kernel release: NOT APPROVED
- two-sided finite-volume invariant pair integral: NEXT
