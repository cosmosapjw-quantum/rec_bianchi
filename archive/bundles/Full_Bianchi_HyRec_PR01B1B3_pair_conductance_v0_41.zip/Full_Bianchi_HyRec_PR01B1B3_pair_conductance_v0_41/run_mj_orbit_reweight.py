from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import mpmath as mp
import numpy as np
import pandas as pd
from scipy.constants import c, k, physical_constants
from scipy.special import eval_legendre

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE / 'workspace'
sys.path.insert(0, str(WORKSPACE / 'src'))

from full_bianchi_hyrec.recoil.mj_orbit_reweight import (  # noqa: E402
    generator_from_conductance,
    mj_to_mb_log_ratio,
    reweight_symmetric_conductance,
)

V014 = Path('/mnt/data/Full_Bianchi_HyRec_C2d2C2B_orbit_cache_v0_14')
T = 3000.0
M_H = physical_constants['atomic mass constant'][0] * 1.00782503223


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def extract_harmonic_kernel(
    generator: np.ndarray,
    frequency_index: np.ndarray,
    angle_index: np.ndarray,
    directions: np.ndarray,
    angular_weights: np.ndarray,
    ell_max: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    nf = int(frequency_index.max()) + 1
    nq = len(angular_weights)
    # Off-diagonal state-to-state rates.  K[q<-r] already contains the
    # target quadrature weight; source orientation is averaged with w_r.
    rate = generator.copy()
    np.fill_diagonal(rate, 0.0)
    rate4 = rate.reshape(nf, nq, nf, nq)
    mu = directions @ directions.T

    kernel = np.zeros((ell_max + 1, nf, nf))
    source_orientation_spread = np.zeros((ell_max + 1, nf, nf))

    for ell in range(ell_max + 1):
        Pl = eval_legendre(ell, mu)
        for target_f in range(nf):
            for source_f in range(nf):
                block = rate4[target_f, :, source_f, :]
                by_source = np.sum(block * Pl, axis=0)
                kernel[ell, target_f, source_f] = float(
                    np.dot(angular_weights, by_source)
                )
                denominator = abs(kernel[ell, target_f, source_f]) + 1e-300
                source_orientation_spread[ell, target_f, source_f] = float(
                    np.sqrt(
                        np.dot(
                            angular_weights,
                            (by_source - kernel[ell, target_f, source_f]) ** 2,
                        )
                    )
                    / denominator
                )

    # Average total opacity over source directions.
    opacity_state = -np.diag(generator).reshape(nf, nq)
    opacity_frequency = opacity_state @ angular_weights
    return kernel, opacity_frequency, source_orientation_spread


def main() -> None:
    cache = pd.read_csv(V014 / 'orbit_amplitude_cache.csv')
    data = np.load(V014 / 'orbit_cache_and_conductance.npz')

    conductance_mb = np.asarray(data['full_conductance'], dtype=float)
    Pi = np.asarray(data['equilibrium_cell_weight'], dtype=float)
    fi = np.asarray(data['state_frequency_index'], dtype=int)
    ai = np.asarray(data['state_angle_index'], dtype=int)
    state_x = np.asarray(data['state_x'], dtype=float)
    directions = np.asarray(data['directions'], dtype=float)
    angular_weights = np.asarray(data['angular_weights'], dtype=float)
    state_nu = np.asarray(data['state_nu_Hz'], dtype=float)

    # One exact relativistic thermal correction per physical orbit.
    orbit_rows = []
    factor_lookup: dict[tuple[int, int, float], float] = {}
    log_ratio_values = []
    even_residuals = []

    for row in cache.itertuples(index=False):
        q = float(row.Q_SI) / (M_H * c)
        delta = float(row.DeltaE_SI) / (M_H * c**2)
        log_ratio = mj_to_mb_log_ratio(q, delta, M_H, T)
        log_ratio_reverse = mj_to_mb_log_ratio(q, -delta, M_H, T)
        factor = math.exp(log_ratio)
        key = (
            int(row.frequency_i),
            int(row.frequency_j),
            round(float(row.mu), 12),
        )
        factor_lookup[key] = factor
        log_ratio_values.append(log_ratio)
        even_residuals.append(log_ratio - log_ratio_reverse)
        orbit_rows.append(
            {
                'physics_orbit_id': int(row.physics_orbit_id),
                'frequency_i': int(row.frequency_i),
                'frequency_j': int(row.frequency_j),
                'x_i': float(row.x_i),
                'x_j': float(row.x_j),
                'mu': float(row.mu),
                'q_dimensionless': q,
                'delta_dimensionless': delta,
                'log_S_MJ_over_S_MB': log_ratio,
                'S_MJ_over_S_MB': factor,
                'delta_even_residual': log_ratio - log_ratio_reverse,
                'full_mean_amp2': float(row.full_mean_amp2),
                'amplitude_quad_change': float(row.quad_change_full_96_128_to_128_192),
            }
        )

    nstate = len(Pi)
    pair_factor = np.ones((nstate, nstate), dtype=float)
    mapped_edges = 0
    missing_edges: list[tuple] = []

    for a in range(nstate):
        for b in range(a + 1, nstate):
            if conductance_mb[a, b] <= 0.0:
                continue
            i = int(fi[a])
            j = int(fi[b])
            if i > j:
                i, j = j, i
            mu = round(float(directions[ai[a]] @ directions[ai[b]]), 12)
            key = (i, j, mu)
            factor = factor_lookup.get(key)
            if factor is None:
                missing_edges.append(key)
                continue
            pair_factor[a, b] = factor
            pair_factor[b, a] = factor
            mapped_edges += 1

    if missing_edges:
        raise RuntimeError(
            f'{len(missing_edges)} active edges lack an orbit factor; first={missing_edges[0]}'
        )

    conductance_mj = reweight_symmetric_conductance(
        conductance_mb, pair_factor
    )
    generator_mb = generator_from_conductance(conductance_mb, Pi)
    generator_mj = generator_from_conductance(conductance_mj, Pi)

    harmonic_mb, opacity_mb, spread_mb = extract_harmonic_kernel(
        generator_mb, fi, ai, directions, angular_weights, ell_max=6
    )
    harmonic_mj, opacity_mj, spread_mj = extract_harmonic_kernel(
        generator_mj, fi, ai, directions, angular_weights, ell_max=6
    )

    x_centers = state_x.reshape(17, 26)[:, 0]
    spectral_shapes = {
        'smooth_L8': 1.0 + 0.05 * np.cos(x_centers / 8.0),
        'smooth_L2': 1.0 + 0.05 * np.cos(x_centers / 2.0),
        'narrow_core': 1.0 + 0.10 * np.exp(-0.5 * (x_centers / 0.4) ** 2),
        'odd_red_blue': 1.0 + 0.05 * np.tanh(x_centers / 0.5),
    }

    action_rows = []
    for name, field in spectral_shapes.items():
        # Isotropic spectral action: same-frequency angular redistribution
        # cancels, so use the l=0 gain with total opacity.
        action_mb = harmonic_mb[0] @ field - opacity_mb * field
        action_mj = harmonic_mj[0] @ field - opacity_mj * field
        action_rows.append(
            {
                'state': name,
                'ell': 0,
                'MB_action_norm': float(np.linalg.norm(action_mb)),
                'MJ_action_norm': float(np.linalg.norm(action_mj)),
                'absolute_change': float(np.linalg.norm(action_mj - action_mb)),
                'relative_change': float(
                    np.linalg.norm(action_mj - action_mb)
                    / (np.linalg.norm(action_mj) + 1e-300)
                ),
                'MJ_number_residual': float(abs(action_mj.sum())),
            }
        )

    envelope = np.exp(-0.5 * (x_centers / 2.0) ** 2)
    for ell in range(1, 7):
        action_mb = harmonic_mb[ell] @ envelope - opacity_mb * envelope
        action_mj = harmonic_mj[ell] @ envelope - opacity_mj * envelope
        action_rows.append(
            {
                'state': 'Gaussian_harmonic_envelope',
                'ell': ell,
                'MB_action_norm': float(np.linalg.norm(action_mb)),
                'MJ_action_norm': float(np.linalg.norm(action_mj)),
                'absolute_change': float(np.linalg.norm(action_mj - action_mb)),
                'relative_change': float(
                    np.linalg.norm(action_mj - action_mb)
                    / (np.linalg.norm(action_mj) + 1e-300)
                ),
                'MJ_number_residual': float('nan'),
            }
        )

    # Generator invariants.
    symmetry = float(np.max(np.abs(conductance_mj - conductance_mj.T)))
    left_null = float(np.max(np.abs(np.ones(nstate) @ generator_mj)))
    right_null = float(
        np.max(np.abs(generator_mj @ Pi))
        / (np.max(np.abs(generator_mj)) * np.max(Pi) + 1e-300)
    )

    # High-precision special-function/structure-factor cross-check for the
    # orbit with the largest relativistic correction.
    extremal = orbit_rows[int(np.argmax(np.abs(log_ratio_values)))]
    mp.mp.dps = 100
    q_hp = mp.mpf(str(extremal['q_dimensionless']))
    d_hp = mp.mpf(str(extremal['delta_dimensionless']))
    mass_hp = mp.mpf(str(M_H))
    temp_hp = mp.mpf(str(T))
    c_hp = mp.mpf(str(c))
    k_hp = mp.mpf(str(k))
    z_hp = mass_hp * c_hp**2 / (k_hp * temp_hp)
    theta_hp = 1 / z_hp
    ratio = d_hp / q_hp
    root = mp.sqrt(1 - ratio**2)
    chi = q_hp * root
    gamma_min_minus_one = (
        (q_hp / chi) * mp.sqrt(1 + chi**2 / 4) - d_hp / 2 - 1
    )
    log_mj_hp = -z_hp * gamma_min_minus_one - mp.log(
        2 * q_hp * mp.e**z_hp * mp.besselk(2, z_hp)
    )
    log_mb_hp = (
        -mp.mpf('0.5') * mp.log(2 * mp.pi * theta_hp)
        - mp.log(q_hp)
        - (d_hp - q_hp**2 / 2) ** 2 / (2 * theta_hp * q_hp**2)
    )
    hp_log_ratio = log_mj_hp - log_mb_hp
    hp_residual = float(
        abs(hp_log_ratio - mp.mpf(str(extremal['log_S_MJ_over_S_MB'])))
    )

    write_csv(HERE / 'orbit_mj_reweight.csv', orbit_rows)
    write_csv(HERE / 'measure_action_comparison.csv', action_rows)

    harmonic_rows = []
    for ell in range(7):
        relative = float(
            np.linalg.norm(harmonic_mj[ell] - harmonic_mb[ell])
            / (np.linalg.norm(harmonic_mj[ell]) + 1e-300)
        )
        harmonic_rows.append(
            {
                'ell': ell,
                'MB_kernel_norm': float(np.linalg.norm(harmonic_mb[ell])),
                'MJ_kernel_norm': float(np.linalg.norm(harmonic_mj[ell])),
                'relative_measure_change': relative,
                'MB_max_source_orientation_spread': float(np.max(spread_mb[ell])),
                'MJ_max_source_orientation_spread': float(np.max(spread_mj[ell])),
            }
        )
    write_csv(HERE / 'harmonic_measure_correction.csv', harmonic_rows)

    np.savez_compressed(
        HERE / 'mj_reweighted_center_kernel.npz',
        classification=np.asarray('CENTER_SAMPLED_COM_KHW_EXACT_MJ_MEASURE_PILOT'),
        x_centers=x_centers,
        directions=directions,
        angular_weights=angular_weights,
        equilibrium_weight=Pi,
        pair_factor=pair_factor,
        conductance_MB=conductance_mb,
        conductance_MJ=conductance_mj,
        generator_MJ=generator_mj,
        harmonic_kernel_MB=harmonic_mb,
        harmonic_kernel_MJ=harmonic_mj,
        opacity_MB=opacity_mb,
        opacity_MJ=opacity_mj,
        source_orientation_spread_MJ=spread_mj,
    )

    summary = {
        'mapped_active_edges': mapped_edges,
        'active_physics_orbits': len(orbit_rows),
        'log_ratio_min': float(np.min(log_ratio_values)),
        'log_ratio_max': float(np.max(log_ratio_values)),
        'factor_min': float(np.exp(np.min(log_ratio_values))),
        'factor_max': float(np.exp(np.max(log_ratio_values))),
        'maximum_delta_even_residual': float(np.max(np.abs(even_residuals))),
        'conductance_symmetry': symmetry,
        'generator_left_null': left_null,
        'generator_equilibrium_right_null': right_null,
        'maximum_harmonic_relative_change': float(
            max(row['relative_measure_change'] for row in harmonic_rows)
        ),
        'maximum_action_relative_change': float(
            max(row['relative_change'] for row in action_rows if np.isfinite(row['relative_change']))
        ),
        'high_precision_log_ratio_residual': hp_residual,
        'extremal_orbit': extremal,
    }
    (HERE / 'mj_reweight_summary.json').write_text(
        json.dumps(summary, indent=2), encoding='utf-8'
    )
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
