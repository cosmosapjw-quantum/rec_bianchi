from pathlib import Path
import json
import numpy as np

HERE = Path(__file__).resolve().parent
summary = json.loads((HERE / 'mj_reweight_summary.json').read_text())
ledger = json.loads((HERE / 'PR01B1B3A_ledger.json').read_text())

for key, value in ledger['hard_gate_status'].items():
    if key in {
        'two_sided_finite_volume',
        'absolute_physical_normalization',
        'fresh_resonance_amplitude_integral',
        'production_release',
    }:
        assert not value
    else:
        assert value

data = np.load(HERE / 'mj_reweighted_center_kernel.npz')
S = data['conductance_MJ']
G = data['generator_MJ']
Pi = data['equilibrium_weight']

assert np.max(np.abs(S - S.T)) == 0.0
assert np.min(S) >= 0.0
assert np.max(np.abs(np.ones(len(Pi)) @ G)) < 1e-12
assert np.max(np.abs(G @ Pi)) / (
    np.max(np.abs(G)) * np.max(Pi)
) < 1e-12
assert summary['mapped_active_edges'] == 93925

print('PR01B1-B3A Maxwell-Juttner orbit reweighting: PASS')
