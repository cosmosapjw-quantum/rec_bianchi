from pathlib import Path
import json
import numpy as np

HERE=Path(__file__).resolve().parent
ledger=json.loads((HERE/"PR01B0_ledger.json").read_text())

assert ledger["hard_gate_status"]["analytic_recoil_moments"]
assert ledger["hard_gate_status"]["no_recoil_baseline_reproduction"]
assert ledger["hard_gate_status"]["quadrature_convergence"]

assert not ledger["hard_gate_status"]["original_v033_equality_gate"]
assert not ledger["hard_gate_status"]["shift_only_microreversibility"]
assert not ledger["hard_gate_status"]["full_PR01B_microreversible_kernel"]

reference=ledger["bridge_reference"]["lanes"]["reference"]
assert reference["shift_only_pair_balance_relative"] > 1e-7
assert reference["shift_only_vs_v033_drift_relative"] > 0.5

print("PR-01B0 recoil/thermodynamic bridge audit: PASS")
