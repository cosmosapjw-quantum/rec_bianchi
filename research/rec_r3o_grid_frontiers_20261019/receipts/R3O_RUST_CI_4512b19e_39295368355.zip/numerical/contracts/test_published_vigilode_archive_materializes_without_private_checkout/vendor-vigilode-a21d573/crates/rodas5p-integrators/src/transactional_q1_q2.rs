use rodas5p_core::{
    CoreError, CoreResult, IdentityPreconditioner, InitialGuess, LinearMethod, LinearOperator,
    LinearSolverConfig, PreconditionerKind, WorkCounters, error_scale, wrms,
};
use rodas5p_krylov::{GmresConfig, solve_gmres};
use serde::Serialize;

use crate::homotopy::{add_scaled_rows, evaluate_partial_path};
use crate::{
    DiagonalStageProblem, HomotopyWorkLedger, InverseWitness, OdeProblem, ParallelExecution,
    QuadraticStageProblem, STAGE_TARGET_SEQUENTIAL, StageCertificate, StageTarget, StepCertificate,
    StepContext, StepResult, StructuredBlockSystem, build_step_context_matrix_free,
    candidate_digest, certify_stage_target, certify_stage_target_diagonal, finish_step,
    sequential_stages,
};
use rodas5p_core::directed::{mul_down, mul_up};

/// How the escalated q=2 candidate is admitted (re-audit R3, HOM-05).
#[derive(Clone, Copy)]
pub enum Q2Admission<'a> {
    /// The eighth common-W batch: a q=0 correction at the post-q2 residual,
    /// never applied, estimates the remaining output defect. Operational,
    /// not a bound.
    OperationalDiagnostic,
    /// No eighth batch: an outward certificate on the sequential stage
    /// target ([`STAGE_TARGET_SEQUENTIAL`]) bounds the candidate output's
    /// distance from the target's exact output, and the budget comes from the
    /// certified lower bound of the embedded estimate.
    NativeTargetCertificate(&'a dyn Q2CertificateSource),
    /// [`Q2Admission::NativeTargetCertificate`] with one
    /// [`PreparedQ2Certificate`] per attempt (integrated DAG node INT-02):
    /// the stage problem and its witness are built once, before the fast
    /// path, and serve both the capability decision and the certificate. A
    /// source with [`Q2CertificateSource::diagonal_stage_problem`] is
    /// certified on its O(n) diagonal form. Every binding and consistency
    /// check of the native path is kept.
    PreparedStructuredCertificate(&'a dyn Q2CertificateSource),
}

pub const OPERATIONAL_DIAGNOSTIC_ADMISSION: &str = "operational-diagnostic";
pub const NATIVE_TARGET_CERTIFICATE_ADMISSION: &str = "native-target-certificate";
pub const PREPARED_STRUCTURED_CERTIFICATE_ADMISSION: &str = "prepared-structured-certificate";

impl Q2Admission<'_> {
    pub fn name(&self) -> &'static str {
        match self {
            Self::OperationalDiagnostic => OPERATIONAL_DIAGNOSTIC_ADMISSION,
            Self::NativeTargetCertificate(_) => NATIVE_TARGET_CERTIFICATE_ADMISSION,
            Self::PreparedStructuredCertificate(_) => PREPARED_STRUCTURED_CERTIFICATE_ADMISSION,
        }
    }
}

/// The certificate problem of a step. The certificate covers the
/// autonomous, identity-mass family `f(y + d) = f(y) + J d + q d^2` (for
/// example `f(z) = A z + q z^2` with `J = A + 2 diag(q y)`). What it bounds is
/// the declared problem; its agreement with the integrated ODE is checked
/// numerically (`f(y)` and one JVP), which is a consistency check, not a
/// proof.
pub trait Q2CertificateSource: Sync {
    fn stage_problem(&self, t: f64, y: &[f64], h: f64) -> CoreResult<QuadraticStageProblem>;

    /// How the declared model is tied to the integrated ODE (re-audit R4,
    /// R4-HOM-DEV-03). A general callback is [`ModelBinding::SampledAgreement`]:
    /// the checks at `f(y)`, one JVP and the stage states are consistency
    /// checks, never a proof.
    fn binding(&self) -> ModelBinding {
        ModelBinding::SampledAgreement
    }

    /// Whether [`Q2CertificateSource::witness`] exists for this problem,
    /// decided before any speculative work (re-audit R4, R4-HOM-DEV-06), by
    /// building it: a source that overrides `witness` (an approximate
    /// inverse for `n > 2`) is judged by its own witness. The default
    /// witnesses are the diagonal one and the exact small one (`n <= 2`), so
    /// with them a non-diagonal `J` with `n > 2` is a dimension cutoff and any
    /// other constructor failure (a singular `W`) a mathematical rejection.
    fn capability(&self, problem: &QuadraticStageProblem, gamma: f64) -> WitnessCapability {
        match self.witness(problem, gamma) {
            Ok(witness) => WitnessCapability::Available {
                structure: witness.identity().structure.clone(),
            },
            Err(error) if error.to_string().contains(SMALL_WITNESS_DIMENSION_LIMIT) => {
                WitnessCapability::DimensionCutoff {
                    dimension: problem.dimension(),
                }
            }
            Err(error) => WitnessCapability::MathematicalReject {
                reason: error.to_string(),
            },
        }
    }

    /// The stage problem in diagonal form, for sources whose `J` is diagonal
    /// by construction (integrated DAG node INT-02). `None` (the default)
    /// means the dense [`Q2CertificateSource::stage_problem`] is used.
    fn diagonal_stage_problem(
        &self,
        _t: f64,
        _y: &[f64],
        _h: f64,
    ) -> Option<CoreResult<DiagonalStageProblem>> {
        None
    }

    /// The witness of a diagonal stage problem:
    /// [`InverseWitness::diagonal_structured`].
    fn diagonal_witness(
        &self,
        problem: &DiagonalStageProblem,
        gamma: f64,
    ) -> CoreResult<InverseWitness> {
        InverseWitness::diagonal_structured(problem, gamma)
    }

    /// An inverse witness for `W = I - h gamma J`: diagonal when `J` is,
    /// otherwise the small dense one.
    fn witness(&self, problem: &QuadraticStageProblem, gamma: f64) -> CoreResult<InverseWitness> {
        let diagonal = problem.jacobian.iter().enumerate().all(|(a, row)| {
            row.iter()
                .enumerate()
                .all(|(b, value)| a == b || *value == 0.0)
        });
        if diagonal {
            InverseWitness::diagonal(problem, gamma)
        } else {
            InverseWitness::small(problem, gamma)
        }
    }
}

const MODEL_DIGEST_TAG: &str = "quadratic-model-sha256=";

/// The binding an admission may claim for `problem`: a source's
/// [`ModelBinding::GeneratedFromModel`] holds only if the integrated
/// problem carries that model digest in its name (it was generated by
/// [`QuadraticModel::ode_problem`]); otherwise the agreement is sampled.
fn effective_binding(source: &dyn Q2CertificateSource, problem: &OdeProblem) -> ModelBinding {
    match source.binding() {
        ModelBinding::GeneratedFromModel { model_sha256 }
            if problem
                .name
                .ends_with(&format!("#{MODEL_DIGEST_TAG}{model_sha256}")) =>
        {
            ModelBinding::GeneratedFromModel { model_sha256 }
        }
        _ => ModelBinding::SampledAgreement,
    }
}

/// See [`Q2CertificateSource::binding`].
#[derive(Clone, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "kebab-case", tag = "kind")]
pub enum ModelBinding {
    /// The ODE's RHS, JVP and the certificate problem come from one
    /// [`QuadraticModel`] with this content digest; they agree by
    /// construction up to the binary64 rounding of `J = A + 2 diag(q y)`.
    GeneratedFromModel { model_sha256: String },
    /// An arbitrary callback checked at sampled points.
    SampledAgreement,
}

/// `f(z) = A z + q * z^2` (componentwise `q`), autonomous with identity
/// mass: one type generates the integrated [`OdeProblem`] (RHS and JVP)
/// and the certificate problem, so a certificate cannot silently refer to
/// another model (re-audit R4, R4-HOM-DEV-03).
#[derive(Clone, Debug, PartialEq)]
pub struct QuadraticModel {
    pub name: String,
    pub a: Vec<Vec<f64>>,
    pub q: Vec<f64>,
}

impl QuadraticModel {
    pub fn new(name: impl Into<String>, a: Vec<Vec<f64>>, q: Vec<f64>) -> CoreResult<Self> {
        let n = q.len();
        if n == 0
            || a.len() != n
            || a.iter().any(|row| row.len() != n)
            || !a.iter().flatten().chain(&q).all(|value| value.is_finite())
        {
            return Err(CoreError::InvalidInput(
                "quadratic model: A must be a finite n x n matrix and q finite of length n".into(),
            ));
        }
        Ok(Self {
            name: name.into(),
            a,
            q,
        })
    }

    pub fn dimension(&self) -> usize {
        self.q.len()
    }

    /// SHA-256 of `A` and `q` bits.
    pub fn model_sha256(&self) -> String {
        let bits = self
            .a
            .iter()
            .flatten()
            .chain(&self.q)
            .map(|value| format!("{:016x}", value.to_bits()))
            .collect::<Vec<_>>()
            .join(",");
        rodas5p_core::sha256_hex(
            format!("vigilode-quadratic-model-v1|n={}|{bits}", self.dimension()).as_bytes(),
        )
    }

    /// The name an [`OdeProblem`] generated by this model carries: the
    /// model's name and digest, which the certificate admission checks.
    pub fn problem_name(&self) -> String {
        format!("{}#{MODEL_DIGEST_TAG}{}", self.name, self.model_sha256())
    }

    /// The integrated ODE: RHS `A z + q z^2` and JVP `(A + 2 diag(q z)) v`,
    /// named by [`QuadraticModel::problem_name`].
    pub fn ode_problem(&self) -> CoreResult<OdeProblem> {
        let (rhs_model, jvp_model) = (self.clone(), self.clone());
        OdeProblem::new(
            self.problem_name(),
            self.dimension(),
            std::sync::Arc::new(move |_t, z: &[f64], out: &mut [f64]| {
                for (a, out) in out.iter_mut().enumerate() {
                    let linear = rhs_model.a[a]
                        .iter()
                        .zip(z)
                        .map(|(x, y)| x * y)
                        .sum::<f64>();
                    *out = linear + rhs_model.q[a] * z[a] * z[a];
                }
                Ok(())
            }),
            None,
            None,
            Some(std::sync::Arc::new(
                move |_t, z: &[f64], v: &[f64], out: &mut [f64]| {
                    for (a, out) in out.iter_mut().enumerate() {
                        let linear = jvp_model.a[a]
                            .iter()
                            .zip(v)
                            .map(|(x, y)| x * y)
                            .sum::<f64>();
                        *out = linear + 2.0 * jvp_model.q[a] * z[a] * v[a];
                    }
                    Ok(())
                },
            )),
            None,
            true,
            None,
            None,
        )
    }
}

impl Q2CertificateSource for QuadraticModel {
    fn stage_problem(&self, _t: f64, y: &[f64], h: f64) -> CoreResult<QuadraticStageProblem> {
        if y.len() != self.dimension() {
            return Err(CoreError::Dimension(
                "quadratic model: state dimension".into(),
            ));
        }
        let jacobian = (0..self.dimension())
            .map(|a| {
                (0..self.dimension())
                    .map(|b| {
                        if a == b {
                            self.a[a][b] + 2.0 * self.q[a] * y[a]
                        } else {
                            self.a[a][b]
                        }
                    })
                    .collect()
            })
            .collect();
        Ok(QuadraticStageProblem {
            jacobian,
            y: y.to_vec(),
            h,
            q: self.q.clone(),
        })
    }

    fn binding(&self) -> ModelBinding {
        ModelBinding::GeneratedFromModel {
            model_sha256: self.model_sha256(),
        }
    }
}

/// A [`QuadraticModel`] whose `A` is diagonal, with that diagonal kept, so
/// that its stage problems are O(n) data (integrated DAG node INT-02). Its
/// dense [`Q2CertificateSource::stage_problem`], binding and ODE are the
/// wrapped model's.
#[derive(Clone, Debug, PartialEq)]
pub struct DiagonalQuadraticModel {
    model: QuadraticModel,
    diagonal: Vec<f64>,
}

impl DiagonalQuadraticModel {
    /// Rejects a model with a nonzero off-diagonal entry of `A`.
    pub fn new(model: QuadraticModel) -> CoreResult<Self> {
        let n = model.dimension();
        if (0..n).any(|a| (0..n).any(|b| a != b && model.a[a][b] != 0.0)) {
            return Err(CoreError::InvalidInput(
                "CERTIFICATE_STRUCTURE_UNSUPPORTED: the model's A is not diagonal".into(),
            ));
        }
        let diagonal = (0..n).map(|a| model.a[a][a]).collect();
        Ok(Self { model, diagonal })
    }

    pub fn model(&self) -> &QuadraticModel {
        &self.model
    }
}

impl Q2CertificateSource for DiagonalQuadraticModel {
    fn stage_problem(&self, t: f64, y: &[f64], h: f64) -> CoreResult<QuadraticStageProblem> {
        self.model.stage_problem(t, y, h)
    }

    fn binding(&self) -> ModelBinding {
        self.model.binding()
    }

    fn diagonal_stage_problem(
        &self,
        _t: f64,
        y: &[f64],
        h: f64,
    ) -> Option<CoreResult<DiagonalStageProblem>> {
        if y.len() != self.diagonal.len() {
            return Some(Err(CoreError::Dimension(
                "quadratic model: state dimension".into(),
            )));
        }
        // J = A + 2 diag(q y), entry by entry as in the dense stage problem.
        let diagonal = self
            .diagonal
            .iter()
            .zip(&self.model.q)
            .zip(y)
            .map(|((a, q), y)| a + 2.0 * q * y)
            .collect();
        Some(Ok(DiagonalStageProblem {
            diagonal,
            y: y.to_vec(),
            h,
            q: self.model.q.clone(),
        }))
    }
}

/// The stage problem of one attempt, dense or diagonal.
#[derive(Clone, Debug, PartialEq)]
pub enum PreparedStageProblem {
    Dense(QuadraticStageProblem),
    Diagonal(DiagonalStageProblem),
}

impl PreparedStageProblem {
    pub fn y(&self) -> &[f64] {
        match self {
            Self::Dense(problem) => &problem.y,
            Self::Diagonal(problem) => &problem.y,
        }
    }

    pub fn h(&self) -> f64 {
        match self {
            Self::Dense(problem) => problem.h,
            Self::Diagonal(problem) => problem.h,
        }
    }

    pub fn q(&self) -> &[f64] {
        match self {
            Self::Dense(problem) => &problem.q,
            Self::Diagonal(problem) => &problem.q,
        }
    }

    /// `f(J row a)`: calls `visit(b, J_ab)` for the stored entries of row
    /// `a` (all `n` of a dense row, in order; only the diagonal otherwise).
    fn for_each_entry(&self, a: usize, mut visit: impl FnMut(usize, f64)) {
        match self {
            Self::Dense(problem) => {
                for (b, value) in problem.jacobian[a].iter().enumerate() {
                    visit(b, *value);
                }
            }
            Self::Diagonal(problem) => visit(a, problem.diagonal[a]),
        }
    }

    /// Stored f64 slots of `J`.
    pub fn jacobian_slots(&self) -> usize {
        match self {
            Self::Dense(problem) => problem.jacobian.iter().map(Vec::len).sum(),
            Self::Diagonal(problem) => problem.diagonal.len(),
        }
    }
}

/// The stage problem and witness of one q=2 attempt, built once and not
/// changed afterwards (integrated DAG node INT-02, external review N3).
#[derive(Debug)]
pub struct PreparedQ2Certificate {
    problem: CoreResult<PreparedStageProblem>,
    witness: Option<CoreResult<InverseWitness>>,
}

impl PreparedQ2Certificate {
    pub fn prepare(
        source: &dyn Q2CertificateSource,
        t: f64,
        y: &[f64],
        h: f64,
        gamma: f64,
    ) -> Self {
        let problem = match source.diagonal_stage_problem(t, y, h) {
            Some(problem) => problem.map(PreparedStageProblem::Diagonal),
            None => source
                .stage_problem(t, y, h)
                .map(PreparedStageProblem::Dense),
        };
        let witness = problem.as_ref().ok().map(|problem| match problem {
            PreparedStageProblem::Dense(problem) => source.witness(problem, gamma),
            PreparedStageProblem::Diagonal(problem) => source.diagonal_witness(problem, gamma),
        });
        Self { problem, witness }
    }

    pub fn problem(&self) -> Option<&PreparedStageProblem> {
        self.problem.as_ref().ok()
    }

    pub fn witness(&self) -> Option<&InverseWitness> {
        self.witness.as_ref().and_then(|w| w.as_ref().ok())
    }

    /// The capability decision of [`Q2CertificateSource::capability`],
    /// from the prepared witness.
    pub fn capability(&self) -> WitnessCapability {
        match (&self.problem, &self.witness) {
            (Err(error), _) => WitnessCapability::ProblemUnavailable {
                reason: error.to_string(),
            },
            (Ok(_), Some(Ok(witness))) => WitnessCapability::Available {
                structure: witness.identity().structure.clone(),
            },
            (Ok(problem), Some(Err(error)))
                if error.to_string().contains(SMALL_WITNESS_DIMENSION_LIMIT) =>
            {
                WitnessCapability::DimensionCutoff {
                    dimension: problem.y().len(),
                }
            }
            (Ok(_), Some(Err(error))) => WitnessCapability::MathematicalReject {
                reason: error.to_string(),
            },
            (Ok(_), None) => WitnessCapability::MathematicalReject {
                reason: "no witness".into(),
            },
        }
    }
}

/// The outcome of [`Q2CertificateSource::capability`].
#[derive(Clone, Debug, PartialEq, Serialize)]
#[serde(rename_all = "kebab-case", tag = "kind")]
pub enum WitnessCapability {
    Available {
        structure: String,
    },
    /// No witness constructor covers this structure and size: a policy
    /// limit, not a statement about the operator.
    DimensionCutoff {
        dimension: usize,
    },
    /// A constructor applies and failed (for example a singular `W`).
    MathematicalReject {
        reason: String,
    },
    /// The source produced no certificate problem for this step.
    ProblemUnavailable {
        reason: String,
    },
}

impl WitnessCapability {
    pub fn is_available(&self) -> bool {
        matches!(self, Self::Available { .. })
    }
}

pub const CERTIFICATE_CAPABILITY_UNAVAILABLE: &str = "CERTIFICATE_CAPABILITY_UNAVAILABLE";
/// The message of the exact small witness beyond its dimension.
const SMALL_WITNESS_DIMENSION_LIMIT: &str = "small witness needs n <= 2";

/// The certificate admission of one q=2 candidate.
#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct Q2CertificateAdmission {
    pub accepted: bool,
    pub reason: String,
    /// [`Q2CertificateSource::binding`] of the source (re-audit R4,
    /// R4-HOM-DEV-03).
    pub model_binding: ModelBinding,
    pub certificate: Option<StageCertificate>,
    /// Lower bound on `min(absolute, fraction * E^(6/5))` for the certified
    /// lower bound `E` of the embedded estimate.
    pub budget_lower: f64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum TransactionalQ1Q2Lane {
    Q1Fast,
    Q2Escalated,
    SequentialFallback,
}

/// The q=1 and operational q=2 gate. Under
/// [`Q2Admission::NativeTargetCertificate`] the q=2 report reuses these
/// fields: `last_output_correction_wrms` and `contraction_tail_wrms` hold the
/// certified output bound, `output_contraction` is that bound over the q=2
/// correction, and `output_budget` is the certified budget lower bound; the
/// certificate itself is in [`TransactionalQ1Q2StepReport::q2_certificate`].
#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct OperationalGateReport {
    pub accepted: bool,
    pub reason: String,
    pub finite: bool,
    pub target_residual_before: f64,
    pub target_residual_after: f64,
    pub target_residual_ratio: f64,
    pub target_relative_residual: f64,
    pub previous_output_correction_wrms: f64,
    pub last_output_correction_wrms: f64,
    pub output_contraction: f64,
    pub contraction_tail_wrms: f64,
    pub embedded_error: f64,
    pub output_budget: f64,
}

#[derive(Clone, Debug, PartialEq, Serialize)]
pub struct TransactionalQ1Q2Config {
    pub threads: usize,
    pub gmres_restart: usize,
    pub gmres_max_arnoldi: usize,
    pub gmres_rtol: f64,
    pub gmres_atol: f64,
    pub absolute_output_budget: f64,
    pub embedded_budget_fraction: f64,
    pub max_output_contraction: f64,
    pub max_residual_contraction: f64,
    pub max_target_relative_residual: f64,
}

impl Default for TransactionalQ1Q2Config {
    fn default() -> Self {
        Self {
            threads: 1,
            gmres_restart: 32,
            gmres_max_arnoldi: 256,
            gmres_rtol: 1.0e-10,
            gmres_atol: 1.0e-12,
            absolute_output_budget: 0.1,
            embedded_budget_fraction: 0.2,
            max_output_contraction: 0.8,
            max_residual_contraction: 0.9,
            max_target_relative_residual: 1.0e-5,
        }
    }
}

impl TransactionalQ1Q2Config {
    pub fn validate(&self) -> CoreResult<()> {
        if self.threads == 0 || self.gmres_restart == 0 || self.gmres_max_arnoldi == 0 {
            return Err(CoreError::InvalidInput(
                "transactional q1/q2 thread and Krylov limits must be positive".into(),
            ));
        }
        if self.gmres_max_arnoldi < self.gmres_restart {
            return Err(CoreError::InvalidInput(
                "transactional q1/q2 max Arnoldi count must be at least the restart length".into(),
            ));
        }
        if ![
            self.gmres_rtol,
            self.gmres_atol,
            self.absolute_output_budget,
            self.embedded_budget_fraction,
            self.max_output_contraction,
            self.max_residual_contraction,
            self.max_target_relative_residual,
        ]
        .iter()
        .all(|value| value.is_finite() && *value >= 0.0)
        {
            return Err(CoreError::InvalidInput(
                "transactional q1/q2 tolerances contain invalid values".into(),
            ));
        }
        if !(self.absolute_output_budget > 0.0
            && self.embedded_budget_fraction > 0.0
            && self.max_output_contraction < 1.0
            && self.max_residual_contraction < 1.0
            && self.max_target_relative_residual > 0.0)
        {
            return Err(CoreError::InvalidInput(
                "transactional q1/q2 gate parameters lie outside their admissible ranges".into(),
            ));
        }
        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct TransactionalQ1Q2StepReport {
    pub step: StepResult,
    pub lane: TransactionalQ1Q2Lane,
    pub q1_gate: OperationalGateReport,
    pub q2_gate: Option<OperationalGateReport>,
    pub fast_accepted: bool,
    pub escalated: bool,
    pub fallback_reason: Option<String>,
    pub q1_candidate_y: Vec<f64>,
    pub q2_candidate_y: Option<Vec<f64>>,
    /// Common-W batches on the critical path (plus the stages of a
    /// fallback). Certificate work also runs after the q=2 candidate but is
    /// not a W batch: it is `work.certificate_operations`.
    pub critical_path_depth: u64,
    pub work: HomotopyWorkLedger,
    /// [`Q2Admission::name`].
    pub q2_admission: &'static str,
    pub q2_certificate: Option<Q2CertificateAdmission>,
    /// Certificate mode only: the q=2 candidate stages the certificate was
    /// attempted on, kept for research comparisons of certificate arms on
    /// the same candidate (research node
    /// `research/rnext06_homotopy_net_cost_20261003`).
    pub q2_candidate_stages: Option<Vec<Vec<f64>>>,
    /// Certificate mode only: the capability decided before the fast path
    /// (re-audit R4, R4-HOM-DEV-06). When unavailable, the q=2 escalation
    /// is skipped and a q=1 failure falls back at once.
    pub q2_capability: Option<WitnessCapability>,
}

#[derive(Clone, Debug, Default, PartialEq, Serialize)]
pub struct TransactionalQ1Q2RunDiagnostics {
    /// Every transactional attempt evaluates the q=1 path before any escalation or fallback.
    pub q1_path_attempts: usize,
    /// Attempts that reached the q=2 causal escalation, including attempts that later fell back.
    pub q2_path_attempts: usize,
    /// Final lane selected for the attempt after all transactional gates.
    pub selected_q1_fast_attempts: usize,
    pub selected_q2_escalated_attempts: usize,
    pub selected_sequential_fallback_attempts: usize,
    pub accepted_q1_fast_steps: usize,
    pub accepted_q2_escalated_steps: usize,
    pub accepted_sequential_fallback_steps: usize,
    pub total_w_solve_batches: u64,
    pub total_w_solve_vectors: u64,
    pub max_w_solve_batches_per_attempt: u64,
    pub accepted_w_solve_batches: Vec<u64>,
    pub total_critical_path_depth: u64,
    pub max_critical_path_depth_per_attempt: u64,
    pub accepted_critical_path_depths: Vec<u64>,
    pub attempted_lanes: Vec<TransactionalQ1Q2Lane>,
    /// Native-target certificate attempts, admissions and directed
    /// operations (re-audit R3, HOM-05). Omitted while zero.
    #[serde(skip_serializing_if = "is_zero_usize")]
    pub certificate_attempts: usize,
    #[serde(skip_serializing_if = "is_zero_usize")]
    pub certificate_admissions: usize,
    #[serde(skip_serializing_if = "is_zero_u64")]
    pub certificate_operations: u64,
    /// Accepted q2-escalated steps in certificate mode whose certificate did
    /// not admit them, counted per step; any nonzero value is a defect.
    #[serde(skip_serializing_if = "is_zero_usize")]
    pub certificate_mismatches: usize,
    /// Thread pools built during the run, every step included (re-audit R4,
    /// R4-HOM-DEV-04): at most 1 for an integration.
    pub pool_creations: u64,
    /// Certificate-mode attempts whose witness was unavailable by the
    /// dimension cutoff, or rejected by its constructor, and the q=2
    /// escalations skipped for either (re-audit R4, R4-HOM-DEV-06).
    #[serde(skip_serializing_if = "is_zero_usize")]
    pub capability_dimension_cutoffs: usize,
    #[serde(skip_serializing_if = "is_zero_usize")]
    pub capability_mathematical_rejects: usize,
    #[serde(skip_serializing_if = "is_zero_usize")]
    pub escalations_skipped_uncertifiable: usize,
}

fn is_zero_usize(value: &usize) -> bool {
    *value == 0
}

fn is_zero_u64(value: &u64) -> bool {
    *value == 0
}

impl TransactionalQ1Q2RunDiagnostics {
    pub(crate) fn record(&mut self, report: &TransactionalQ1Q2StepReport, accepted: bool) {
        match &report.q2_capability {
            Some(WitnessCapability::DimensionCutoff { .. }) => {
                self.capability_dimension_cutoffs += 1
            }
            Some(
                WitnessCapability::MathematicalReject { .. }
                | WitnessCapability::ProblemUnavailable { .. },
            ) => self.capability_mathematical_rejects += 1,
            _ => {}
        }
        if report
            .fallback_reason
            .as_deref()
            .is_some_and(|reason| reason.starts_with(CERTIFICATE_CAPABILITY_UNAVAILABLE))
        {
            self.escalations_skipped_uncertifiable += 1;
        }
        if let Some(admission) = &report.q2_certificate {
            self.certificate_attempts += 1;
            if admission.accepted {
                self.certificate_admissions += 1;
            }
        }
        if accepted
            && report.lane == TransactionalQ1Q2Lane::Q2Escalated
            && report.q2_admission == NATIVE_TARGET_CERTIFICATE_ADMISSION
            && !report
                .q2_certificate
                .as_ref()
                .is_some_and(|admission| admission.accepted)
        {
            self.certificate_mismatches += 1;
        }
        self.certificate_operations = self
            .certificate_operations
            .saturating_add(report.work.certificate_operations);
        self.pool_creations = self
            .pool_creations
            .saturating_add(report.work.pool_creations);
        self.total_w_solve_batches = self
            .total_w_solve_batches
            .saturating_add(report.work.w_solve_batches);
        self.total_w_solve_vectors = self
            .total_w_solve_vectors
            .saturating_add(report.work.w_solve_vectors);
        self.max_w_solve_batches_per_attempt = self
            .max_w_solve_batches_per_attempt
            .max(report.work.w_solve_batches);
        self.total_critical_path_depth = self
            .total_critical_path_depth
            .saturating_add(report.critical_path_depth);
        self.max_critical_path_depth_per_attempt = self
            .max_critical_path_depth_per_attempt
            .max(report.critical_path_depth);
        self.q1_path_attempts += 1;
        if report.escalated {
            self.q2_path_attempts += 1;
        }
        self.attempted_lanes.push(report.lane);
        match report.lane {
            TransactionalQ1Q2Lane::Q1Fast => {
                self.selected_q1_fast_attempts += 1;
                if accepted {
                    self.accepted_q1_fast_steps += 1;
                }
            }
            TransactionalQ1Q2Lane::Q2Escalated => {
                self.selected_q2_escalated_attempts += 1;
                if accepted {
                    self.accepted_q2_escalated_steps += 1;
                }
            }
            TransactionalQ1Q2Lane::SequentialFallback => {
                self.selected_sequential_fallback_attempts += 1;
                if accepted {
                    self.accepted_sequential_fallback_steps += 1;
                }
            }
        }
        if accepted {
            self.accepted_w_solve_batches
                .push(report.work.w_solve_batches);
            self.accepted_critical_path_depths
                .push(report.critical_path_depth);
        }
    }

    pub fn accepted_steps(&self) -> usize {
        self.accepted_q1_fast_steps
            + self.accepted_q2_escalated_steps
            + self.accepted_sequential_fallback_steps
    }

    pub fn fast_fraction(&self) -> f64 {
        let accepted = self.accepted_steps();
        if accepted == 0 {
            0.0
        } else {
            (self.accepted_q1_fast_steps + self.accepted_q2_escalated_steps) as f64
                / accepted as f64
        }
    }

    pub fn fallback_fraction(&self) -> f64 {
        let accepted = self.accepted_steps();
        if accepted == 0 {
            0.0
        } else {
            self.accepted_sequential_fallback_steps as f64 / accepted as f64
        }
    }
}

struct MatrixFreeCommonWSolver<'ctx, 'problem, 'exec> {
    context: &'ctx StepContext<'problem>,
    /// Owned by the caller for the whole integration (re-audit R4,
    /// R4-HOM-DEV-04): the solver never builds a pool.
    execution: &'exec ParallelExecution,
    gmres: GmresConfig,
}

impl<'ctx, 'problem, 'exec> MatrixFreeCommonWSolver<'ctx, 'problem, 'exec> {
    fn new(
        context: &'ctx StepContext<'problem>,
        config: &TransactionalQ1Q2Config,
        execution: &'exec ParallelExecution,
    ) -> CoreResult<Self> {
        if context.shifted.explicit().is_some() {
            return Err(CoreError::InvalidInput(
                "transactional q1/q2 fast path received an explicit shifted matrix".into(),
            ));
        }
        if execution.threads() != config.threads {
            return Err(CoreError::InvalidInput(format!(
                "transactional q1/q2: execution has {} threads, the config {}",
                execution.threads(),
                config.threads
            )));
        }
        Ok(Self {
            context,
            execution,
            gmres: GmresConfig {
                restart: config.gmres_restart.min(context.problem.dimension.max(1)),
                max_arnoldi: config.gmres_max_arnoldi,
                rtol: config.gmres_rtol,
                atol: config.gmres_atol,
            },
        })
    }

    fn solve_rows(
        &self,
        rhs: &[Vec<f64>],
        counters: &mut WorkCounters,
        work: &mut HomotopyWorkLedger,
    ) -> CoreResult<Vec<Vec<f64>>> {
        let n = self.context.problem.dimension;
        if rhs.is_empty() || rhs.iter().any(|row| row.len() != n) {
            return Err(CoreError::Dimension(
                "transactional common-W RHS batch shape mismatch".into(),
            ));
        }
        let indices = (0..rhs.len()).collect::<Vec<_>>();
        let solved = self.execution.map_ordered(&indices, |&index| {
            let pc = IdentityPreconditioner::new(n);
            let mut local = WorkCounters::default();
            let report = solve_gmres(
                &self.context.shifted,
                &pc,
                &rhs[index],
                None,
                &self.gmres,
                &mut local,
            );
            Ok((report.map(|report| report.x), local))
        })?;
        counters.block_linear_solves += 1;
        work.w_solve_batches += 1;
        work.w_solve_vectors += rhs.len() as u64;
        let mut rows = Vec::with_capacity(rhs.len());
        let mut first_error = None;
        for (row, local) in solved {
            counters.block_linear_iterations = counters
                .block_linear_iterations
                .saturating_add(local.linear_iterations);
            counters.accumulate(local);
            match row {
                Ok(row) => rows.push(row),
                Err(error) if first_error.is_none() => first_error = Some(error),
                Err(_) => {}
            }
        }
        if let Some(error) = first_error {
            return Err(error);
        }
        Ok(rows)
    }
}

struct TruncatedInverseRows {
    sum: Vec<Vec<f64>>,
    last_term: Vec<Vec<f64>>,
}

fn truncated_inverse_rows_with_last_term(
    block: &StructuredBlockSystem<'_, '_>,
    solver: &MatrixFreeCommonWSolver<'_, '_, '_>,
    eta: f64,
    q: usize,
    rhs: &[Vec<f64>],
    counters: &mut WorkCounters,
    work: &mut HomotopyWorkLedger,
) -> CoreResult<TruncatedInverseRows> {
    if !eta.is_finite() || q >= block.s {
        return Err(CoreError::InvalidInput(
            "invalid matrix-free truncated-inverse parameters".into(),
        ));
    }
    let mut term = solver.solve_rows(rhs, counters, work)?;
    let mut sum = term.clone();
    if eta != 0.0 {
        for _ in 1..=q {
            let mut coupled = block.coupling_apply(&term, counters)?;
            work.coupling_actions += 1;
            for value in coupled.iter_mut().flatten() {
                *value *= eta;
            }
            term = solver.solve_rows(&coupled, counters, work)?;
            for (sum_row, term_row) in sum.iter_mut().zip(&term) {
                for (sum_value, term_value) in sum_row.iter_mut().zip(term_row) {
                    *sum_value += term_value;
                }
            }
        }
    }
    if sum.iter().flatten().all(|value| value.is_finite())
        && term.iter().flatten().all(|value| value.is_finite())
    {
        Ok(TruncatedInverseRows {
            sum,
            last_term: term,
        })
    } else {
        Err(CoreError::NonFinite(
            "matrix-free truncated inverse produced NaN/Inf".into(),
        ))
    }
}

fn truncated_inverse_rows(
    block: &StructuredBlockSystem<'_, '_>,
    solver: &MatrixFreeCommonWSolver<'_, '_, '_>,
    eta: f64,
    q: usize,
    rhs: &[Vec<f64>],
    counters: &mut WorkCounters,
    work: &mut HomotopyWorkLedger,
) -> CoreResult<Vec<Vec<f64>>> {
    Ok(truncated_inverse_rows_with_last_term(block, solver, eta, q, rhs, counters, work)?.sum)
}

fn weighted_stage_update(weights: &[f64], rows: &[Vec<f64>], n: usize) -> Vec<f64> {
    let mut output = vec![0.0; n];
    for (&weight, row) in weights.iter().zip(rows) {
        for (value, increment) in output.iter_mut().zip(row) {
            *value += weight * increment;
        }
    }
    output
}

fn candidate_output(context: &StepContext<'_>, stages: &[Vec<f64>]) -> Vec<f64> {
    let update = weighted_stage_update(&context.coeffs.b, stages, context.problem.dimension);
    context
        .y
        .iter()
        .zip(update)
        .map(|(base, increment)| base + increment)
        .collect()
}

fn embedded_error(
    context: &StepContext<'_>,
    stages: &[Vec<f64>],
    atol: f64,
    rtol: f64,
) -> CoreResult<f64> {
    let output = candidate_output(context, stages);
    let error = weighted_stage_update(&context.coeffs.btilde, stages, context.problem.dimension);
    let scale = error_scale(&context.y, &output, &[atol], rtol)?;
    wrms(&error, &scale)
}

fn output_correction_wrms(
    context: &StepContext<'_>,
    candidate: &[Vec<f64>],
    correction: &[Vec<f64>],
    atol: f64,
    rtol: f64,
) -> CoreResult<f64> {
    let output = candidate_output(context, candidate);
    let projected = weighted_stage_update(&context.coeffs.b, correction, context.problem.dimension);
    let scale = error_scale(&context.y, &output, &[atol], rtol)?;
    wrms(&projected, &scale)
}

fn operational_gate(
    config: &TransactionalQ1Q2Config,
    residual_before: f64,
    residual_after: f64,
    target_rhs_norm: f64,
    previous_output_correction_wrms: f64,
    last_output_correction_wrms: f64,
    embedded_error: f64,
) -> OperationalGateReport {
    let finite = [
        residual_before,
        residual_after,
        target_rhs_norm,
        previous_output_correction_wrms,
        last_output_correction_wrms,
        embedded_error,
    ]
    .iter()
    .all(|value| value.is_finite());
    let target_residual_ratio = residual_after / residual_before.max(f64::MIN_POSITIVE);
    let target_relative_residual = residual_after / target_rhs_norm.max(f64::MIN_POSITIVE);
    let output_contraction = if previous_output_correction_wrms <= f64::MIN_POSITIVE {
        if last_output_correction_wrms <= f64::MIN_POSITIVE {
            0.0
        } else {
            f64::INFINITY
        }
    } else {
        last_output_correction_wrms / previous_output_correction_wrms
    };
    let contraction_tail_wrms = if output_contraction < 1.0 {
        last_output_correction_wrms / (1.0 - output_contraction)
    } else {
        f64::INFINITY
    };
    // The embedded RODAS5P estimator is dimensionless.  Raising it to 6/5 forces the
    // algebraic-tail allowance to shrink like a fifth-order method's local O(h^6) defect when
    // the embedded difference scales as O(h^5), while the absolute cap preserves a bounded
    // tolerance-relative fallback in coarse regimes.
    let output_budget = config.absolute_output_budget.min(
        config.embedded_budget_fraction * embedded_error.max(1024.0 * f64::EPSILON).powf(6.0 / 5.0),
    );
    let residual_gate = target_relative_residual <= config.max_target_relative_residual
        || target_residual_ratio <= config.max_residual_contraction;
    let accepted = finite
        && output_contraction <= config.max_output_contraction
        && residual_gate
        && contraction_tail_wrms <= output_budget;
    let reason = if !finite {
        "nonfinite diagnostic"
    } else if output_contraction > config.max_output_contraction {
        "output correction did not contract"
    } else if !residual_gate {
        "target residual is neither small nor contracting"
    } else if contraction_tail_wrms > output_budget {
        "correction tail above order-aware budget"
    } else {
        "operational gate passed"
    }
    .to_string();
    OperationalGateReport {
        accepted,
        reason,
        finite,
        target_residual_before: residual_before,
        target_residual_after: residual_after,
        target_residual_ratio,
        target_relative_residual,
        previous_output_correction_wrms,
        last_output_correction_wrms,
        output_contraction,
        contraction_tail_wrms,
        embedded_error,
        output_budget,
    }
}

fn build_step_certificate(
    gate: &OperationalGateReport,
    iterations: usize,
    reason_prefix: &str,
) -> StepCertificate {
    StepCertificate {
        accepted: gate.accepted,
        reason: format!("{reason_prefix}: {}", gate.reason),
        iterations,
        embedded_error: gate.embedded_error,
        fixed_point_error: gate.contraction_tail_wrms,
        residual_proxy_error: gate.target_relative_residual,
        contraction_tail_error: Some(gate.contraction_tail_wrms),
        observed_contraction: Some(gate.output_contraction),
        stage_residual_norm: gate.target_residual_after,
        stage_relative_residual: gate.target_relative_residual,
    }
}

struct FastPathSuccess {
    stages: Vec<Vec<f64>>,
    q1_candidate_y: Vec<f64>,
    q2_candidate_y: Option<Vec<f64>>,
    lane: TransactionalQ1Q2Lane,
    q1_gate: OperationalGateReport,
    q2_gate: Option<OperationalGateReport>,
    active_gate: OperationalGateReport,
    escalated: bool,
    q2_certificate: Option<Q2CertificateAdmission>,
}

struct FastPathFailure {
    error: CoreError,
    q1_gate: Option<OperationalGateReport>,
    q2_gate: Option<OperationalGateReport>,
    escalated: bool,
}

fn failed_operational_gate(reason: impl Into<String>) -> OperationalGateReport {
    OperationalGateReport {
        accepted: false,
        reason: reason.into(),
        finite: false,
        target_residual_before: f64::INFINITY,
        target_residual_after: f64::INFINITY,
        target_residual_ratio: f64::INFINITY,
        target_relative_residual: f64::INFINITY,
        previous_output_correction_wrms: f64::INFINITY,
        last_output_correction_wrms: f64::INFINITY,
        output_contraction: f64::INFINITY,
        contraction_tail_wrms: f64::INFINITY,
        embedded_error: f64::INFINITY,
        output_budget: 0.0,
    }
}

/// Lower bound on `min(absolute, fraction * max(e, 1024 eps)^(6/5))`.
fn certified_q2_budget(config: &TransactionalQ1Q2Config, embedded_lower: f64) -> CoreResult<f64> {
    let x = embedded_lower.max(1024.0 * f64::EPSILON);
    // r <= x^(1/5): step down until r^5 <= x holds with upward rounding.
    let mut r = x.powf(0.2);
    loop {
        let fifth = mul_up(mul_up(mul_up(mul_up(r, r)?, r)?, r)?, r)?;
        if fifth <= x {
            break;
        }
        r = r.next_down();
    }
    Ok(config
        .absolute_output_budget
        .min(mul_down(config.embedded_budget_fraction, mul_down(x, r)?)?))
}

/// Certificate admission of the q=2 candidate; every failure rejects.
#[allow(clippy::too_many_arguments)]
fn certify_q2_candidate(
    context: &StepContext<'_>,
    source: &dyn Q2CertificateSource,
    prepared: Option<&PreparedQ2Certificate>,
    stages: &[Vec<f64>],
    config: &TransactionalQ1Q2Config,
    atol: f64,
    rtol: f64,
    counters: &mut WorkCounters,
    work: &mut HomotopyWorkLedger,
) -> Q2CertificateAdmission {
    work.certificate_attempts += 1;
    let mut attempt = || -> CoreResult<(StageCertificate, f64)> {
        if !context.problem.autonomous
            || context.ft0.iter().any(|value| *value != 0.0)
            || context.problem.mass_matrix.is_some()
        {
            return Err(CoreError::InvalidInput(
                "the certificate covers autonomous identity-mass problems only".into(),
            ));
        }
        // The prepared problem of this attempt, or the dense one built here.
        let built;
        let problem = match prepared {
            Some(prepared) => match &prepared.problem {
                Ok(problem) => problem,
                Err(error) => return Err(CoreError::InvalidInput(error.to_string())),
            },
            None => {
                built = PreparedStageProblem::Dense(
                    source.stage_problem(context.t, &context.y, context.h)?,
                );
                &built
            }
        };
        let n = context.problem.dimension;
        if problem.h().to_bits() != context.h.to_bits()
            || problem.y().len() != n
            || problem.q().len() != n
            || problem
                .y()
                .iter()
                .zip(&context.y)
                .any(|(a, b)| a.to_bits() != b.to_bits())
        {
            return Err(CoreError::InvalidInput(
                "the certificate problem is not this step's (y, h)".into(),
            ));
        }
        // Consistency with the integrated ODE: f(y) = J y - q y^2 and the
        // JVP on the first stage direction.
        let direction = &stages[0];
        let mut jvp = vec![0.0; n];
        context.jacobian.apply(direction, &mut jvp)?;
        let (y0, q) = (problem.y(), problem.q());
        for a in 0..n {
            let (mut jy, mut jy_scale, mut jd, mut jd_scale) = (-0.0, -0.0, -0.0, -0.0);
            problem.for_each_entry(a, |b, j| {
                jy += j * y0[b];
                jy_scale += (j * y0[b]).abs();
                jd += j * direction[b];
                jd_scale += (j * direction[b]).abs();
            });
            let quadratic = q[a] * y0[a] * y0[a];
            let model_f = jy - quadratic;
            let tolerance =
                |scale: f64| 64.0 * f64::EPSILON * (n as f64) * scale + f64::MIN_POSITIVE;
            if (model_f - context.f0[a]).abs() > tolerance(jy_scale + quadratic.abs())
                || (jd - jvp[a]).abs() > tolerance(jd_scale)
            {
                return Err(CoreError::InvalidInput(format!(
                    "the certificate problem disagrees with the ODE in component {a}"
                )));
            }
        }
        let target = StageTarget::sequential(&context.coeffs)?;
        // The declared model must also reproduce the ODE at every candidate
        // stage state y + sum_{j<i} alpha_ij K_j, where a cubic or
        // unconstrained quadratic term would show (re-audit R3 review). This
        // is still a consistency check between the model and the ODE, not a
        // proof that they agree near the exact root.
        let model_f0 = (0..n)
            .map(|a| {
                let mut jy = -0.0;
                problem.for_each_entry(a, |b, j| jy += j * y0[b]);
                jy - q[a] * y0[a] * y0[a]
            })
            .collect::<Vec<_>>();
        for (i, alpha) in target.alpha_rows.iter().enumerate().skip(1) {
            let state = (0..n)
                .map(|a| {
                    context.y[a]
                        + alpha
                            .iter()
                            .zip(stages)
                            .map(|(coefficient, stage)| coefficient * stage[a])
                            .sum::<f64>()
                })
                .collect::<Vec<_>>();
            let actual = context.problem.eval_rhs(context.t, &state, counters)?;
            let d = state
                .iter()
                .zip(&context.y)
                .map(|(s, y)| s - y)
                .collect::<Vec<_>>();
            for a in 0..n {
                let (mut jd, mut jd_scale) = (-0.0, -0.0);
                problem.for_each_entry(a, |b, j| {
                    jd += j * d[b];
                    jd_scale += (j * d[b]).abs();
                });
                let quadratic = q[a] * d[a] * d[a];
                let model = model_f0[a] + jd + quadratic;
                let scale = model_f0[a].abs() + jd_scale + quadratic.abs() + actual[a].abs();
                if !actual[a].is_finite()
                    || (model - actual[a]).abs()
                        > 64.0 * f64::EPSILON * (n as f64) * scale + f64::MIN_POSITIVE
                {
                    return Err(CoreError::InvalidInput(format!(
                        "the certificate model disagrees with the ODE at stage {i}, component {a}"
                    )));
                }
            }
        }
        let built_witness;
        let witness = match prepared {
            Some(prepared) => match &prepared.witness {
                Some(Ok(witness)) => witness,
                Some(Err(error)) => return Err(CoreError::InvalidInput(error.to_string())),
                None => {
                    return Err(CoreError::InvalidInput(
                        "the prepared certificate has no witness".into(),
                    ));
                }
            },
            None => match problem {
                PreparedStageProblem::Dense(problem) => {
                    built_witness = source.witness(problem, target.gamma)?;
                    &built_witness
                }
                PreparedStageProblem::Diagonal(problem) => {
                    built_witness = source.diagonal_witness(problem, target.gamma)?;
                    &built_witness
                }
            },
        };
        let y_hat = candidate_output(context, stages);
        let e_hat = weighted_stage_update(&context.coeffs.btilde, stages, n);
        let (certificate, bound_to) = match problem {
            PreparedStageProblem::Dense(problem) => {
                let certificate = certify_stage_target(
                    &target, problem, stages, &y_hat, &e_hat, witness, atol, rtol,
                )?;
                let bound = certificate.is_bound_to(
                    &target,
                    problem,
                    stages,
                    &y_hat,
                    &e_hat,
                    witness.identity(),
                    atol,
                    rtol,
                );
                (certificate, bound)
            }
            PreparedStageProblem::Diagonal(problem) => {
                let certificate = certify_stage_target_diagonal(
                    &target, problem, stages, &y_hat, &e_hat, witness, atol, rtol,
                )?;
                let bound = certificate.is_bound_to_diagonal(
                    &target,
                    problem,
                    stages,
                    &y_hat,
                    &e_hat,
                    witness.identity(),
                    atol,
                    rtol,
                );
                (certificate, bound)
            }
        };
        if certificate.target_id != STAGE_TARGET_SEQUENTIAL
            || certificate.candidate_sha256 != candidate_digest(stages)
            || !bound_to
        {
            return Err(CoreError::InvalidInput(
                "the certificate is not about this candidate on the native target".into(),
            ));
        }
        let budget = certified_q2_budget(config, certificate.embedded_target_wrms_lower)?;
        Ok((certificate, budget))
    };
    match attempt() {
        Ok((certificate, budget_lower)) => {
            work.certificate_operations = work
                .certificate_operations
                .saturating_add(certificate.directed_operations);
            let accepted = certificate.output_wrms_upper <= budget_lower;
            let binding = effective_binding(source, context.problem);
            Q2CertificateAdmission {
                accepted,
                model_binding: binding.clone(),
                reason: if accepted {
                    match binding {
                        ModelBinding::GeneratedFromModel { .. } => "native-target certificate of the generating quadratic model (RHS, JVP and certificate from one model) within the certified budget".into(),
                        ModelBinding::SampledAgreement => "native-target certificate of the declared model (checked against the ODE at the stage states, not proven equal) within the certified budget".into(),
                    }
                } else {
                    format!(
                        "ADMISSION_EQUIVALENCE_NOT_ESTABLISHED: certified output bound {:e} above budget {budget_lower:e}",
                        certificate.output_wrms_upper
                    )
                },
                certificate: Some(certificate),
                budget_lower,
            }
        }
        Err(error) => Q2CertificateAdmission {
            accepted: false,
            model_binding: effective_binding(source, context.problem),
            reason: format!("ADMISSION_EQUIVALENCE_NOT_ESTABLISHED: {error}"),
            certificate: None,
            budget_lower: 0.0,
        },
    }
}

#[allow(clippy::too_many_arguments)]
fn attempt_fast_path(
    context: &StepContext<'_>,
    block: &StructuredBlockSystem<'_, '_>,
    solver: &MatrixFreeCommonWSolver<'_, '_, '_>,
    config: &TransactionalQ1Q2Config,
    atol: f64,
    rtol: f64,
    admission: Q2Admission<'_>,
    q2_certifiable: bool,
    prepared: Option<&PreparedQ2Certificate>,
    counters: &mut WorkCounters,
    work: &mut HomotopyWorkLedger,
) -> Result<FastPathSuccess, Box<FastPathFailure>> {
    let mut q1_gate: Option<OperationalGateReport> = None;
    let mut q2_gate: Option<OperationalGateReport> = None;
    let mut escalated = false;
    macro_rules! fast_try {
        ($expression:expr) => {
            match $expression {
                Ok(value) => value,
                Err(error) => {
                    return Err(Box::new(FastPathFailure {
                        error,
                        q1_gate: q1_gate.clone(),
                        q2_gate: q2_gate.clone(),
                        escalated,
                    }));
                }
            }
        };
    }

    // Decoupled lambda=0 start and direct endpoint predictor.  eta=0 makes the q=1 tangent
    // solve one common-W batch; no q-dependent work is hidden in the start state.
    let mut stages = fast_try!(truncated_inverse_rows(
        block,
        solver,
        0.0,
        1,
        &block.rhs_base(),
        counters,
        work,
    ));
    let start = fast_try!(evaluate_partial_path(
        block, &stages, 0.0, 0.0, counters, work,
    ));
    let tangent = fast_try!(truncated_inverse_rows(
        block,
        solver,
        0.0,
        1,
        &start.tangent_rhs,
        counters,
        work,
    ));
    stages = fast_try!(add_scaled_rows(&stages, 1.0, &tangent, 0.0, None));

    let mut q1_corrections = Vec::with_capacity(2);
    let mut last_q1_causal_term = None;
    let mut residuals = Vec::with_capacity(3);
    for correction_index in 0..2 {
        let evaluation = fast_try!(evaluate_partial_path(
            block, &stages, 0.0, 1.0, counters, work,
        ));
        residuals.push(evaluation.target_residual_norm);
        let inverse = fast_try!(truncated_inverse_rows_with_last_term(
            block,
            solver,
            1.0,
            1,
            &evaluation.homotopy_residual,
            counters,
            work,
        ));
        if correction_index == 1 {
            last_q1_causal_term = Some(inverse.last_term.clone());
        }
        let correction_wrms = fast_try!(output_correction_wrms(
            context,
            &stages,
            &inverse.sum,
            atol,
            rtol,
        ));
        q1_corrections.push(correction_wrms);
        stages = fast_try!(add_scaled_rows(&stages, -1.0, &inverse.sum, 0.0, None));
        work.correction_rounds += 1;
    }
    let q1_final = fast_try!(evaluate_partial_path(
        block, &stages, 0.0, 1.0, counters, work,
    ));
    let q1_candidate_y = candidate_output(context, &stages);
    residuals.push(q1_final.target_residual_norm);
    let q1_embedded = fast_try!(embedded_error(context, &stages, atol, rtol));
    let q1_report = operational_gate(
        config,
        residuals[1],
        residuals[2],
        q1_final.target_rhs_norm,
        q1_corrections[0],
        q1_corrections[1],
        q1_embedded,
    );
    q1_gate = Some(q1_report.clone());
    if q1_report.accepted {
        return Ok(FastPathSuccess {
            stages,
            q1_candidate_y,
            q2_candidate_y: None,
            lane: TransactionalQ1Q2Lane::Q1Fast,
            q1_gate: q1_report.clone(),
            q2_gate,
            active_gate: q1_report,
            escalated,
            q2_certificate: None,
        });
    }

    if matches!(
        admission,
        Q2Admission::NativeTargetCertificate(_) | Q2Admission::PreparedStructuredCertificate(_)
    ) && !q2_certifiable
    {
        // No certificate can admit a q=2 candidate here: do not spend the
        // escalation batches on one (re-audit R4, R4-HOM-DEV-06).
        let gate = failed_operational_gate(format!(
            "{CERTIFICATE_CAPABILITY_UNAVAILABLE}: q=1 rejected ({}) and no witness exists for a q=2 certificate",
            q1_report.reason
        ));
        return Ok(FastPathSuccess {
            stages,
            q1_candidate_y,
            q2_candidate_y: None,
            lane: TransactionalQ1Q2Lane::Q1Fast,
            q1_gate: q1_report,
            q2_gate,
            active_gate: gate,
            escalated,
            q2_certificate: None,
        });
    }
    escalated = true;
    let q2_before = q1_final.target_residual_norm;
    // The q=1 endpoint and all prior common-W work are retained.  The second q=1 correction
    // already contains D^{-1}r + QD^{-1}r for its own residual.  One additional common-W
    // application computes Q^2D^{-1}r and upgrades that correction to q=2 without restarting
    // from the decoupled predictor.  This is the load-bearing 6 -> 7 batch escalation.
    let mut q2_rhs = fast_try!(block.coupling_apply(
        &last_q1_causal_term.expect("second q1 causal term is available"),
        counters,
    ));
    work.coupling_actions += 1;
    // eta=1 at the target endpoint.  Retain the explicit scaling loop so that a future
    // nonunit-endpoint extension cannot silently inherit this assumption.
    for value in q2_rhs.iter_mut().flatten() {
        *value *= 1.0;
    }
    let q2_correction = fast_try!(solver.solve_rows(&q2_rhs, counters, work));
    let q2_correction_wrms = fast_try!(output_correction_wrms(
        context,
        &stages,
        &q2_correction,
        atol,
        rtol,
    ));
    stages = fast_try!(add_scaled_rows(&stages, -1.0, &q2_correction, 0.0, None,));
    work.correction_rounds += 1;
    let q2_final = fast_try!(evaluate_partial_path(
        block, &stages, 0.0, 1.0, counters, work,
    ));
    let q2_candidate_y = Some(candidate_output(context, &stages));
    if let Q2Admission::NativeTargetCertificate(source)
    | Q2Admission::PreparedStructuredCertificate(source) = admission
    {
        // The candidate is final here: no eighth batch, nothing applied.
        let q2_embedded = fast_try!(embedded_error(context, &stages, atol, rtol));
        let admitted = certify_q2_candidate(
            context, source, prepared, &stages, config, atol, rtol, counters, work,
        );
        let bound = admitted
            .certificate
            .as_ref()
            .map_or(f64::INFINITY, |certificate| certificate.output_wrms_upper);
        let residual_after = q2_final.target_residual_norm;
        let q2_report = OperationalGateReport {
            accepted: admitted.accepted,
            reason: admitted.reason.clone(),
            finite: bound.is_finite() && residual_after.is_finite(),
            target_residual_before: q2_before,
            target_residual_after: residual_after,
            target_residual_ratio: residual_after / q2_before.max(f64::MIN_POSITIVE),
            target_relative_residual: residual_after
                / q2_final.target_rhs_norm.max(f64::MIN_POSITIVE),
            previous_output_correction_wrms: q2_correction_wrms,
            last_output_correction_wrms: bound,
            output_contraction: bound / q2_correction_wrms.max(f64::MIN_POSITIVE),
            contraction_tail_wrms: bound,
            embedded_error: q2_embedded,
            output_budget: admitted.budget_lower,
        };
        q2_gate = Some(q2_report.clone());
        return Ok(FastPathSuccess {
            stages,
            q1_candidate_y,
            q2_candidate_y,
            lane: TransactionalQ1Q2Lane::Q2Escalated,
            q1_gate: q1_report,
            q2_gate,
            active_gate: q2_report,
            escalated,
            q2_certificate: Some(admitted),
        });
    }
    // One q=0 common-W diagnostic at the post-q2 residual estimates the *remaining* output
    // defect rather than reusing the magnitude of the correction that was already applied.
    // It is not applied to the state, so q=2 remains a single causal escalation; the eighth
    // batch is explicitly certificate work and is retained in the critical path ledger.
    let q2_diagnostic = fast_try!(solver.solve_rows(&q2_final.homotopy_residual, counters, work,));
    let q2_remaining_wrms = fast_try!(output_correction_wrms(
        context,
        &stages,
        &q2_diagnostic,
        atol,
        rtol,
    ));
    let q2_embedded = fast_try!(embedded_error(context, &stages, atol, rtol));
    let q2_report = operational_gate(
        config,
        q2_before,
        q2_final.target_residual_norm,
        q2_final.target_rhs_norm,
        q2_correction_wrms,
        q2_remaining_wrms,
        q2_embedded,
    );
    q2_gate = Some(q2_report.clone());
    Ok(FastPathSuccess {
        stages,
        q1_candidate_y,
        q2_candidate_y,
        lane: TransactionalQ1Q2Lane::Q2Escalated,
        q1_gate: q1_report,
        q2_gate,
        active_gate: q2_report,
        escalated,
        q2_certificate: None,
    })
}

#[allow(clippy::too_many_arguments)]
pub fn transactional_q1_q2_step(
    problem: &OdeProblem,
    t: f64,
    y: &[f64],
    h: f64,
    config: &TransactionalQ1Q2Config,
    atol: f64,
    rtol: f64,
    force_accept: bool,
    counters: &mut WorkCounters,
) -> CoreResult<TransactionalQ1Q2StepReport> {
    transactional_q1_q2_step_with_admission(
        problem,
        t,
        y,
        h,
        config,
        atol,
        rtol,
        force_accept,
        Q2Admission::OperationalDiagnostic,
        counters,
    )
}

/// [`transactional_q1_q2_step`] with an explicit q=2 admission. The q=1
/// lane, the seven batches that build the q=2 candidate and the sequential
/// fallback transaction are the same in both modes.
#[allow(clippy::too_many_arguments)]
pub fn transactional_q1_q2_step_with_admission(
    problem: &OdeProblem,
    t: f64,
    y: &[f64],
    h: f64,
    config: &TransactionalQ1Q2Config,
    atol: f64,
    rtol: f64,
    force_accept: bool,
    admission: Q2Admission<'_>,
    counters: &mut WorkCounters,
) -> CoreResult<TransactionalQ1Q2StepReport> {
    // A pool for this step only; an integration passes its own through
    // [`transactional_q1_q2_step_with_execution`].
    config.validate()?;
    let execution = ParallelExecution::rayon(config.threads)?;
    let mut report = transactional_q1_q2_step_with_execution(
        problem,
        t,
        y,
        h,
        config,
        atol,
        rtol,
        force_accept,
        admission,
        &execution,
        counters,
    )?;
    report.work.pool_creations += u64::from(execution.threads() > 1);
    Ok(report)
}

/// [`transactional_q1_q2_step_with_admission`] on a caller-owned
/// execution context (re-audit R4, R4-HOM-DEV-04): no thread pool is
/// created here, so an integration builds at most one. `execution` must
/// have `config.threads` threads; rows are solved in input order, so the
/// result is the same for any owner.
#[allow(clippy::too_many_arguments)]
pub fn transactional_q1_q2_step_with_execution(
    problem: &OdeProblem,
    t: f64,
    y: &[f64],
    h: f64,
    config: &TransactionalQ1Q2Config,
    atol: f64,
    rtol: f64,
    force_accept: bool,
    admission: Q2Admission<'_>,
    execution: &ParallelExecution,
    counters: &mut WorkCounters,
) -> CoreResult<TransactionalQ1Q2StepReport> {
    config.validate()?;
    let before = *counters;
    counters.fast_attempts += 1;
    let context = build_step_context_matrix_free(problem, t, y, h, counters)?;
    if context.shifted.explicit().is_some() || counters.jacobian_builds != before.jacobian_builds {
        return Err(CoreError::InvalidInput(
            "transactional q1/q2 path violated the explicit-J-free contract".into(),
        ));
    }
    let block = StructuredBlockSystem::new(&context);
    if block.s != 8 {
        return Err(CoreError::InvalidInput(
            "transactional q1/q2 path requires the 8-stage RODAS5P tableau".into(),
        ));
    }
    let solver = MatrixFreeCommonWSolver::new(&context, config, execution)?;
    let mut work = HomotopyWorkLedger {
        path_rounds: 1,
        ..HomotopyWorkLedger::default()
    };

    let prepared = match admission {
        Q2Admission::PreparedStructuredCertificate(source) => Some(PreparedQ2Certificate::prepare(
            source,
            context.t,
            &context.y,
            context.h,
            context.coeffs.gamma,
        )),
        _ => None,
    };
    let q2_capability = match admission {
        Q2Admission::PreparedStructuredCertificate(_) => {
            prepared.as_ref().map(PreparedQ2Certificate::capability)
        }
        Q2Admission::NativeTargetCertificate(source) => Some(
            match source.stage_problem(context.t, &context.y, context.h) {
                Ok(problem) => source.capability(&problem, context.coeffs.gamma),
                Err(error) => WitnessCapability::ProblemUnavailable {
                    reason: error.to_string(),
                },
            },
        ),
        Q2Admission::OperationalDiagnostic => None,
    };
    let q2_certifiable = q2_capability
        .as_ref()
        .is_none_or(WitnessCapability::is_available);
    let fast = attempt_fast_path(
        &context,
        &block,
        &solver,
        config,
        atol,
        rtol,
        admission,
        q2_certifiable,
        prepared.as_ref(),
        counters,
        &mut work,
    );
    let (
        mut lane,
        q1_gate,
        q2_gate,
        active_gate,
        fast_stages,
        q1_candidate_y,
        q2_candidate_y,
        escalated,
        mut fallback_reason,
        q2_certificate,
    ) = match fast {
        Ok(result) => (
            result.lane,
            result.q1_gate,
            result.q2_gate,
            result.active_gate,
            Some(result.stages),
            result.q1_candidate_y,
            result.q2_candidate_y,
            result.escalated,
            None,
            result.q2_certificate,
        ),
        Err(failure) => match failure.error {
            CoreError::NonFinite(_) | CoreError::LinearSolve(_) => {
                let reason = format!("speculative q1/q2 path failed: {}", failure.error);
                let gate = failure
                    .q2_gate
                    .clone()
                    .or_else(|| failure.q1_gate.clone())
                    .unwrap_or_else(|| failed_operational_gate(reason.clone()));
                (
                    TransactionalQ1Q2Lane::SequentialFallback,
                    failure
                        .q1_gate
                        .unwrap_or_else(|| failed_operational_gate(reason.clone())),
                    failure.q2_gate,
                    gate,
                    None,
                    Vec::new(),
                    None,
                    failure.escalated,
                    Some(reason),
                    None,
                )
            }
            error => return Err(error),
        },
    };
    let q2_candidate_stages = if q2_certificate.is_some() {
        fast_stages.clone()
    } else {
        None
    };

    let fast_path_accepted = active_gate.accepted && fast_stages.is_some();
    let mut step = if fast_path_accepted {
        counters.fast_accepts += 1;
        let certificate = build_step_certificate(
            &active_gate,
            work.correction_rounds,
            match lane {
                TransactionalQ1Q2Lane::Q1Fast => "q1-c2",
                TransactionalQ1Q2Lane::Q2Escalated => "q1-c2-plus-q2-c1",
                TransactionalQ1Q2Lane::SequentialFallback => unreachable!(),
            },
        );
        let mut step = finish_step(
            &context,
            fast_stages.expect("fast stages present for accepted fast path"),
            atol,
            rtol,
            match lane {
                TransactionalQ1Q2Lane::Q1Fast => "RODAS5P-transactional-q1-c2".into(),
                TransactionalQ1Q2Lane::Q2Escalated => "RODAS5P-transactional-q1-c2-q2-c1".into(),
                TransactionalQ1Q2Lane::SequentialFallback => unreachable!(),
            },
            None,
            false,
            Some(certificate),
            before,
            counters,
        )?;
        step.accepted = active_gate.accepted && (force_accept || step.error_norm <= 1.0);
        step
    } else {
        if fallback_reason.is_none() {
            fallback_reason = Some(active_gate.reason.clone());
        }
        lane = TransactionalQ1Q2Lane::SequentialFallback;
        counters.fallback_steps += 1;
        let fallback_config = LinearSolverConfig {
            method: LinearMethod::Gmres,
            rtol: config.gmres_rtol,
            atol: config.gmres_atol,
            restart: config.gmres_restart,
            maxiter: config.gmres_max_arnoldi,
            preconditioner: PreconditionerKind::None,
            x0_strategy: InitialGuess::Previous,
            ..LinearSolverConfig::default()
        };
        let data = sequential_stages(&context, &fallback_config, None, counters)?;
        finish_step(
            &context,
            data.stages,
            atol,
            rtol,
            "RODAS5P-protected-sequential-JF-fallback".into(),
            if force_accept { Some(true) } else { None },
            true,
            None,
            before,
            counters,
        )?
    };

    if step.accepted {
        counters.accepted_steps += 1;
    } else {
        counters.rejected_steps += 1;
    }
    step.used_fallback = lane == TransactionalQ1Q2Lane::SequentialFallback;
    step.counters = counters.delta(before);
    debug_assert_eq!(step.counters.jacobian_builds, 0);
    debug_assert_eq!(step.counters.direct_factorizations, 0);
    let fast_accepted = lane != TransactionalQ1Q2Lane::SequentialFallback && active_gate.accepted;
    let critical_path_depth = work.w_solve_batches
        + if lane == TransactionalQ1Q2Lane::SequentialFallback {
            context.coeffs.stages() as u64
        } else {
            0
        };
    Ok(TransactionalQ1Q2StepReport {
        step,
        lane,
        q1_gate,
        q2_gate,
        fast_accepted,
        escalated,
        fallback_reason,
        q1_candidate_y,
        q2_candidate_y,
        critical_path_depth,
        work,
        q2_admission: admission.name(),
        q2_certificate,
        q2_candidate_stages,
        q2_capability,
    })
}

#[cfg(test)]
mod tests {
    use std::sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    };

    use super::*;

    #[test]
    fn multi_row_failure_retains_later_row_shifted_work() {
        let applies = Arc::new(AtomicUsize::new(0));
        let jvp_applies = applies.clone();
        let problem = OdeProblem::new(
            "multi-row-accounting",
            1,
            Arc::new(|_t, _y, out| {
                out[0] = 0.0;
                Ok(())
            }),
            None,
            None,
            Some(Arc::new(move |_t, _y, v, out| {
                if jvp_applies.fetch_add(1, Ordering::SeqCst) == 0 {
                    return Err(CoreError::LinearSolve("first row injected failure".into()));
                }
                out[0] = v[0];
                Ok(())
            })),
            Some(Arc::new(|_t, _y, out| {
                out[0] = 0.0;
                Ok(())
            })),
            false,
            None,
            None,
        )
        .unwrap();
        let mut counters = WorkCounters::default();
        let context =
            build_step_context_matrix_free(&problem, 0.0, &[1.0], 0.1, &mut counters).unwrap();
        let execution = ParallelExecution::sequential();
        let solver =
            MatrixFreeCommonWSolver::new(&context, &TransactionalQ1Q2Config::default(), &execution)
                .unwrap();
        let mut work = HomotopyWorkLedger::default();

        let error = solver
            .solve_rows(&[vec![1.0], vec![2.0]], &mut counters, &mut work)
            .unwrap_err();

        assert!(error.to_string().contains("first row injected failure"));
        assert!(applies.load(Ordering::SeqCst) > 1);
        assert!(
            counters.linear_matvecs > 0,
            "later successful row applications must survive the first-row error"
        );
    }
}
