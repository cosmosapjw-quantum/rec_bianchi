"""Source-authentic scientific plots, no uncertainty claims."""
from pathlib import Path
import sys,os
os.environ['SOURCE_DATE_EPOCH']='0'
import numpy as np
import matplotlib
matplotlib.rcParams['svg.hashsalt']='rec_hd_public_flux_20261031'
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from public_flux_joint import read_rows
f=ROOT/'figures';f.mkdir(exist_ok=True)
rows=read_rows(ROOT/'outputs'/'PUBLIC_HD_104_CENSORED_WORKING_PROFILES.csv')
select=[r for r in rows if r['hd_lines_scope']=='all' and float(r['calibration_working_epsilon'])==0 and int(r['n_detected'])>0]
x=np.asarray([float(r['original_Neufeld_xhd_best']) for r in select]);y=np.asarray([float(r['new_conditioned_xhd_hat']) for r in select]);
fig,ax=plt.subplots(figsize=(6.7,5.4));ax.scatter(x,y)
a=min(x.min(),y.min())*0.7;b=max(x.max(),y.max())*1.3
ax.plot([a,b],[a,b],linestyle='--',label='Equal molecular ratio')
ax.set(xscale='log',yscale='log',xlim=(a,b),ylim=(a,b),xlabel='Neufeld (2026) published best-fit N(HD)/N(H2)',ylabel='Public-flux H2-anchor conditional molecular ratio',title='17 detected positions | two published H2 anchors')
ax.legend();fig.tight_layout()
for ext in ('.png','.svg'):fig.savefig(f/('HD_17_DETECTION_ABUNDANCE_WORKING_CHECK'+ext),dpi=170)
plt.close(fig)
trans=read_rows(ROOT/'outputs'/'H2_52_APERTURE_EFFECTIVE_TRANSMISSIONS.csv')
fig,ax=plt.subplots(figsize=(7.4,4.7))
for name in ('S(1)','S(2)'):
 r=[q for q in trans if q['H2_line']==name]
 ax.scatter(np.arange(len(r)),[float(q['effective_transmission']) for q in r],label=name)
ax.set(xlabel='Source aperture index (sorted)',ylabel='F_obs/(Omega * I_intrinsic)',title='Published-flux source-conditional H2 transfer, 1 arcsec aperture',ylim=(0,1.05));ax.legend();fig.tight_layout()
for ext in ('.png','.svg'):fig.savefig(f/('H2_52_EFFECTIVE_TRANSMISSIONS'+ext),dpi=170)
plt.close(fig)
print('Plots produced: 4 files')
