"""Physical aperture transmission and independent one-dimensional numeric oracle."""
import csv, math, sys, json
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from public_flux_joint import read_rows,save_rows,physical_templates,select,working_deviance


def run():
    lines=read_rows(ROOT/'source'/'H2_HD_364_INTRINSIC_LINE_ATLAS.csv'); groups={}
    for r in lines:groups.setdefault((r['source'],r['aperture']),[]).append(r)
    profiles=read_rows(ROOT/'outputs'/'PUBLIC_HD_104_CENSORED_WORKING_PROFILES.csv')
    omega=math.pi*(math.pi/(180*3600))**2
    transmissions=[];checks=[]
    for (source,aperture),g in sorted(groups.items()):
        a,f,s,base,hd_all=physical_templates(g)
        for anchor in a:
            r=anchor
            throughput_sr=float(r['reported_flux_1e15'])*1e-15/float(r['I_intrinsic_erg_cm2_s_sr'])
            transmission=throughput_sr/omega
            transmissions.append(dict(source=source,aperture=aperture,H2_line=r['line'],wavelength_um=r['wavelength_um'],observed_flux_1e15=r['reported_flux_1e15'],intrinsic_I_erg_cm2_s_sr=r['I_intrinsic_erg_cm2_s_sr'],assumed_filled_aperture_radius_arcsec=1,aperture_solid_angle_sr=omega,effective_transmission=transmission,conditional_tau_effective=-math.log(transmission),interpretation='model_dependent_combines_true_extinction_and_beam_or_aperture_effects'))
        for kind in ('all','bracket'):
            hd=select(hd_all,kind)
            for eps in (0.,0.06):
                one=minimize_scalar(lambda u:working_deviance((0,0,u),(f,s,base),hd,eps),bounds=(0,100),method='bounded',options={'xatol':1e-9})
                prof=next(row for row in profiles if (row['source'],row['aperture'],row['hd_lines_scope'],float(row['calibration_working_epsilon']))==(source,aperture,kind,eps))
                best=float(prof['objective_deviance'])
                checks.append(dict(source=source,aperture=aperture,scope=kind,eps=eps,one_dim_anchor_fixed_deviance=float(one.fun),full_3var_deviance=best,improvement_due_to_profiling=float(one.fun-best),independent_derivative_free_1d_oracle_PASS=bool(best<=one.fun+2e-5)))
    save_rows(ROOT/'outputs'/'H2_52_APERTURE_EFFECTIVE_TRANSMISSIONS.csv',transmissions)
    save_rows(ROOT/'verification'/'INDEPENDENT_104_ORACLE.csv',checks)
    summary={'aperture_radius_arcsec':1,'aperture_solid_angle_sr':omega,'transmission_rows':len(transmissions),'unphysical_transmission_over_1':sum(float(q['effective_transmission'])>1 for q in transmissions),'transmission_min':min(float(q['effective_transmission']) for q in transmissions),'transmission_max':max(float(q['effective_transmission']) for q in transmissions),'independent_oracle_rows':len(checks),'oracle_pass':sum(q['independent_derivative_free_1d_oracle_PASS'] for q in checks),'max_negative_profiling_delta':min(q['improvement_due_to_profiling'] for q in checks)}
    (ROOT/'verification'/'PHYSICAL_ORACLE_SUMMARY.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    return summary
if __name__=='__main__':print(json.dumps(run(),indent=2))
