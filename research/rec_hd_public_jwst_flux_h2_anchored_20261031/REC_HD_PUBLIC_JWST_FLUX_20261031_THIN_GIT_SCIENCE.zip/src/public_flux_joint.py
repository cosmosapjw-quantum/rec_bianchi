"""Francis 2025 *published-flux* H2-anchored HD working-likelihood atlas.

Uses original Francis final Appendix F + Neufeld 2026 v2 posterior-conditioned
non-LTE intrinsic emissivities from preceding source-locked atlas. This is a
new explicit statistical model with diagonal published flux errors and a
log-linear 12.28--17.03 micron empirical throughput transfer. It is NOT the
Neufeld author's likelihood, nor an independent full spectral covariance fit.
"""
from __future__ import annotations
import csv, json, math
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
from scipy.special import log_ndtr

ROOT=Path(__file__).resolve().parents[1]
X_UNIT=1e-5  # molecular N(HD)/N(H2), never elemental D/H
EPS_OPTIONS=(0.0,0.06)


def read_rows(path):
    with open(path,newline='') as f:return list(csv.DictReader(f))


def save_rows(path,rows):
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def wavelength_weight(lam,lam1,lam2):
    return math.log(lam/lam1)/math.log(lam2/lam1)


def select(aperture_rows,kind):
    if kind=='all':return aperture_rows[:]
    if kind=='bracket':return [r for r in aperture_rows if r['line'] in ('R(6)','R(7)','R(8)','R(9)')]
    raise ValueError('kind must be all or bracket')


def physical_templates(aperture_rows):
    by={(r['species'],r['line']):r for r in aperture_rows}
    anchors=(by[('H2','S(1)')],by[('H2','S(2)')])
    for r in anchors:
        assert r['reported_status']=='detected_positive_printed_error'
        assert float(r['reported_flux_1e15'])>0 and float(r['reported_sigma_1e15'])>0
    x0=float(anchors[0]['xhd_posterior'])
    if not (x0>0 and math.isfinite(x0)):raise ValueError('positive original molecular abundance required')
    lam1=float(anchors[0]['wavelength_um']);lam2=float(anchors[1]['wavelength_um'])
    f_anchor=np.array([float(r['reported_flux_1e15']) for r in anchors]);
    i_anchor=np.array([float(r['I_intrinsic_erg_cm2_s_sr']) for r in anchors]);
    s_anchor=np.array([float(r['reported_sigma_1e15']) for r in anchors]);
    if not (np.all(i_anchor>0) and np.all(s_anchor>0)):raise ValueError('invalid H2 anchor')
    gamma_anchor=np.log(f_anchor/i_anchor)
    hd=[]
    for r in aperture_rows:
        if r['species']!='HD':continue
        sig=r['reported_sigma_1e15']
        h=dict(source=r['source'],aperture=r['aperture'],line=r['line'],lambda_um=float(r['wavelength_um']),w=wavelength_weight(float(r['wavelength_um']),lam1,lam2),value=float(r['reported_flux_1e15']),status=r['reported_status'],sigma=float(sig) if sig!='' else float('nan'),intrinsic_per_x=float(r['I_intrinsic_erg_cm2_s_sr'])/x0)
        if h['status'] not in ('detected_positive_printed_error','detected_rounded_error_zero','upper_limit'):raise ValueError('unrecognized Francis source entry')
        hd.append(h)
    if len(hd)!=6:raise ValueError('six HD source lines expected')
    return anchors, f_anchor,s_anchor,gamma_anchor,hd


def predicted_lines(params,hd):
    delta1,delta2,u,base1,base2=params
    if u<0:raise ValueError('negative molecular abundance')
    # Each aperture has its own empirically transferred H2 throughput measured
    # in units of (1e-15 erg cm^-2 s^-1)/(erg cm^-2 s^-1 sr^-1).
    mu=[]
    for h in hd:
        loggamma=(1-h['w'])*params[3]+h['w']*params[4] + (1-h['w'])*delta1+h['w']*delta2
        mu.append(max(0.0,h['intrinsic_per_x'] * X_UNIT * u * math.exp(loggamma)))
    return np.asarray(mu)


def working_deviance(theta,meta,hd,eps):
    """Deviation from constant-detection Gaussian terms, with censor CDF.

    Two H2 observed anchors are fitted jointly, so shared H2 measurement noise
    enters through the same profiled log-throughput nuisance parameters.
    HD upper limit L is treated as a 3-sigma left-censor threshold, an explicit
    working assumption not guaranteed by the published source processing.
    """
    d1,d2,u=map(float,theta)
    if not math.isfinite(u) or u<0:return 1e250
    f_h2,s_h2,base_loggamma=meta
    mu_h2=f_h2*np.exp(np.array([d1,d2]))
    var_h2=s_h2**2 + (eps*mu_h2)**2
    out=float(np.sum((f_h2-mu_h2)**2/var_h2 + np.log(var_h2/s_h2**2)))
    params=np.r_[d1,d2,u,base_loggamma]
    mu_hd=predicted_lines(params,hd)
    for h,m in zip(hd,mu_hd):
        if h['status']=='detected_rounded_error_zero':continue
        if h['status']=='upper_limit':
            sigma0=h['value']/3.0
            if sigma0<=0:raise ValueError('nonpositive source upper limit')
            sigma=math.hypot(sigma0,eps*m)
            out-=2*float(log_ndtr((h['value']-m)/sigma))
        else:
            s=h['sigma'];
            if not (math.isfinite(s) and s>0):raise ValueError('invalid positive-error detection')
            var=s*s + (eps*m)**2
            out+=(h['value']-m)**2/var + math.log(var/(s*s))
    return float(out)


def fit_one(aperture_rows,kind,eps):
    anchors,f,s,loggam,hd_all=physical_templates(aperture_rows)
    hd=select(hd_all,kind)
    meta=(f,s,loggam)
    # finite bound on physical H2-anchoring perturbations; report boundary if hit.
    # abundance u in units 10^-5, xHD in [0, 10^-2] for broad exploratory search.
    bounds=[(-1.6094379124341003,1.6094379124341003)]*2+[(0,1000)]
    orig_x=float(anchors[0]['xhd_posterior']);start=orig_x/X_UNIT
    trials=[]
    for init in (0.0,max(start,1e-6),0.25,1.0,3.0,10.0):
        res=minimize(working_deviance,np.array([0.,0.,min(init,1000.)]),args=(meta,hd,eps),bounds=bounds,method='L-BFGS-B',options={'maxiter':350,'ftol':1e-12,'gtol':1e-8})
        if math.isfinite(res.fun):trials.append(res)
    if not trials:raise RuntimeError('no converged finite results')
    best=min(trials,key=lambda r:r.fun)
    if not best.success:
        # This only repairs the numerical line-search termination of the local
        # 3-variable working fit; source data or scientific assumptions unchanged.
        alt=minimize(working_deviance,best.x,args=(meta,hd,eps),bounds=bounds,
                     method='Powell',options={'maxiter':450,'xtol':1e-10,'ftol':1e-11})
        if alt.success and alt.fun<=best.fun+1e-6:
            best=alt
    # Explicit 1-d derivative free independent check at fixed H2 observed anchors.
    raw=np.r_[best.x,np.array(loggam)]
    pred=predicted_lines(raw,hd)
    upper=sum(h['status']=='upper_limit' for h in hd)
    detected=sum(h['status']=='detected_positive_printed_error' for h in hd)
    rounded=sum(h['status']=='detected_rounded_error_zero' for h in hd)
    source=aperture_rows[0]['source']; aperture=aperture_rows[0]['aperture']
    result=dict(source=source,aperture=aperture,hd_lines_scope=kind,calibration_working_epsilon=eps,n_detected=detected,n_upper_limits=upper,n_rounded_error_excluded=rounded,original_Neufeld_xhd_best=orig_x,new_conditioned_xhd_hat=float(best.x[2]*X_UNIT),ratio_to_author_posterior=float(best.x[2]*X_UNIT/orig_x),new_hd_scaled_u=float(best.x[2]),H2_S1_throughput_logoffset=float(best.x[0]),H2_S2_throughput_logoffset=float(best.x[1]),objective_deviance=float(best.fun),fit_optimizer_success=bool(best.success),optimizer_message=str(best.message),upper_grid_boundary=bool(best.x[2]>=999.999),H2_anchor_offset_boundary=bool(abs(best.x[0])>1.6094 or abs(best.x[1])>1.6094),physical_model='Neufeld2026_v2_published_posterior_fixed_T_n_N_OPR',attenuation_assumption='H2_S1_S2_loglambda_transfer_EXTRAPOLATE_R4_R5' if kind=='all' else 'H2_S1_S2_loglambda_interpolation_only',likelihood_assumption='source_reported_sigma_and_3sigma_censored_cdf_independent_errors',source_original_correlation_provided=False,physical_claim_admitted=False)
    rows=[]
    for h,m in zip(hd,pred):
        rows.append(dict(source=source,aperture=aperture,scope=kind,epsilon=eps,line=h['line'],lambda_um=h['lambda_um'],transfer_weight_w=h['w'],is_extrapolated=bool(h['w']<0 or h['w']>1),published_value_1e15=h['value'],published_error_1e15=h['sigma'] if math.isfinite(h['sigma']) else '',status=h['status'],working_prediction_1e15=float(m),observed_minus_working=float(h['value']-m) if h['status']=='detected_positive_printed_error' else '',prediction_is_data_conditioned=True))
    return result,rows


def run(root=ROOT):
    root=Path(root)
    inp=root/'source'/'H2_HD_364_INTRINSIC_LINE_ATLAS.csv'
    rows=read_rows(inp)
    if len(rows)!=364:raise ValueError('expected 364 source-authentic physical atlas rows')
    groups={}
    for r in rows:groups.setdefault((r['source'],r['aperture']),[]).append(r)
    if len(groups)!=26 or any(len(x)!=14 for x in groups.values()):raise ValueError('bad aperture-group join')
    out=[];pred=[]
    for k,aperture_rows in sorted(groups.items()):
        for kind in ('all','bracket'):
            for eps in EPS_OPTIONS:
                a,b=fit_one(aperture_rows,kind,eps)
                out.append(a);pred.extend(b)
    d=root/'outputs';d.mkdir(exist_ok=True,parents=True)
    save_rows(d/'PUBLIC_HD_104_CENSORED_WORKING_PROFILES.csv',out)
    save_rows(d/'PUBLIC_HD_520_LINE_PREDICTIONS.csv',pred)
    # a physically meaningful observable is a *published-flux working statistic*
    summary=dict(input_atlas_rows=len(rows),n_apertures=len(groups),profiles=len(out),predicted_HD_flux_rows=len(pred),scopes=['all','bracket'],calibration_working_eps=list(EPS_OPTIONS),source_censor_assumption='published three-sigma upper limit treated as Gaussian L/3',original_missing_full_covariance_not_required_for_scoped_working_likelihood=True,provenance='Francis2025_Zenodo14592550 + Neufeld2026_Zenodo21165907v2',xhd_is_molecular_not_elemental=True,canonical_DAG='28/88',REC_PHYSICAL_DAG='0/313',original_35hz='FAIL7/8',production='HOLD')
    for kind in ('all','bracket'):
        for eps in EPS_OPTIONS:
            x=[a for a in out if a['hd_lines_scope']==kind and a['calibration_working_epsilon']==eps]
            summary[f'{kind}_eps{eps}']=dict(n=len(x),success=sum(a['fit_optimizer_success'] for a in x),all_limit_apertures=sum(a['n_detected']==0 for a in x),nonzero_xhd=sum(a['new_conditioned_xhd_hat']>1e-12 for a in x),max_new_xhd=max(a['new_conditioned_xhd_hat'] for a in x),median_nonzero_xhd=float(np.median([a['new_conditioned_xhd_hat'] for a in x if a['n_detected']>0])) if any(a['n_detected']>0 for a in x) else None,upper_x_boundary_count=sum(a['upper_grid_boundary'] for a in x),H2_offset_boundary_count=sum(a['H2_anchor_offset_boundary'] for a in x))
    (d/'SUMMARY.json').write_text(json.dumps(summary,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
    return summary

if __name__=='__main__':print(json.dumps(run(),indent=2))
