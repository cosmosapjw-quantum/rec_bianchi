import sys,unittest,csv,math,json,hashlib
from pathlib import Path
from scipy.optimize import minimize_scalar
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import public_flux_joint as m

class SourceLockedTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.r=m.read_rows(ROOT/'source'/'H2_HD_364_INTRINSIC_LINE_ATLAS.csv')
  cls.g={}
  for r in cls.r:cls.g.setdefault((r['source'],r['aperture']),[]).append(r)
  cls.out=m.read_rows(ROOT/'outputs'/'PUBLIC_HD_104_CENSORED_WORKING_PROFILES.csv')
  cls.pred=m.read_rows(ROOT/'outputs'/'PUBLIC_HD_520_LINE_PREDICTIONS.csv')
 def test_original_h2_identity(self):
  b=(ROOT/'source'/'h2_population_grids.fits').read_bytes();self.assertEqual(hashlib.md5(b).hexdigest(),'cc652422aeb54f27899ddfc435cd93ae')
 def test_original_posterior_identity(self):
  b=(ROOT/'source'/'posterior_isobaric.csv.gz').read_bytes();self.assertEqual(hashlib.md5(b).hexdigest(),'f21c0527fcf00829ad95888887d20afd')
 def test_h2_hd_atlas_364_and_26(self):self.assertEqual((len(self.r),len(self.g)),(364,26))
 def test_census_immutable(self):
  from collections import Counter
  a=Counter((r['species'],r['reported_status']) for r in self.r)
  self.assertEqual(a[('H2','detected_positive_printed_error')],207);self.assertEqual(a[('H2','upper_limit')],1)
  self.assertEqual(a[('HD','detected_positive_printed_error')],76);self.assertEqual(a[('HD','upper_limit')],72)
  self.assertEqual(a[('HD','detected_rounded_error_zero')],8)
 def test_104_profiles(self):self.assertEqual(len(self.out),104)
 def test_520_predictions(self):self.assertEqual(len(self.pred),520)
 def test_no_source_amp_mutation(self):
  for r in self.r:self.assertGreater(float(r['I_intrinsic_erg_cm2_s_sr']),0)
 def test_h2_anchor_is_never_upper(self):
  for r in self.g.values():
   a,f,s,lg,h=m.physical_templates(r)
   self.assertTrue(all(x['reported_status']=='detected_positive_printed_error' for x in a))
 def test_same_source_xhd(self):
  for r in self.g.values():self.assertEqual(len({float(x['xhd_posterior']) for x in r}),1)
 def test_model_censors_exclude_eight(self):
  a=self.out
  self.assertEqual(sum(int(x['n_rounded_error_excluded']) for x in a if x['hd_lines_scope']=='all' and x['calibration_working_epsilon']=='0.0'),8)
 def test_loglam_endpoint(self):
  self.assertAlmostEqual(m.wavelength_weight(17.0,17.0,12.0),0)
  self.assertAlmostEqual(m.wavelength_weight(12.0,17.0,12.0),1)
 def test_upper_limits_monotone_at_zero_calibration(self):
  a,f,s,logs,h=m.physical_templates(self.g[('G28-IRS2','1')]);meta=(f,s,logs)
  self.assertEqual(sum(x['status']=='detected_positive_printed_error' for x in h),0)
  x=[m.working_deviance((0,0,u),meta,h,0) for u in [0,0.05,0.3,1.0]]
  self.assertTrue(all(a<=b for a,b in zip(x,x[1:])),x)
 def test_predicted_zero_xhd(self):
  _,_,_,logs,h=m.physical_templates(next(iter(self.g.values())))
  self.assertTrue(np.all(m.predicted_lines([0,0,0,*logs],h)==0))
 def test_H2_anchor_recovery(self):
  for r in list(self.g.values())[:6]:
   _,f,s,lg,h=m.physical_templates(r)
   self.assertLess(abs(m.working_deviance((0,0,0),(f,s,lg),[],0)),1e-15)
 def test_joint_fit_better_than_plug_in_1d_fit(self):
  # independent numeric optimization with H2 anchor throughput fixed, per fit.
  selected=list(self.g.items())[:4]
  for k,rows in selected:
   _,f,s,logs,allh=m.physical_templates(rows)
   for kind in ('all','bracket'):
    h=m.select(allh,kind)
    for eps in (0,0.06):
     one=minimize_scalar(lambda u:m.working_deviance((0,0,u),(f,s,logs),h,eps),bounds=(0,100),method='bounded',options={'xatol':1e-8})
     x=next(t for t in self.out if (t['source'],t['aperture'])==k and t['hd_lines_scope']==kind and float(t['calibration_working_epsilon'])==eps)
     self.assertLessEqual(float(x['objective_deviance']),one.fun+1e-5)
 def test_optimization_reports_success(self):self.assertTrue(all(x['fit_optimizer_success']=='True' for x in self.out))
 def test_xhd_nonnegative(self):self.assertTrue(all(float(x['new_conditioned_xhd_hat'])>=0 for x in self.out))
 def test_round_source_labels_preserved(self):
  for p in self.pred:
   if p['status']=='detected_rounded_error_zero':self.assertEqual(p['observed_minus_working'],'')
 def test_flux_predictions_finite(self):
  self.assertTrue(all(math.isfinite(float(p['working_prediction_1e15'])) and float(p['working_prediction_1e15'])>=0 for p in self.pred))
 def test_no_unjustified_credible_intervals(self):
  self.assertNotIn('xhd_credible_interval',self.out[0]);self.assertEqual(self.out[0]['physical_claim_admitted'],'False')
 def test_extrapolation_scope(self):
  self.assertTrue(all(p['is_extrapolated']=='False' for p in self.pred if p['scope']=='bracket'))
 def test_low_info_all_limit_zero(self):
  for x in self.out:
   if int(x['n_detected'])==0:self.assertLess(float(x['new_conditioned_xhd_hat']),1e-12)
 def test_bounds_not_active(self):
  self.assertEqual(sum(x['upper_grid_boundary']=='True' for x in self.out),0)
  self.assertEqual(sum(x['H2_anchor_offset_boundary']=='True' for x in self.out),0)
 def test_52_h2_transmissions(self):
  rows=m.read_rows(ROOT/'outputs'/'H2_52_APERTURE_EFFECTIVE_TRANSMISSIONS.csv')
  self.assertEqual(len(rows),52)
  self.assertTrue(all(0<float(r['effective_transmission'])<=1 for r in rows))
 def test_104_independent_oracle(self):
  z=m.read_rows(ROOT/'verification'/'INDEPENDENT_104_ORACLE.csv')
  self.assertEqual(len(z),104)
  self.assertTrue(all(x['independent_derivative_free_1d_oracle_PASS']=='True' for x in z))
 def test_physical_radian_solid_angle(self):
  z=json.loads((ROOT/'verification'/'PHYSICAL_ORACLE_SUMMARY.json').read_text())
  self.assertAlmostEqual(z['aperture_solid_angle_sr'],math.pi*(math.pi/(180*3600))**2,places=22)
 def test_no_dag_promotion(self):
  z=json.loads((ROOT/'outputs'/'SUMMARY.json').read_text())
  self.assertEqual((z['canonical_DAG'],z['REC_PHYSICAL_DAG'],z['original_35hz'],z['production']),('28/88','0/313','FAIL7/8','HOLD'))

if __name__=='__main__':unittest.main()
