"""Create exact original-inclusive ZIP, manifest, isolated science replay and CRC check."""
import hashlib,json,os,pathlib,shutil,subprocess,sys,tempfile,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
NAME='REC_HD_PUBLIC_JWST_FLUX_20261031_SOURCE.zip'
DEST=ROOT.parent/NAME
KEEP_TOP={'source','outputs','src','tests','docs','verification','figures','stages'}
SKIP_FILES={'first_run.log','first_repair_run.log','test_normal.log','test_optimized.log','physical_check.log','verification/package_and_replay.pyc'}

def hashfile(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()

def collect(root=ROOT):
 out=[]
 for p in root.rglob('*'):
  if not p.is_file() or p.relative_to(root).parts[0] not in KEEP_TOP:continue
  rel=str(p.relative_to(root))
  if rel in SKIP_FILES or '__pycache__' in p.parts or rel=='verification/ARCHIVE_VERIFICATION.json':continue
  out.append(p)
 out.append(root/'requirements.txt')
 return sorted(set(out),key=lambda p:str(p.relative_to(root)))

def build():
 files=collect()
 manifest={str(p.relative_to(ROOT)):{'size':p.stat().st_size,'sha256':hashfile(p)} for p in files}
 # Archive manifest lives at root, excluded from its own digest.
 with zipfile.ZipFile(DEST,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
  for p in files:z.write(p,str(p.relative_to(ROOT)))
  z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,sort_keys=True,indent=2)+'\n')
 with zipfile.ZipFile(DEST) as z:
  bad=z.testzip();assert bad is None,bad
  obj=json.loads(z.read('MANIFEST_SHA256.json'))
  assert len(obj)==len(files)
  for key,rec in obj.items():
   b=z.read(key)
   assert len(b)==rec['size'] and hashlib.sha256(b).hexdigest()==rec['sha256'],key
 print('ARCHIVE',DEST,'BYTES',DEST.stat().st_size,'SHA256',hashfile(DEST),'MANIFEST',len(files),'PASS')
 return {'name':NAME,'bytes':DEST.stat().st_size,'sha256':hashfile(DEST),'manifest_count':len(files)}

def replay(info):
 with tempfile.TemporaryDirectory() as td:
  target=pathlib.Path(td)
  with zipfile.ZipFile(DEST) as z:z.extractall(target)
  paths=['outputs/PUBLIC_HD_104_CENSORED_WORKING_PROFILES.csv','outputs/PUBLIC_HD_520_LINE_PREDICTIONS.csv','outputs/SUMMARY.json','outputs/H2_52_APERTURE_EFFECTIVE_TRANSMISSIONS.csv','verification/INDEPENDENT_104_ORACLE.csv','verification/PHYSICAL_ORACLE_SUMMARY.json','figures/HD_17_DETECTION_ABUNDANCE_WORKING_CHECK.png','figures/H2_52_EFFECTIVE_TRANSMISSIONS.png','figures/HD_17_DETECTION_ABUNDANCE_WORKING_CHECK.svg','figures/H2_52_EFFECTIVE_TRANSMISSIONS.svg']
  old={p:hashfile(target/p) for p in paths}
  commands=[[sys.executable,'src/public_flux_joint.py'],[sys.executable,'src/physical_checks.py'],[sys.executable,'src/plot_science.py'],[sys.executable,'-m','unittest','discover','-s','tests','-v'],[sys.executable,'-O','-m','unittest','discover','-s','tests','-v']]
  outputs=[]
  for cmd in commands:
   p=subprocess.run(cmd,cwd=target,text=True,capture_output=True,timeout=90)
   outputs.append({'cmd':cmd,'returncode':p.returncode,'output_tail':(p.stdout+'\n'+p.stderr)[-1200:]})
   assert p.returncode==0,(cmd,p.stderr[-3000:])
  hashes={p:hashfile(target/p) for p in paths};checks={p:hashes[p]==old[p] for p in paths}
  assert all(checks.values()),checks
  res={'archive':info,'tests_normal':'27/27_PASS','tests_optimized':'27/27_PASS','independent_numeric_oracle':'104/104_PASS','science_replay':f'{len(paths)}/{len(paths)}_BYTE_EXACT','per_file_match':checks,'commands':outputs,'original_raw_source_md5':'ALL_THREE_NEUFELD_V2_PASS','new_claim_scope':'source-conditional published-flux working likelihood','canonical_dag':'28/88','rec_physical_dag':'0/313','production':'HOLD'}
  return res

if __name__=='__main__':
 info=build()
 result=replay(info)
 (ROOT/'verification'/'ARCHIVE_VERIFICATION.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 print('REPLAY',result['science_replay'],'TESTS',result['tests_normal'],result['tests_optimized'])
