# REC-HD 공개 출판 선속 기반 joint H₂–HD likelihood 및 물리 데이터
2026-10-31 | `REC_HD_PUBLIC_JWST_FLUX_H2_ANCHORED_CENSORED_20261031` | **EXPLORATORY_PUBLISHED_FLUX_WORKING_LIKELIHOOD**

## 1. 원전, 기존 연구와 재사용

1. Francis et al., *JOYS: The [D/H] abundance derived from protostellar outflows across the Galactic disk measured with JWST*, A&A 694 A174 (2025), DOI:10.1051/0004-6361/202451629, 최종 부록 F 데이터 DOI:10.5281/zenodo.14592550. 26 aperture × (H₂ S1–S8 8선 + HD R4–R9 6선)=364 출판 측정 셀. 원본 논문의 관측 선속 표기는 `10^-15 erg cm^-2 s^-1`, 소광 보정 전이며 출판 분석은 원형 반경 1각초 aperture를 사용한다.
2. Neufeld, *Excitation of Warm HD and H2 and Implications for the Interstellar Deuterium Abundance*, ApJ 1007,16 (2026), DOI:10.3847/1538-4357/ae851a; 원본 Zenodo v2 DOI:10.5281/zenodo.21165907. 제공 H₂/HD 비LTE population FITS 원본 및 isobaric bestfit posterior를 참조. `log10(fJ/gJ)`라는 저장 규약, H₂ ortho/para 분리 정규화, collider OPR=3과 emitter OPR의 분리를 유지한다.
3. 선행 PR #176 전체 HD 29,640 profiles와 PR #178 364개 intrinsic line physics는 **읽고 재사용**하며, 29,640개를 재적합하지 않는다. 원본 분자 population, 선 에너지, Einstein-A, 두 성분 T, p, N, emitter OPR, 저자 xHD는 불변.
4. Pontoppidan et al. (2024), *A Constrained Dust Opacity for Models of Dense Clouds and Protostellar Envelopes*, Research Notes AAS 8, 68 DOI:10.3847/2515-5172/ad303f 는 공개된 기존 KP5 곡선의 원 논문. 이번 단위는 원본 KP5 numerical kernel을 확보했다고 주장하지 않으며 **H₂ 근접 파장 전달함수**로 한정한다.
5. 공인 JWST `spacetelescope/jwst`의 `calwebb_spec3`/`extract_1d`는 MAST x1d/s3d 데이터의 권위 있는 처리 코드다. STScI MIRI-MRS Known Issues 문서는 cube resampling이 covariance를 생성하며 ERR 배열이 완전한 cross-line covariance가 아님을 설명한다. 미공개 저자 fit covariance를 표준 `x1d`의 단순 오류 막대와 동일시하지 않는다.

## 2. 구성적 관측 forward 및 가정

앞선 물리 결과는 Neufeld 원본 물리에서 얻은 per-aperture intrinsic emission intensity `I_{a,j}(x0)`, 단위 `erg cm^-2 s^-1 sr^-1`이다. 저자 최적 molecular ratio를 `x0=N(HD)/N(H₂)`로 둔다. H₂의 두 기준선 `k=1,2`는 S(1) 17.03 μm, S(2) 12.28 μm로, 전 26개 위치에서 양의 오차를 가진 검출이다.

`gamma_{a,k}=F_{a,k}^{H2}/I_{a,k}^{H2}` 는 (10⁻¹⁵ cgs flux)/intrinsic surface brightness 단위이고, 물리적으로 `1e15 sr` 단위를 포함한다. H₂ anchor 진폭의 log nuisance δ_{a,k}를 추가해 `gamma'_{a,k}=gamma_{a,k} exp δ_{a,k}`. 가중치 `w_j=ln(λ_j/λ_{S1})/ln(λ_{S2}/λ_{S1})`와 `G_{a,j}=gamma'_{a,1}^{1-w_j} gamma'_{a,2}^{w_j}`를 정의하면,

```
mu_HD(a,j;x,delta)=I_HD(a,j;x0) * (x/x0) * G_a,j
mu_H2(a,k;delta)= F_H2(a,k) * exp(delta_k), k= S1,S2.
```

이는 원본 물리와 **실제 관측된 출판 H₂ 기준선의 상대 전달**을 결합한 새로운 측정 가능한 HD flux 예측이다. 전체 aperture 고유 solid angle과 smooth throughput가 함께 흡수된다. 1″ radius를 가정하면 Ω=7.38413463084415e-11 sr, 52개 H₂ anchor 유효 전달률 `F/(Ω I)`은 0.0059609–0.7548346로 모두 0–1 사이였다. 이는 원본 bestfit에 조건부인 기하·소광 sanity check일 뿐 KP5 검증이 아니다.

HD R(6)–R(9)은 anchor 안쪽 구간 12.28–17.03 μm에서 **내삽**한다. HD R(4),R(5)는 각각 23.03,19.43 μm로 구간 밖 **외삽**하므로 `all`과 `bracket`을 따로 실행한다. 파장 사이 ice/CO₂/continuum 특성은 통과시키지 못할 수 있으므로 모델 시스템오차로 유지한다.

## 3. 출판 오차로 정의한 censored 작업 likelihood

각 aperture에서는 H₂ 두 anchor와 HD 측정들을 **공동으로** 프로파일한다. 발견된 HD 양의 오차 검출 D에는 출판 F, σ를 그대로 사용하고, 출판 3σ upper limit U는 가정 σ_lim=L/3에 따른 좌측 censor CDF를 사용한다. HD의 8개 `σ=0.00` 반올림 인쇄 검출은 정밀도 0인 수치로 잘못 취급하지 않고 제외한다. 독립 오차 `ε=0` 또는 source-referenced 6%를 독립 **working** 분산으로 추가한 `ε=0.06` 두 민감도를 계산한다.

\[
\begin{split}
D_a(\delta_1,\delta_2,x)={}&\sum_{k=S1,S2}\left\{\frac{[F_k-\mu_k]^2}{s_k^2+\varepsilon^2\mu_k^2}+\ln\frac{s_k^2+\varepsilon^2\mu_k^2}{s_k^2}\right\}\\
&+\sum_{j\in D}\left\{\frac{[F_j-\mu_j]^2}{s_j^2+\varepsilon^2\mu_j^2}+\ln\frac{s_j^2+\varepsilon^2\mu_j^2}{s_j^2}\right\}\\
&-2\sum_{j\in U}\ln\Phi\left(\frac{L_j-\mu_j}{\sqrt{(L_j/3)^2+\varepsilon^2\mu_j^2}}\right).
\end{split}
\]

제약 `x ≥ 0`, `|δ1,2| ≤ ln 5`, `x ≤ 1e-2`를 명시하고 SciPy L-BFGS-B multistart, 비정상 line-search 때 Powell로 동일 목적함수를 수렴시킨다. 어떠한 상관 matrix도 출처 없이 주입하지 않았고, `ε=0.06`은 **공통 calibration systematic의 올바른 저차원 marginalization이 아니라** 출판 관행과 비교하는 diagonal 민감도다. H₂ anchor의 통계 오차는 δ1,2 동시 최적화에 포함되나 관측 선택·노이즈 covariance의 모든 상관은 포함되지 않는다.

전체 6선에서 26 위치, 2 epsilon → 52, 내삽 4선에서 26 위치, 2 epsilon → 52, 총 **104개 적합 및 520개 실제 HD 예측 행**. 기존 원본 저자 posterior의 T/n/N/OPR/압력은 *고정*이다. x의 최적값은 **molecular abundance working-fit point**일 뿐 elemental D/H나 신규 신뢰구간/유의도는 아니다.

## 4. 새 수치 데이터와 물리 비교

| 데이터 선택 | ε | 성공/26 | 양의 HD 검출 위치 | 비검출 x=0 위치 | 검출 위치 xHD 중앙값 |
|---|---:|---:|---:|---:|---:|
| HD 6선 전체 | 0 | 26 | 17 | 9 | 1.35011055e-5 |
| HD 6선 전체 | 0.06 | 26 | 17 | 9 | 1.39518842e-5 |
| 내삽 구간 R6–R9 | 0 | 26 | 16 | 10 | 1.45702937e-5 |
| 내삽 구간 R6–R9 | 0.06 | 26 | 16 | 10 | 1.45111942e-5 |

`all,ε=0`에서 검출 17개 위치의 Neufeld 원저자 bestfit molecular ratio와의 중앙 비는 **0.9600169**이나, 원저자 posterior 자체가 동일 Francis 데이터로 추정되었으므로 이는 독립 validation이나 Bayes factor가 아님. HD 비검출 9개는 unconstrained nonnegative amplitude의 최적값이 0이며 압력 추정이 아니라는 해석이 유지된다. `bracket`에서 양의 오차 검출 위치가 16개로 줄어드는 것은 R4/R5만의 검출 조합이 일부 존재하기 때문이다. IRAS 4B 일부 위치에서는 작업 deviance가 커지는 과학적 잔차가 남으며, 속단해서 확률적 이상검출이라 하지 않는다.

새 물리 파일:
- `PUBLIC_HD_104_CENSORED_WORKING_PROFILES.csv`: 104 profiles 및 source/선/ε/계수/상태.
- `PUBLIC_HD_520_LINE_PREDICTIONS.csv`: 실제 출판 flux, upper limit, working model flux, 내삽·외삽 플래그를 가진 520행.
- `H2_52_APERTURE_EFFECTIVE_TRANSMISSIONS.csv`: 관측된 두 기준선의 물리적 전달률 52행.
- `INDEPENDENT_104_ORACLE.csv`: 104번, 별도 derivative-free 1D 고정-anchor 비교.
- 물리 그래프 PNG/SVG 4개.

## 5. 실행 검증 및 blind referee

- ZIP 원본에서 재사용한 364개 비LTE 고유 방출강도와 원본 H₂ FITS MD5 `cc6524...`, 원저자 posterior MD5 `f21c05...`의 소스 바이트 보호.
- `python -m unittest discover -s tests -v`: 27/27 PASS; `python -O -m unittest ...`: 27/27 PASS.
- 전 104 적합에 대해 별도 SciPy `minimize_scalar(method='bounded')` 고정 H₂ anchor 수치 oracle 104/104 통과. 3변수 full profiling 목적함수는 1차원 고정-anchor 최적값보다 높지 않음. `max_negative_profiling_delta=9e-14`는 부동소수 오차 범위.
- 26×2 H₂ anchor transmission 52개 모두 0≤transmission≤1 및 원형 1″ Ω 차원 재검산.
- 자체 적대적 검토: (1) 원저자 T,n,N,OPR를 동일 관측에서 고정했으므로 independence 없음; (2) 연속 attenuation/beam 추정이 개별 기능을 분해하지 않음; (3) 19–23μm R4/R5 외삽 위험; (4) 6% calibration 독립 가정은 계측기 correlated systematic 대체 아님; (5) L/3 upper noise는 공개 논문에서 명시한 3σ 분류의 작업용 매핑, selection likelihood 아님; (6) 8 반올림 오차 감지값 누락; (7) pressure, density, chemistry, [D/H]는 새로 추론하지 않음; (8) 35Hz 원래 실패 보존; (9) native 별도 저자 R6/C9 NOT_RUN; (10) 원본 GitHub `verify_repo_quick` CI 실패는 구 연구 SVG/CSV whitespace/EOF 진단이고 이 과학 검산의 PASS가 CI 성공을 대체하지 않는다.

## 6. 판정과 다음 최소 연구

새 보조 연구는 **scoped science 1/1 완료**로 분류하되 canonical 28/88, REC physical 0/313, R/C 18/20, original 35Hz FAIL7/8을 그대로 유지한다. Production HOLD, no merge/source switch/35Hz relaxation, auto_next false.

다음 경로는 미공개 저자 covariance를 대기하는 것이 아니라 (a) 공개 KP5 optical numerical table 혹은 문헌 근거 alternative curve를 출처 고정해 2-H₂-anchor 근사의 외삽 시스템오차를 정량화, (b) 이미 공개된 Neufeld isochoric posterior 원본 파일을 추가해 source-conditional model 비교, (c) 마찬가지로 공개 Francis 364측정 오차를 사용하여 일부 nuisance parameter를 source grid 내에서 재적합하되 prior/bounds와 model inadequacy를 보존하는 것이다. 별도 저자 교신은 optional 후속 확증이며 workflow blocker가 아니다.
