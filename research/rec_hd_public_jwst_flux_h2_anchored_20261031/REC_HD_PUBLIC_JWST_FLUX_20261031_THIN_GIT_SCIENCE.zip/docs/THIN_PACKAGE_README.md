# THIN GitHub science bundle

The GitHub binary object contains the new code, 104 published-flux working profiles, 520 HD flux predictions, 52 H₂ transmitted flux ratios, figures, 20-stage ledger, and independently re-run numeric checks. It does **NOT** contain the original H₂/HD FITS, Francis 364-cell source CSV or old intrinsic atlas; all those are present in the **FULL** source package with MD5/SHA provenance.

Full ZIP: `REC_HD_PUBLIC_JWST_FLUX_20261031_SOURCE.zip` SHA256 `d67bbe7c497192fd33469ae860fa6813cdd45da8ec18fbc98025652e89833079`, 3,916,018 bytes, Google Drive file `1IHcSdyRDjD9kZCixZa8UE7Ys-fCjh8Gp`.

Reproduction: extract FULL ZIP, `python src/public_flux_joint.py`, `python src/physical_checks.py`, `python src/plot_science.py`, and `python -m unittest discover -s tests -v` (+ `python -O ...`). The THIN bundle is for inspection and **is not standalone runnable** without the listed source original bytes.

All results are **source-authentic posterior-conditioned working likelihood**, not independent observed JWST covariance or elemental D/H. `CANONICAL=28/88`, `REC_PHYSICAL=0/313`, `ORIGINAL_35HZ=FAIL7/8`, production HOLD. `NO_MERGE`.
