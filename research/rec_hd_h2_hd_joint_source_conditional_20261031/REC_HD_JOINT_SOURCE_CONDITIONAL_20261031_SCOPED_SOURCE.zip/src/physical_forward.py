"""Explicit optically thin H2 + HD flux forward operator, source-conditional.

Units: CGS with h in erg*s (retaining Planck constant explicitly), nu in Hz,
A in 1/s, column densities in cm^-2, beam solid angle in steradians,
output flux in 1e-15 erg cm^-2 s^-1 by default.

H2 ortho and para populations are normalized separately (the convention of
Neufeld 2026 v2 FITS).  Caller must supply authentic source grid fractions;
no H2 grid or measured JWST covariance is bundled or invented here.

The formula is valid for optically thin isotropic spontaneous emission and
specified extinction and beam coupling only; no trapping, chemistry evolution,
or fluorescence is modeled.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections.abc import Mapping, Sequence
import math
import numpy as np

PLANCK_ERG_S = 6.62607015e-27  # exact SI h converted to erg s
FLUX_UNIT = 1e-15  # erg cm^-2 s^-1 per printed flux unit


def level_fraction_from_source_logpop(log10_f_over_g: float, degeneracy: float) -> float:
    """Neufeld-v2 FITS convention: f_J = g_J * 10**LOGPOP, spin-isomer local."""
    x, g = float(log10_f_over_g), float(degeneracy)
    if not math.isfinite(x) or not math.isfinite(g) or g <= 0:
        raise ValueError("Missing/NaN or invalid source LOGPOP / degeneracy")
    f = g * 10.0 ** x
    if not math.isfinite(f) or f < 0.0 or f > 1.0 + 1e-12:
        raise ValueError("Source level fraction outside [0,1]")
    return f


@dataclass(frozen=True)
class Transition:
    name: str
    species: str  # one of 'H2' or 'HD'
    upper_j: int
    frequency_hz: float
    einstein_A_s_inv: float
    transmission: float = 1.0
    aperture_coupling: float = 1.0


@dataclass(frozen=True)
class Component:
    N_H2_cm2: float
    gas_D_over_H: float
    hd_fraction_of_gas_deuterium: float
    H2_OPR: float
    h2_para_population: Mapping[int, float]
    h2_ortho_population: Mapping[int, float]
    hd_population: Mapping[int, float]


def joint_flux_optically_thin(transitions: Sequence[Transition],
                              components: Sequence[Component],
                              aperture_omega_sr: float,
                              *, flux_unit: float = FLUX_UNIT) -> np.ndarray:
    """F_i = Ω/(4π flux_unit) T_i B_i hν_i A_i Σ_c N_{u,i,c}.

    N_{u,H2} = N_H2 * [OPR/(1+OPR) for odd J, 1/(1+OPR) for even J] * f_{J|spin}
    N_{u,HD} = 2*(D/H)_gas * ξ_HD * N_H2 * f_J^HD.

    ξ_HD is an explicit assumed molecular partition/depletion factor, NOT
    inferred observationally. This does not enforce H2 and HD collider OPR
    equality, which is a separate physical assumption of the input populations.
    """
    omega = float(aperture_omega_sr)
    unit = float(flux_unit)
    if not (math.isfinite(omega) and omega > 0 and math.isfinite(unit) and unit > 0):
        raise ValueError("Invalid aperture solid angle or flux units")
    for c in components:
        vals = (c.N_H2_cm2, c.gas_D_over_H, c.hd_fraction_of_gas_deuterium, c.H2_OPR)
        if not all(math.isfinite(float(z)) for z in vals):
            raise ValueError("Nonfinite component physical parameters")
        if c.N_H2_cm2 < 0 or not 0 <= c.gas_D_over_H <= 1 or not 0 <= c.hd_fraction_of_gas_deuterium <= 1 or c.H2_OPR < 0:
            raise ValueError("Unphysical component column/abundance/partition/OPR")
    flux = []
    for tr in transitions:
        if tr.species not in ('H2','HD') or not isinstance(tr.upper_j,int) or tr.upper_j < 1:
            raise ValueError("Unrecognized transition")
        vals = (tr.frequency_hz, tr.einstein_A_s_inv, tr.transmission, tr.aperture_coupling)
        if not all(math.isfinite(float(z)) for z in vals):
            raise ValueError("Nonfinite transition parameters")
        if tr.frequency_hz <= 0 or tr.einstein_A_s_inv <= 0 or not 0 <= tr.transmission <= 1 or not 0 <= tr.aperture_coupling <= 1:
            raise ValueError("Unphysical transition frequency/rate/attenuation/coupling")
        nuA=tr.frequency_hz*tr.einstein_A_s_inv
        Nupper=0.0
        for c in components:
            if tr.species == 'HD':
                n_molecule = 2.0*c.gas_D_over_H*c.hd_fraction_of_gas_deuterium*c.N_H2_cm2
                pop=c.hd_population
            else:
                ortho=tr.upper_j%2==1
                spin_w=(c.H2_OPR/(1.0+c.H2_OPR)) if ortho else (1.0/(1.0+c.H2_OPR))
                n_molecule=c.N_H2_cm2*spin_w
                pop=c.h2_ortho_population if ortho else c.h2_para_population
            f=float(pop[tr.upper_j])  # Fail on missing authentic grid population.
            if not math.isfinite(f) or not 0 <= f <= 1.0+1e-12:
                raise ValueError("Unphysical or unavailable level fractional population")
            Nupper+=n_molecule*f
        flux.append(omega * tr.transmission * tr.aperture_coupling * PLANCK_ERG_S * nuA * Nupper / (4.0*math.pi*unit))
    return np.asarray(flux,dtype=float)
