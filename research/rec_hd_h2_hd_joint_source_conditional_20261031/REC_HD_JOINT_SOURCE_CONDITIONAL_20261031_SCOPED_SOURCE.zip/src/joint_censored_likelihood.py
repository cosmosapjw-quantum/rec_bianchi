"""Scoped experimental H2+HD joint likelihood kernel.

Inputs must be fitted source-verified model fluxes and actual covariance; nothing in
this module substitutes Francis observational covariance or Neufeld H2 populations.
Units for all fluxes are user-provided but must be consistent; covariance has their square.
This code is not the original Francis/Neufeld likelihood, nor production REC.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.special import log_ndtr
from scipy.stats import multivariate_normal


@dataclass(frozen=True)
class JointLogLikelihood:
    value: float
    detected_logpdf: float
    censored_logprob: float
    n_detected: int
    n_upper: int
    method: str


def _spd_matrix(covariance, n: int):
    c = np.asarray(covariance, dtype=float)
    if c.shape != (n, n) or not np.all(np.isfinite(c)):
        raise ValueError("Covariance dimension mismatch or nonfinite elements")
    scale = float(np.max(np.abs(c))) if c.size else 1.0
    if not np.allclose(c, c.T, atol=1e-12 * scale, rtol=1e-12):
        raise ValueError("Covariance must be symmetric")
    c = (c + c.T) / 2
    try:
        np.linalg.cholesky(c)
    except np.linalg.LinAlgError as exc:
        raise ValueError("Covariance must be positive definite") from exc
    return c


def generative_calibration_covariance(means, statistical_covariance, design, calibration_covariance):
    """Sigma=Sigma_stat+diag(mu) B K B^T diag(mu).

    design[i,k] is the known sensitivity of line i to calibration mode k.
    K is the supplied covariance of calibration modes, not an invented 6% value.
    """
    mu = np.asarray(means, dtype=float)
    if mu.ndim != 1 or not np.all(np.isfinite(mu)):
        raise ValueError("Invalid means")
    n = len(mu)
    s = _spd_matrix(statistical_covariance, n)
    b = np.asarray(design, dtype=float)
    if b.ndim != 2 or b.shape[0] != n or not np.all(np.isfinite(b)):
        raise ValueError("Invalid calibration design")
    k = _spd_matrix(calibration_covariance, b.shape[1])
    g = mu[:, None] * b
    return _spd_matrix(s + (g @ k @ g.T), n)


def joint_censored_loglikelihood(means, covariance, detected_indices, detected_values,
                                  censored_indices, upper_limits, *, seed=137,
                                  maxpts=1000000, abseps=1e-8, releps=1e-8):
    """Log phi(y_D;mu_D,C_DD) + log Phi(L_U;mu_{U|D},C_{U|D}).

    The exact likelihood is valid *if* the supplied covariance/limits describe the
    actual generative measurement + reporting model.  For d>=2 non-diagonal
    censoring block, numerical multivariate CDF is approximate and seeded.
    """
    mu = np.asarray(means, dtype=float)
    if mu.ndim != 1 or not np.all(np.isfinite(mu)):
        raise ValueError("Invalid means")
    n = len(mu)
    cov = _spd_matrix(covariance, n)
    d = np.asarray(detected_indices, dtype=int)
    u = np.asarray(censored_indices, dtype=int)
    yd = np.asarray(detected_values, dtype=float)
    lim = np.asarray(upper_limits, dtype=float)
    if d.ndim != 1 or u.ndim != 1 or yd.shape != d.shape or lim.shape != u.shape:
        raise ValueError("Detection/censoring array shape mismatch")
    if len(d) + len(u) != n or sorted([int(i) for i in np.r_[d,u]]) != list(range(n)):
        raise ValueError("Every line must occur exactly once as detected or censored")
    if not np.all(np.isfinite(yd)) or not np.all(np.isfinite(lim)):
        raise ValueError("Invalid measurements or limits")

    if len(d):
        cdd = cov[np.ix_(d,d)]
        factor = cho_factor(cdd, lower=True, check_finite=True)
        resid = yd - mu[d]
        solve = cho_solve(factor,resid)
        logdet = 2 * np.log(np.diag(factor[0])).sum()
        logpdf = -0.5 * (len(d)*np.log(2*np.pi) + logdet + resid @ solve)
    else:
        logpdf = 0.0

    if len(u):
        cuu = cov[np.ix_(u,u)]
        if len(d):
            cud = cov[np.ix_(u,d)]
            cdu = cov[np.ix_(d,u)]
            conditional_mean = mu[u] + cud @ solve
            conditional_cov = cuu - cud @ cho_solve(factor,cdu)
        else:
            conditional_mean = mu[u]
            conditional_cov = cuu
        conditional_cov = _spd_matrix(conditional_cov,len(u))
        z = lim - conditional_mean
        if len(u) == 1:
            logcdf = float(log_ndtr(z[0]/np.sqrt(conditional_cov[0,0])))
            method = "univariate_analytic"
        elif np.max(np.abs(
                conditional_cov / np.sqrt(np.outer(np.diag(conditional_cov), np.diag(conditional_cov)))
                - np.eye(len(u)))) <= 1e-13:
            logcdf = float(np.sum(log_ndtr(z/np.sqrt(np.diag(conditional_cov)))))
            method = "diagonal_exact"
        else:
            # SciPy uses a seeded randomized/quasi-Monte Carlo Gaussian CDF.
            prob = float(multivariate_normal.cdf(lim, mean=conditional_mean,
                    cov=conditional_cov, maxpts=maxpts, abseps=abseps,
                    releps=releps, rng=np.random.default_rng(seed)))
            if prob <= 0 or prob > 1 or not np.isfinite(prob):
                raise FloatingPointError("MVN CDF underflow/invalid, precision not certified")
            logcdf = float(np.log(prob))
            method = "multivariate_cdf_numerical_seeded"
    else:
        logcdf = 0.0
        method = "detected_gaussian_exact"
    return JointLogLikelihood(float(logpdf+logcdf), float(logpdf), float(logcdf),len(d),len(u),method)


def validate_observation_inputs(rows, *, conditional_limit_noise=None):
    """Produce ordered detected/upper metadata, no fabricated measurement covariance.

    conditional_limit_noise can be a mapping (species,line)->sigma from a genuine
    analysis, or the literal 'printed_limit_over_3_scenario' only for an explicitly
    NONAUTHORITATIVE legacy sensitivity test. Rounded-zero entries remain excluded.
    """
    detections, limits, excluded = [], [], []
    for r in rows:
        key=(r['species'],r['line'])
        kind=r['status']
        if kind == 'detected_positive_printed_error':
            s=float(r['sigma_printed'])
            if s <= 0: raise ValueError("Detection with nonpositive printed error")
            detections.append({'key':key,'flux':float(r['value_printed']),'sigma':s})
        elif kind == 'upper_limit':
            l=float(r['value_printed'])
            if conditional_limit_noise is None:
                sn=None
            elif conditional_limit_noise == 'printed_limit_over_3_scenario':
                sn=l/3
            else:
                sn=float(conditional_limit_noise[key])
            if sn is not None and sn <= 0:
                raise ValueError("Invalid upper-limit noise")
            limits.append({'key':key,'limit':l,'sigma_conditional':sn})
        elif kind == 'detected_rounded_error_zero':
            excluded.append({'key':key, 'flux':float(r['value_printed'])})
        else:
            raise ValueError(f"Unknown observation category: {kind}")
    return {'detected':detections,'limits':limits,'excluded':excluded,
            'covariance_available':False,'measured_joint_likelihood_admissible':False}
