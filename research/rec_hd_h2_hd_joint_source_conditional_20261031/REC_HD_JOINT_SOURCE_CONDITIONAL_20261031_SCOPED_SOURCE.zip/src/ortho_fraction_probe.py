"""A *new small* original HD rate-source sensitivity experiment; no 29,640 rerun.

OPR=1.9 is an illustrative literature-population median, not a measured
collider OPR per aperture. Only exact source temperatures and original HD rates.
"""
import csv, hashlib, json, math, pathlib, sys
if len(sys.argv) != 3:
    raise SystemExit('usage: python src/ortho_fraction_probe.py <unpacked-original-source-ZIP-root> <output.csv>')
old=pathlib.Path(sys.argv[1]).resolve()
out=pathlib.Path(sys.argv[2]).resolve()
out.parent.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(old/'src'))
from hd_cmb15 import solve_cmb
from hd_line_transfer import read_models
source_files={'standard':old/'source/zenodo_v2/hd_lamda.dat',
'alternate':old/'source/zenodo_v2/hd_lamda_altex.dat'}
report=[];signatures={}
models=read_models(old)  # all four source bytes checked against inherited SHA values
for name,p in source_files.items():
    contents=p.read_bytes();model=models['std' if name == 'standard' else 'alternate']
    signatures[name]={'sha256':hashlib.sha256(contents).hexdigest(),'length':len(contents)}
    for T in [600.,1000.,2000.]:
        for n in [1e4,1e6,1e8]:
            results=[]
            for f in [0.75,1.9/2.9]:
                st=solve_cmb(model,T,n,0.,f_ortho=f)
                power={r['J_upper']-1:r['net_W_per_HD'] for r in st['line_power_records']}
                q=[power[J] for J in range(4,10)]
                if min(q)<=0:raise ValueError('Nonpositive line in experiment')
                results.append((q,st['max_stationary_residual_s_inverse']))
            a,b=results
            logratios=[math.log(x/y) for x,y in zip(b[0],a[0])]
            report.append({'source':name,'T_K':T,'nH2_cm3':n,
                'eta_original':0.75,'eta_OPR_1p9':1.9/2.9,
                'R4_fractional_change':b[0][0]/a[0][0]-1,
                'R9_fractional_change':b[0][-1]/a[0][-1]-1,
                'max_abs_line_fractional_change':max(abs(x/y-1) for x,y in zip(b[0],a[0])),
                'delta_log_shape':max(logratios)-min(logratios),
                'max_stationarity_residual_s_inv':max(a[1],b[1])})
with out.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(report[0]));w.writeheader();w.writerows(report)
print(json.dumps({'states':len(report),'source_hashes':signatures,
 'max_delta_log_shape':max(x['delta_log_shape'] for x in report),
 'max_fractional_line_change':max(x['max_abs_line_fractional_change'] for x in report),
 'max_stationarity_residual':max(x['max_stationarity_residual_s_inv'] for x in report),
 'R4_R9_cases':report},indent=2))
