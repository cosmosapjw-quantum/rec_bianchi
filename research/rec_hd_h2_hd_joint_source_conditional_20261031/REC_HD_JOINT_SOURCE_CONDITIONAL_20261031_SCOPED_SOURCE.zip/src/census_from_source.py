"""Creates source table inventory; never recalculates 29,640 existing HD profiles."""
import csv, json, hashlib, collections, pathlib, sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from joint_censored_likelihood import validate_observation_inputs

source=pathlib.Path(sys.argv[1])
out=pathlib.Path(sys.argv[2]);out.mkdir(exist_ok=True,parents=True)
rows=list(csv.DictReader(source.open(encoding='utf-8')))
groups=collections.defaultdict(list)
for r in rows:groups[r['source'],r['aperture']].append(r)
census=[]
for (name,aperture),group in sorted(groups.items()):
    parsed=validate_observation_inputs(group)
    def count(s,k): return sum(1 for r in group if r['species']==s and r['status']==k)
    census.append({'source':name,'aperture':int(aperture),
    'h2_detections':count('H2','detected_positive_printed_error'),
    'h2_upper':count('H2','upper_limit'),
    'hd_detections':count('HD','detected_positive_printed_error'),
    'hd_upper':count('HD','upper_limit'),
    'hd_rounded_zero_excluded':count('HD','detected_rounded_error_zero'),
    'n_effective_lines':len(parsed['detected'])+len(parsed['limits']),
    'covariance': 'NOT_ACQUIRED', 'h2_population_grid': 'NOT_ACQUIRED'})
assert len(rows)==364 and len(census)==26
with (out/'PER_APERTURE_SOURCE_CENSUS.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=census[0].keys());w.writeheader();w.writerows(census)
sumkey=lambda k:sum(x[k] for x in census)
summary={'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'apertures':len(census),'printed_entries':len(rows),
 'h2_detected':sumkey('h2_detections'),'h2_upper':sumkey('h2_upper'),
 'hd_detected':sumkey('hd_detections'),'hd_upper':sumkey('hd_upper'),
 'hd_zero_rounded_excluded':sumkey('hd_rounded_zero_excluded'),
 'effective_joint_entries':sumkey('n_effective_lines'),
 'apertures_no_valid_hd_detection':sum(x['hd_detections']==0 for x in census),
 'apertures_with_h2_and_hd_detected':sum(x['hd_detections']>0 and x['h2_detections']>0 for x in census),
 'max_censored_entries_in_aperture':max(x['hd_upper']+x['h2_upper'] for x in census),
 'covariance_source_status':'NOT_ACQUIRED','h2_population_grid_source_status':'NOT_ACQUIRED',
 'existing_29640_profiles':'REUSED_BY_REFERENCE_NOT_RERUN',
 'canonical_dag':'28/88','rec_physical_dag':'0/313','production':'HOLD'}
(out/'SOURCE_CENSUS.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2))
