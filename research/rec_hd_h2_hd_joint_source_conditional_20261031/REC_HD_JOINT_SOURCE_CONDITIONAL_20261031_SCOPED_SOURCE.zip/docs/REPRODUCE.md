# Minimal scoped execution (Python >=3.11, numpy/scipy/matplotlib)

1. Preserve unmodified original Francis source ZIP `REC_HD_FRANCIS_CENSORED_FLUX_20261031_SOURCE.zip`, SHA-256 `7deb535d22458cb74ae702595131902a750e8d0c9cb585bc309e1fbaba3a94f3`.
2. Extract it to `<FROZEN_ROOT>` and verify `MANIFEST_SHA256.json` 50/50 before reusing. This new package **does not copy** the original bulk FITS/profiles, instead it binds to that source by checksum.
3. From this new package root execute:

```bash
python -m unittest discover -s tests -v
python -O -m unittest discover -s tests -v
python -m compileall -q src tests
python src/census_from_source.py \
  <FROZEN_ROOT>/inputs/francis_zenodo_v1_final_F1_F2_364.csv outputs
python src/ortho_fraction_probe.py <FROZEN_ROOT> outputs/HD_ORTHO_COLLIDER_FRACTION_PROBE.csv \
  > outputs/HD_ORTHO_COLLIDER_FRACTION_PROBE_SUMMARY.json
```

`src/physical_forward.py` holds an optically thin H2/HD generative flux operator, requiring authentic external H₂ level populations. `src/joint_censored_likelihood.py` holds an exact correlated detected/censored Gaussian likelihood, requiring actual measured covariance and reporting rule. No canned observational data or synthetic covariance are included. `src/ortho_fraction_probe.py` imports the original frozen HD physics code and checks the frozen original files' SHA via original `hd_line_transfer.read_models` before computing.

Current run: 24/24 normal tests + 24/24 `-O` tests PASS; 18-case source condition probe complete. This is not reproduction of the absent H₂ population FITS or original JOYS covariance.
