# REC-HD: source-conditional H₂+HD joint forward model and correlated censoring kernel

**UTC date:** 2026-10-31. **Status:** EXPLORATORY / SOURCE-CONDITIONAL / NONAUTHORITATIVE.
**Parent authority:** `cosmosapjw-quantum/rec_bianchi`, draft PR #176, HEAD `338f86a5a4ced83b6bcebb82e008bf7ca63bb1ec`; frozen PR #175 parent `dbe708e6c6bc9d52625321678809d7d816ecf029`. This is a separately scoped successor *research artifact*, NOT a completed REC physical DAG node and NOT the original Francis/Neufeld observational fit.

## 1. Frozen evidence and what was actually checked

- Library source ZIP `REC_HD_FRANCIS_CENSORED_FLUX_20261031_SOURCE.zip`: 4,331,976 bytes, SHA-256 `7deb535d22458cb74ae702595131902a750e8d0c9cb585bc309e1fbaba3a94f3` **locally rechecked**. ZIP 51 members, CRC PASS, 50/50 manifest entries have correct raw SHA-256 and size. `HD_CENSORED_29640_PROFILES.csv` is present with exactly **29,640 data records** and **was not recalculated**. Parent 12/12 standalone tests were rerun and passed (this runtime).
- Original final Francis Appendix F input from immutable parent: `inputs/francis_zenodo_v1_final_F1_F2_364.csv`, SHA-256 `eb550e1790fa2f127ce074fdbf5cff9bb1412c29121a149cf6d9ba5ef4d7896a`. This file was previously reconciled 364/364 against final Zenodo 14592550 Appendix F printing. Current work reused the source CSV bytes rather than repeating a PDF transcription.
- 26 apertures, 8 H₂ lines and 6 HD lines each: 364 printed entries, with H₂ 207 valid positive-error detections / 1 upper limit; HD 76 valid positive-error detections / 72 upper limits / 8 positive-flux detections with uncertainty rounded to 0.00 and excluded from candidate likelihood. **356 usable entries in total** after explicitly excluding the 8 rounded-error entries. Seventeen apertures contain positive-error HD detections, nine have none. No aperture has a current measured full cross-line covariance matrix in the source archive.
- The ChatGPT Library and Google Drive source ZIP are both **listed as existing with 4,331,976 bytes**. Prior PR #176 reports independent byte-exact restore checks from both providers; **these were not repeated using both providers' raw bytes during this turn**, so their current content SHA beyond reported provenance is not newly verified. Source archive `https://drive.google.com/file/d/1fVn1l99zOG_aD9k31ZvfqtWAaFyGgk47/view`, folder `https://drive.google.com/drive/folders/1dcDE2tjePVGzvnwCyqQNOjpTMb9Q9GyF`.
- Parallel REC-HD branches #175–#169 and branches devoted to lab covariance, MIRI shape and independent source physics exist. No PR newer than #176 was returned by the REC-HD search at check time. Original 35 Hz historical failure remains **FAIL 7/8**; that campaign is not rerun here.

## 2. Provenance of unacquired inputs

Original source: Francis et al., *A&A* **694**, A174 (2025), DOI `10.1051/0004-6361/202451629`, final Appendix source Zenodo `14592550`. Non-LTE source: Neufeld, *ApJ* **1007**, 16 (2026), DOI `10.3847/1538-4357/ae851a`; original data Zenodo record **v2 `21165907`**, `https://zenodo.org/records/21165907`.

Official v2 file listing identifies `h2_population_grids.fits` (published MD5 `cc652422aeb54f27899ddfc435cd93ae`) and `posterior_isobaric.csv.gz` (published MD5 `f21c0527fcf00829ad95888887d20afd`). Source listing is verified as an online record; **raw H₂ FITS and posterior bytes were not acquired/MD5-checked** in this runtime. Their contents are NOT silently reconstructed from HD populations or old fitted posterior numbers. There is no source-authentic H₂ population-based observational fit yet.

JWST original per-aperture MIRI MRS extracted spectra, extraction apertures/masks, line-fitting and continuum/blend Jacobians, pixel covariance including resampling, calibration correlation modes across channels, and original upper-limit detection/selection rule remain **NOT_ACQUIRED**. A cube's ERR extension alone is **not** the across-line flux-fit covariance. An assumed common 6% calibration error, or `σ_upper=L/3`, is **only a hypothesis**. The separate Sung HD R0–R3 laboratory covariance is not a substitute for this astronomical covariance.

## 3. Physical forward operator (derived; computational implementation verified on analytic controls)

Assumptions: optically thin, isotropic spontaneous emission, integrated line flux, prescribed extinction and beam coupling, source-native level fractions, no radiation trapping, fluorescence, chemical evolution, or line blends. All units are explicitly CGS; Planck's constant `h = 6.62607015 × 10⁻²⁷ erg s`, `ν` in Hz, Einstein A in s⁻¹, `N` in cm⁻² and solid angle `Ω` in sr. To match Francis printed values, divide by `10⁻¹⁵ erg cm⁻² s⁻¹`.

For line i with upper level `u`, component c:

```
F_i[erg cm^-2 s^-1] = Ω_a T_i b_i / (4π) * h ν_i A_i * Σ_c N_{u,i,c}
N_{u,H2,c} = N_{H2,c} w_{spin,c} f_{u|spin,c}
  w_{ortho,c} = OPR_c/(1+OPR_c);  w_{para,c} = 1/(1+OPR_c)
N_{u,HD,c} = 2 (D/H)_{gas,c} ξ_{HD,c} N_{H2,c} f_{u,HD,c}
```

Here `T_i=e^{-τ_i}` is attenuation (not gas temperature), `b_i` is beam/extraction coupling, `ξ_HD` is the fraction of gas-phase D nuclei represented by HD, and `D/H` is defined per H nucleus. `N_HD = 2(D/H)_gas ξ_HD N_H2` requires fully molecular H gas, spatially coextensive columns, and an explicitly supplied chemical partition factor. Thus the data constrain **the product** `(D/H)_gas ξ_HD` without additional chemistry or independent information. Treat `ξ_HD=1` as a *hypothesis*, never a measured fact.

The Neufeld-v2 H₂ FITS convention stores `LOGPOP = log10(f_J/g_J)`, separately normalized for para and ortho spin isomers, so `f_J = g_J·10^LOGPOP`. Source NaN high-J entries are not silently replaced by zero; the provided function rejects them and requires the caller to supply a physically justified method. `physical_forward.py` accepts already source-derived `f_J` fractions, not arbitrary generated H₂ grid values, and enforces the distinction.

Existing 29,640 HD scores profile **free nonnegative amplitudes** that absorb unknown HD column, aperture and extinction. Their scores cannot be algebraically combined with the H₂ flux table to infer `(D/H)` without reattaching an absolute-flux forward operator and shared physical column parameters. This successor deliberately did not relabel those amplitudes as columns.

## 4. Exact censored likelihood with input covariance (derived)

Let all reported line-flux estimators at an aperture be jointly normal `Y ~ N(μ(θ),Σ(θ))`. Partition into observed detection values `y_D` and upper-limit censoring *events* `Y_U ≤ L_U`. If and only if the empirical reporting process genuinely corresponds to these censoring events and Σ is the calibrated flux-fitting covariance, the exact likelihood is

```
log L(θ) = log φ_|D|(y_D; μ_D, Σ_DD)
           + log Φ_|U|(L_U; μ_{U|D}, Σ_{U|D})
μ_{U|D}=μ_U+Σ_UD Σ_DD^{-1}(y_D−μ_D)
Σ_{U|D}=Σ_UU−Σ_UD Σ_DD^{-1} Σ_DU.
```

The detection term includes `log(det Σ_DD)`, essential for a model-dependent noise calibration. The second term is **one multivariate conditional Gaussian CDF**, not a product of marginal upper-limit CDFs, unless the conditional covariance is actually diagonal. For an explicit Gaussian calibration model `Y_i=μ_i (1+Σ_k B_ik δ_k)+ε_i`, `δ~N(0,K)` and `ε~N(0,S)`, integrating δ gives

```
Σ(μ)=S + diag(μ) B K B^T diag(μ),
```

where `S,B,K` must come from a measured/validated reduction model, not plug-in observed fluxes. This identity is exact for the stated *linear Gaussian calibration model* and can include shared cross-aperture modes by extending the full observation vector. In an observed non-Gaussian/threshold-selected pipeline, the likelihood must instead follow its actual measurement and reporting mechanism.

`joint_censored_likelihood.py` accepts actual `(μ,Σ,y_D,L_U)` and computes exact detection density, exact uni/diagonal censoring CDF or a seeded numerical multivariate CDF for correlated multi-limit cases. Its numerical multi-CDF values are **approximate and not certified at extreme tails**; it raises on zero-probability underflow. A material bug was caught and fixed: for flux squared near `10^-30` in CGS, testing off-diagonal covariance against an absolute `10^-13` threshold incorrectly classifies strongly correlated matrices as diagonal. The implementation now checks the dimensionless correlation matrix; a `ρ=.6` faint-flux test verifies the exact analytic bivariate normal orthant probability. Covariance symmetry tests also scale with the matrix magnitude.

## 5. New original-rate non-LTE experiment (numerically checked)

Unmodified Neufeld HD 15-level and 2 original standard/alternate collider-rate datasets from frozen source ZIP; change only *input* ortho-H₂ collider fraction `η=0.75` vs `η=1.9/(1+1.9)` at redshift 0. Nine exact source combinations per collider rate: T = 600/1000/2000 K, `n_H2=10^4,10^6,10^8 cm^-3`. Total **18** condition comparisons, evaluated for signed emission lines HD R(4)..R(9). No rerun of the 29,640 flux-fitting profiles and no novel H₂ FITS grid.

- Maximum single-line fractional change: **`0.04101728560814577`** (4.1017%).
- Maximum normalized logarithmic six-line shape spread: **`0.031276435356543945`**.
- Maximum stationary-state residual: **`3.521065538555596e-18 s^-1`**.

Original rate-source raw SHA-256: std `f07f36fd56fe351fe4032235abbc863319b652838e635cd76bbf09664ce099cb`, alternate `66033b44196bf8a57735b9c541c4f1c8bc8585449050dfd91152e6444d8d73ac`. Published Neufeld warm H₂ median OPR ≈1.9 is used only as a **sensitivity scenario**, not each aperture's fitted collider OPR. The physically consistent temperature dependence of collider OPR and its coupling to HD needs future source-model admission, not imposed from the paper's posterior sample median.

Source CSV `outputs/HD_ORTHO_COLLIDER_FRACTION_PROBE.csv` gives all 18 values; figure `figures/HD_COLLIDER_ORTHO_SOURCE_SHAPE.png` visualizes them. This is **source-backed numerical model geometry**, not observation-confirmed D/H or physical pressure.

## 6. Verification, scope and gate

New `unittest` standalone: **24/24 normal PASS, 24/24 under Python `-O` PASS**; `compileall` PASS. Tests include analytic independent two-limit Gaussian orthant, conditional one-limit formula, H₂ spin weights, dimensional optically thin flux, two-component linearity, explicit source NaN handling, parameter-dependent calibration covariance, and faint flux covariance scaling. The source-integration script was rerun on frozen ZIP with 18 physical conditions. Native distinct-author R6/C9: **NOT_RUN** (no native subagent tool available); all checks here are same-context code/tests, with analytic oracle for selected cases only.

These 24 tests do **not** prove likelihood fidelity to unacquired spectra; kernel acceptance requires measured Σ, source-authentic H₂ populations, source flux response, and censor mechanism. No profile likelihood over Francis' H₂+HD observations, no D/H abundance posterior or uncertainty, no Bayes factor, no observational significance and no canonical REC physical node resulted.

Unchanged locked admission state:

```
CANONICAL_DAG=28/88 (+0)
REC_PHYSICAL_DAG=0/313 (+0)
EXISTING_SCOPED_R_C=18/20
R6_C9_DISTINCT_AUTHOR=NOT_RUN
ORIGINAL_35HZ=FAIL7/8
PRODUCTION=HOLD
NO_MERGE=true
NO_OWNER_SOURCE_SWITCH=true
NO_35HZ_RELAXATION=true
AUTO_NEXT_NODE=false
```

## 7. Minimal next executable action

1. Obtain byte-authentic H₂ population FITS from official Neufeld v2 and verify published MD5 and FITS HDU/axes/unit/spin normalization. Map `LOGPOP` onto temperature, density, para/ortho J, avoiding undocumented interpolations. Neufeld v2 posterior CSV can provide an **external comparison**, not the source observational likelihood.
2. Obtain Francis JWST per-aperture spectra/cube lineage and extraction masks, pixel covariance, line-fit Jacobians, calibrator modes crossband, signal extraction coupling and upper-limit reporting threshold. Attempt MAST archival data for programs 1290/1257, or get authors' line-fit covariance and spectrum bundles. Confirm the 8 zero-rounded uncertainties with unrounded originals.
3. Bind measured line emission to `physical_forward` and covariance/reporting to `joint_censored_likelihood`; run a model-conditioned multi-line fit with explicit reference parameters, physical priors, positivity and chemistry limitations. Verify source semantics and results against Neufeld's posterior within defined scope; keep the source lock unchanged.
4. Only after an **explicit separate scientific admission decision** change any canonical/physical DAG status or production/merge policy.
