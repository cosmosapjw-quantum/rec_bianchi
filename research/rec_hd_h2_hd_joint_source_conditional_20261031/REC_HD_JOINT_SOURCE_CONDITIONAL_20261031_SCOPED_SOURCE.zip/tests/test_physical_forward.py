import math, sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from physical_forward import Component, Transition, PLANCK_ERG_S, joint_flux_optically_thin, level_fraction_from_source_logpop

def comp(opr=3.,nh2=1e19,abun=2.5e-5,xi=1.):
    return Component(nh2,abun,xi,opr,{2:.3,4:.01},{3:.2,5:.05},{5:.001,6:.0003})

class ForwardPhysics(unittest.TestCase):
    def test_population_source_conversion(self):
        self.assertAlmostEqual(level_fraction_from_source_logpop(-2.,5.),0.05)
    def test_source_missing_nan_not_imputed(self):
        with self.assertRaises(ValueError):level_fraction_from_source_logpop(float('nan'),5.)
    def test_hd_h2_abundance_relation(self):
        # Fully molecular hydrogen and all D in HD: N_HD = 2 (D/H) N_H2.
        x=comp(); self.assertEqual(2*x.gas_D_over_H*x.N_H2_cm2,5e14)
    def test_hd_single_line_analytic(self):
        t=[Transition('HD_R5','HD',6,1e13,1e-5)]
        omega=1e-11; y=joint_flux_optically_thin(t,[comp()],omega)[0]
        Nupper=2*2.5e-5*1e19*0.0003
        expect=omega*PLANCK_ERG_S*1e13*1e-5*Nupper/(4*math.pi*1e-15)
        self.assertAlmostEqual(y,expect,places=12)
    def test_two_component_linearity(self):
        t=[Transition('HD','HD',5,1e13,1e-4)]
        x=comp(); z=comp(nh2=2e19)
        one=joint_flux_optically_thin(t,[x],1e-11)[0]
        two=joint_flux_optically_thin(t,[x,z],1e-11)[0]
        self.assertAlmostEqual(two,3*one)
    def test_h2_spin_ratio(self):
        # H2 odd J=3 sees ortho weight OPR/(1+OPR), J=2 sees para weight 1/(1+OPR).
        t=[Transition('H2_S1','H2',3,1e13,1e-7),Transition('H2_S0','H2',2,1e13,1e-7)]
        f3=joint_flux_optically_thin(t,[comp(opr=3)],1e-11)
        f1=joint_flux_optically_thin(t,[comp(opr=1)],1e-11)
        self.assertAlmostEqual(f3[0]/f1[0],1.5)
        self.assertAlmostEqual(f3[1]/f1[1],0.5)
    def test_extinction_and_beam(self):
        t=[Transition('HD','HD',5,1e13,1e-4)]
        s=joint_flux_optically_thin(t,[comp()],1e-11)[0]
        t2=[Transition('HD','HD',5,1e13,1e-4,transmission=.8,aperture_coupling=.5)]
        self.assertAlmostEqual(joint_flux_optically_thin(t2,[comp()],1e-11)[0],0.4*s)
    def test_none_gas_deuterium_zero_hd(self):
        t=[Transition('HD','HD',5,1e13,1e-4)]
        self.assertEqual(joint_flux_optically_thin(t,[comp(xi=0)],1e-11)[0],0)
    def test_bad_population_rejected(self):
        x=comp(); x.hd_population[5]=float('nan')
        with self.assertRaises(ValueError):joint_flux_optically_thin([Transition('HD','HD',5,1e13,1e-4)],[x],1e-11)
    def test_negative_column_rejected(self):
        with self.assertRaises(ValueError):joint_flux_optically_thin([Transition('H2','H2',3,1e13,1e-7)],[comp(nh2=-1)],1e-11)

if __name__=='__main__':unittest.main()
