import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
from scipy.stats import multivariate_normal, norm
from joint_censored_likelihood import (joint_censored_loglikelihood as ll,
    generative_calibration_covariance as gcc, validate_observation_inputs)

class Tests(unittest.TestCase):
    def test_all_detected_gaussian(self):
        mu=[0.3,0.5]; c=[[1.,0.2],[0.2,2.]]; y=[-0.1,1.]
        out=ll(mu,c,[0,1],y,[],[])
        self.assertAlmostEqual(out.value, multivariate_normal.logpdf(y,mu,c),places=12)

    def test_conditional_one_limit_analytic(self):
        mu=[1.2,0.4]; c=[[4.,0.6],[0.6,1.0]]; y=2.0; lim=0.1
        v=ll(mu,c,[0],[y],[1],[lim]); condmean=mu[1]+c[1][0]/c[0][0]*(y-mu[0])
        condvar=c[1][1]-c[1][0]**2/c[0][0]
        ex=norm.logpdf(y,mu[0],2.)+norm.logcdf((lim-condmean)/np.sqrt(condvar))
        self.assertAlmostEqual(v.value,ex,places=12)

    def test_diagonal_factorization(self):
        mu=[0.,2.,-1.]; c=np.diag([0.25,1.,4.]); v=ll(mu,c,[0],[0.3],[1,2],[1.5,0.])
        ex=norm.logpdf(0.3,0.,0.5)+norm.logcdf(-0.5)+norm.logcdf(0.5)
        self.assertAlmostEqual(v.value,ex,places=12)
        self.assertEqual(v.method,'diagonal_exact')

    def test_two_correlated_limits(self):
        c=[[1.,0.3],[0.3,1.]]; v=ll([0.,0.],c,[],[],[0,1],[0.,0.])
        # Exact orthant P(Y1<=0,Y2<=0)=1/4+arcsin(rho)/(2pi).
        ex=np.log(0.25+np.arcsin(0.3)/(2*np.pi))
        self.assertAlmostEqual(v.value,ex,places=7)

    def test_correlated_faint_flux_not_misclassified_diagonal(self):
        # C ~ 10^-30 in flux^2, with rho=.6. Absolute 1e-13 cutoff is invalid.
        s=1e-15; rho=.6
        cov=s*s*np.array([[1.,rho],[rho,1.]])
        out=ll([0.,0.],cov,[],[],[0,1],[0.,0.]); self.assertEqual(out.method,'multivariate_cdf_numerical_seeded')
        exact=np.log(0.25+np.arcsin(rho)/(2*np.pi))
        self.assertAlmostEqual(out.value,exact,places=7)

    def test_tiny_asymmetric_matrix_rejected(self):
        cov=np.array([[1.,.9],[.1,1.]])*1e-30
        with self.assertRaises(ValueError): ll([0.,0.],cov,[0],[0.],[1],[0.])

    def test_all_upper_monotone_fixed_covariance(self):
        c=np.eye(3); u=[0,1,2]; l=[1.,1.,1.]
        a=ll([0.,0.,0.],c,[],[],u,l).value
        b=ll([1.,1.,1.],c,[],[],u,l).value
        self.assertGreater(a,b)

    def test_calibration_lowrank_covariance(self):
        mu=[2.,4.]; s=np.diag([0.04,0.09]); b=[[1.],[1.]]; k=[[0.01]]
        c=gcc(mu,s,b,k)
        np.testing.assert_allclose(c,[[0.08,0.08],[0.08,0.25]],rtol=1e-12)

    def test_reject_singular_covariance(self):
        with self.assertRaises(ValueError):ll([0.,0.],[[1.,1.],[1.,1.]],[0],[0.],[1],[1.])

    def test_reject_duplicate_index(self):
        with self.assertRaises(ValueError):ll([0.,0.],np.eye(2),[0],[0.],[0],[1.])

    def test_missing_censor_noise_not_invented(self):
        rows=[{'species':'HD','line':'R(4)','status':'upper_limit','value_printed':'0.3','sigma_printed':''}]
        v=validate_observation_inputs(rows)
        self.assertIsNone(v['limits'][0]['sigma_conditional'])
        self.assertFalse(v['measured_joint_likelihood_admissible'])

    def test_rounded_sigma_excluded(self):
        rows=[{'species':'HD','line':'R(4)','status':'detected_rounded_error_zero','value_printed':'0.3','sigma_printed':'0.00'}]
        v=validate_observation_inputs(rows)
        self.assertEqual(len(v['excluded']),1);self.assertEqual(len(v['detected']),0)

    def test_calibration_model_scales_with_mu_not_observed_y(self):
        s=np.diag([0.1,0.1]); b=np.ones((2,1)); k=[[0.01]]
        c1=gcc([2,4],s,b,k); c2=gcc([3,4],s,b,k)
        self.assertNotEqual(c1[0,0],c2[0,0])
        self.assertEqual(c1[1,1],c2[1,1])

    def test_censored_conditional_shift(self):
        mu=[0.,0.]; c=[[1.,0.7],[0.7,1.]]
        self.assertLess(ll(mu,c,[0],[1.],[1],[0.]).value,
                        ll(mu,c,[0],[-1.],[1],[0.]).value)

if __name__=='__main__':unittest.main()
