from pathlib import Path
import hashlib,json,os,resource,sys,time
ROOT=Path('/workspace/scratch/45780e6e06f6/rec_bianchi')
OUT=Path('/workspace/scratch/45780e6e06f6/rec_r3q_intake/formal_validation_002')
OUT.mkdir(exist_ok=False)
start_cpu=sum(getattr(resource.getrusage(k),v) for k in (resource.RUSAGE_SELF,resource.RUSAGE_CHILDREN) for v in ('ru_utime','ru_stime'))
start_wall=time.monotonic()
for kind,cap in ((resource.RLIMIT_CPU,60),(resource.RLIMIT_AS,2*1024**3)):
 soft,hard=resource.getrlimit(kind)
 nh=min(cap,hard) if hard!=resource.RLIM_INFINITY else cap
 ns=min(nh,soft) if soft!=resource.RLIM_INFINITY else nh
 resource.setrlimit(kind,(ns,nh))
cache=OUT/'pycache';cache.mkdir()
sys.dont_write_bytecode=True;sys.pycache_prefix=str(cache)
sys.path.insert(0,str(ROOT/'scripts'))
from build_r3o_rust import Budget,dump_new,finalize_resource_record,sha256
budget=Budget(OUT,cpu_s=60.,wall_s=180.,memory_bytes=2*1024**3)
budget.start_cpu,budget.start_wall=start_cpu-5.334566000000001,start_wall-5.2222272670042
source='1313b1f1b2c081d57bcce9c60e757ef79110df91'
raw=ROOT.parent/'rec_r3q_intake/profile32_repaired/worker'
env=os.environ.copy()
env.update({k:'1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','PYTEST_DISABLE_PLUGIN_AUTOLOAD')})
env['PYTHONPATH']=str(ROOT.parent/'r3r_test_deps')
env['REC_R3R_ACTUAL32_WORKER_DIR']=str(raw)
commands=[
 ('tests',[sys.executable,'-B','-X','pycache_prefix='+str(OUT/'pytest-cache'),'-m','pytest','-q','-p','no:cacheprovider','tests/test_r3r_stream_audit.py','tests/test_r3r_supervised.py','--junitxml='+str(OUT/'tests.xml')]),
 ('benchmark',[sys.executable,'-B',str(ROOT/'scripts/benchmark_r3r_stream_audit.py'),'--source-sha',source,'--native-stream',str(raw/'native_oracle_stdout.csv'),'--python-result',str(raw/'python_continuation.npz'),'--verification',str(raw/'verification.json'),'--rounds','5','--warmups','1','--output-dir',str(OUT/'benchmark')]),
 ('pilot',[sys.executable,'-B',str(ROOT/'scripts/run_r3r_h4_supervised.py'),'--expected-commit',source,'--new-allocation-id','REC_R3R_VALIDATION_20261020_001_PILOT32','--evidence-dir',str(OUT/'pilot'),'--backend','numpy','--steps','32'])
]
record={'schema':'rec.r3r.formal-validation.v1','status':'FAILED','allocation_id':'REC_R3R_VALIDATION_20261020_001','repository_source_commit':source,'validation_wrapper_sha256':sha256(__file__),'wrapper_scope':'External captured harness, not a file in repository_source_commit','total_envelope':{'cpu_s':60,'wall_s':180,'per_process_address_space_bytes':2*1024**3,'reserve_cpu_s':2,'reserve_wall_s':3},'max_new_accepted_steps':32,'prior_attempt_cpu_s':5.334566000000001,'prior_attempt_wall_s':5.2222272670042,'prior_attempt_result':'60 passed,1 fixture-context failure; benchmark/pilot NOT_RUN','wall_accounting':'cumulative supervised execution intervals; intervening editing excluded','first_failure':None}
code=2
try:
 for label,command in commands:
  budget.run(command,cwd=ROOT,env=env,label=label)
 record['status']='COMPLETED_SCOPED'
 code=0
except BaseException as exc:
 record['first_failure']={'type':type(exc).__name__,'message':str(exc)}
finally:
 record['commands']=budget.commands
 record['evidence_sha256']={str(p.relative_to(OUT)):sha256(p) for p in OUT.rglob('*') if p.is_file()}
 code=finalize_resource_record(record,budget,code,'R3R_FORMAL_VALIDATION')
 dump_new(OUT/'validation.json',record)
print(json.dumps({'status':record['status'],'exit_code':code,'CPU_s':record['process_tree_cpu_s'],'wall_s':record['wall_s'],'receipt':str(OUT/'validation.json')}))
raise SystemExit(code)

